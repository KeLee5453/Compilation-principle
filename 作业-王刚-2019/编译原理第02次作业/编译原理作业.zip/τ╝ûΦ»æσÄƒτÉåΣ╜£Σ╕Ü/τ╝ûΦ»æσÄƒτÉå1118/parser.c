%{
/****************************************************************************
parser.y
ParserWizard generated YACC file.

Date: 2017��11��19��
****************************************************************************/
#include<iostream>
#include<string>


using namespace std;
#define MAX 4
enum NodeType{Stmt,Expr,Decl};
enum Statement{If,While,For,Block,Input,Output,Fuc,Return,Expr_fuc,Fuc_asked};//stmt������
enum Expression{Op,Const,Idk,Type};
enum Declaration{Var,FucVar};
enum Type1{Int,Char,Void,Bool};

struct TreeNode
{
  struct TreeNode*child[MAX];
  struct TreeNode*brother;//����ƥ���ʱ�����ƥ���һ���仰���ʿ���֪�����ֵܽڵ㣬�����޷�֪���丸�ڵ�
  NodeType nodetype; 
  Statement stmttype;
  Expression exprtype;
  Declaration dectype;
  Type1 type;
  union{
   int op;//����������token���壬����int�Ͳ������ŵ�ֵ
   int val;//���ֵ�ֵ
   char* symbol;//id��ֵ
  }attr;//ֻ��id,const��op������attrֵ
  int lineno;//�ڵ����
};
int NUM=0;
int line=0;
TreeNode*root;
TreeNode*newDeclNode(Declaration dectype)
{
  TreeNode*t=(TreeNode*)malloc(sizeof(TreeNode));
  if(t==NULL)
    cout<<"Out of memory error"<<endl;
  else{
  for(int i=0;i<MAX;i++)
    t->child[i]=NULL;
  t->brother=NULL;
  t->nodetype=Decl;
  t->dectype=dectype;
  t->lineno=line++;}
  return t;
}
TreeNode*newExprNode(Expression exprtype)
{
  TreeNode*t=(TreeNode*)malloc(sizeof(TreeNode));
  if(t==NULL)
    cout<<"Out of memory error"<<endl;
  else{
  for(int i=0;i<MAX;i++)
    t->child[i]=NULL;
  t->brother=NULL;
  t->nodetype=Expr;
  t->exprtype=exprtype;
  t->lineno=line++;
  t->type=Void;}
  return t;
}
TreeNode*newStmtNode(Statement stmttype)
{
  TreeNode*t=(TreeNode*)malloc(sizeof(TreeNode));
  if(t==NULL)
    cout<<"Out of memory error"<<endl;
  else{
  for(int i=0;i<MAX;i++)
    t->child[i]=NULL;
  t->brother=NULL;
  t->nodetype=Stmt;
  t->stmttype=stmttype;
  t->lineno=line++;}
  return t;
}

%}

/////////////////////////////////////////////////////////////////////////////
// declarations section
%include{
  class lexer;
 }
 
 %include{
  #include "lexer.h"
 }
// parser name
%name parser

// class definition
{
	// place any extra class members here
public:
  lexer m_lexer;
public:
  void display(struct TreeNode*t);
 void shownode(struct TreeNode*t);
}

// constructor
{
	// place any extra initialisation code here
}

// destructor
{
	// place any extra cleanup code here
}

// attribute type
%include {
#ifndef YYSTYPE
#define YYSTYPE TreeNode* //yylval������
#endif
}

// place any declarations here
%token IF MAIN FOR WHILE CIN COUT//�ؼ���
%token INT CHAR VOID STRING//
%token ID NUMBER
%token PLUS MINUS MUL DIV REMI DPLUS DMINUS//������
%token GT LT GE LE NEQ AND OR NOT ASSIGN//�߼���ϵ
%token LFP RFP LSP RSP COMMA SEMI LP RP LM RM//������
%token RETURN

%left COMMA
%right ASSIGN
%left EQ NEQ
%left LT LE GT GE
%left PLUS MINUS
%left MUL DIV REMI
%left   DPLUS DMINUS
%left	LP RP LSP RSP LFP RFP LM RM
%right ELSE
%%

/////////////////////////////////////////////////////////////////////////////
// rules section
start   :MAIN LP RP block  { $$=$4;root=$4;display(root);m_lexer.show();}//main()
        ;
block   :LFP stmts RFP {$$=newStmtNode(Block);$$->child[0]=$2;}//������
        ;
stmts   :stmt stmts     {$$=$1;$$->brother=$2;}
        |stmt          {$$=$1;}
        ;
stmt    :expr_stmt     {$$=$1;}
        |var_stmt      {$$=$1;}//��������
        |if_stmt       {$$=$1;}
        |while_stmt    {$$=$1;}
        |for_stmt      {$$=$1;}
        |block         {$$=$1;}
        |input_stmt    {$$=$1;}
        |output_stmt   {$$=$1;}
        |fuc_stmt      {$$=$1;}
        |fuc_asked_stmt{$$=$1;}
        |return_stmt   {$$=$1;}
        ;
/*��������*/
type_var     :INT                      {$$=newExprNode(Type);$$->type=Int;}
             |CHAR                     {$$=newExprNode(Type);$$->type=Char;}
             |VOID                     {$$=newExprNode(Type);$$->type=Void;}
             ;
id_list      :expr COMMA id_list       {$$=$1;$$->brother=$3;}
             |expr
             ;
var_stmt     :type_var id_list SEMI    {$$=newDeclNode(Var);$$->child[0]=$1;$$->child[1]=$2;}//��������
             ; 
fuc_var      :fuc1_var COMMA fuc_var    {$$=$1;$$->brother=$3;}//�����б���������
             |fuc1_var                  {$$=$1;}              
             ; 
fuc1_var     :type_var ID              {$$=newDeclNode(FucVar);$$->child[0]=$1;$$->child[1]=$2;}
             ;     
expr_stmt    :expr SEMI				   {$$=$1;}
             |SEMI                   
             ;
             /*��ֵ*/
expr         :expr ASSIGN expr         {$$=newExprNode(Op);$$->child[0]=$1;$$->child[1]=$3;$$->attr.op=ASSIGN;}//$$=newStmtNode(Assign)
             |or_expr                  {$$=$1;}  
             ;
             /*����*/
or_expr      :or_expr OR and_expr      {$$=newExprNode(Op);$$->attr.op=OR;$$->child[0]=$1;$$->child[1]=$3;}
             |and_expr                 {$$=$1;}
             ;
and_expr     :and_expr AND eq_expr     {$$=newExprNode(Op);$$->attr.op=AND;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr                  {$$=$1;}
             ;
             /*>/</>=/<=*/
eq_expr      :eq_expr EQ simple_expr   {$$=newExprNode(Op);$$->attr.op=EQ;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr GE simple_expr   {$$=newExprNode(Op);$$->attr.op=GE;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr LE simple_expr   {$$=newExprNode(Op);$$->attr.op=LE;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr GT simple_expr   {$$=newExprNode(Op);$$->attr.op=GT;$$->child[0]=$1;$$->child[1]=$3;}//>
             |eq_expr LT simple_expr   {$$=newExprNode(Op);$$->attr.op=LT;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr NEQ simple_expr  {$$=newExprNode(Op);$$->attr.op=NEQ;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr LM simple_expr   {$$=newExprNode(Op);$$->attr.op=LM;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr RM simple_expr   {$$=newExprNode(Op);$$->attr.op=RM;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr			   {$$=$1;}
             ;
             /*+/-/*///++/--*/
simple_expr  :simple_expr PLUS term    {$$=newExprNode(Op);$$->attr.op=PLUS;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr MINUS term   {$$=newExprNode(Op);$$->attr.op=MINUS;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr MUL term     {$$=newExprNode(Op);$$->attr.op=MUL;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr DIV term     {$$=newExprNode(Op);$$->attr.op=DIV;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr REMI term    {$$=newExprNode(Op);$$->attr.op=REMI;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr DPLUS        {$$=newExprNode(Op);$$->attr.op=DPLUS;$$->child[0]=$1;}
             |simple_expr DMINUS       {$$=newExprNode(Op);$$->attr.op=DMINUS;$$->child[0]=$1;}
             |term					   {$$=$1;}
             ;
term         :LP expr RP               {$$=$2;}
			 |ID					   {$$=$1;}
			 |NUMBER				   {$$=$1;}
			 |NOT term                 {$$=newExprNode(Op);$$->attr.op=NOT;$$->child[0]=$2;}
			 ;
/*if���˵��*/
if_stmt      :IF LP expr RP stmt       {$$=newStmtNode(If);$$->child[0]=$3;$$->child[1]=$5;}
             |IF LP expr RP stmt ELSE stmt {$$=newStmtNode(If);$$->child[0]=$3;$$->child[1]=$5;$$->child[1]=$7;}
             ;
/*for���˵��*/
for_stmt     :FOR LP expr SEMI expr SEMI expr RP stmt {$$=newStmtNode(For);$$->child[0]=$3;$$->child[1]=$5;$$->child[2]=$7;$$->child[3]=$9;}
	         |FOR LP SEMI expr SEMI expr RP stmt      {$$=newStmtNode(For);$$->child[0]=$4;$$->child[1]=$6;$$->child[2]=$8;}  
             |FOR LP expr SEMI SEMI expr RP stmt      {$$=newStmtNode(For);$$->child[0]=$3;$$->child[1]=$6;$$->child[2]=$8;}  
             |FOR LP expr SEMI expr SEMI RP stmt      {$$=newStmtNode(For);$$->child[0]=$3;$$->child[1]=$5;$$->child[2]=$8;}  
             |FOR LP SEMI SEMI expr RP stmt			  {$$=newStmtNode(For);$$->child[0]=$5;$$->child[1]=$7;} 
             |FOR LP SEMI expr SEMI RP stmt			  {$$=newStmtNode(For);$$->child[0]=$4;$$->child[1]=$7;}
             |FOR LP expr SEMI SEMI RP stmt			  {$$=newStmtNode(For);$$->child[0]=$3;$$->child[1]=$7;}
             |FOR LP SEMI SEMI RP stmt				  {$$=newStmtNode(For);$$->child[0]=$6;}
             ;
                         
/*while���˵��*/
while_stmt   :WHILE LP expr RP stmt                   {$$=newStmtNode(While);$$->child[0]=$3;$$->child[1]=$5;}
             ;
/*input����output���*/
input_stmt   :CIN RM ID                               {$$=newStmtNode(Input);$$->child[0]=$3;}
             ; 
output_stmt  :COUT LM ID							  {$$=newStmtNode(Output);$$->child[0]=$3;}
             ;
/*�жϺ��������������ͺ�������*/
fuc_stmt     :type_var ID LP fuc_var  RP block        {$$=newStmtNode(Fuc);$$->child[0]=$1;$$->child[1]=$2;$$->child[2]=$4;$$->child[3]=$6; m_lexer.create(2,$2->attr.symbol);}
             ;
fuc_asked_stmt:type_var ID ASSIGN fuc_asked1_stmt     {$$=newStmtNode(Fuc);$$->child[0]=$1;$$->child[1]=$2;$$->child[2]=$4;m_lexer.create(2,$2->attr.symbol);}
              |fuc_asked1_stmt                        {$$=$1;}
              ;
fuc_asked1_stmt:ID LP expr_fuc RP SEMI                {$$=newStmtNode(Fuc_asked);$$->child[0]=$1;$$->child[1]=$3;}
               ;
expr_fuc      :expr COMMA expr                        {$$=newStmtNode(Expr_fuc);$$->child[0]=$1;$$->child[1]=$3;}
              |expr                                   {$$=newStmtNode(Expr_fuc);$$->child[0]=$1;}
              ; 
/*���ؾ���*/
return_stmt  :RETURN term							  {$$=newStmtNode(Return);$$->child[0]=$2;}
             ;                        
// place your YACC rules here (there must be at least one)

Grammar
	: /* empty */
	;

%%

/////////////////////////////////////////////////////////////////////////////
// programs section
void parser::display(struct TreeNode*t)//��ͷ��ʼ��ʾ�﷨��
{
 struct TreeNode*temp=(TreeNode*)malloc(sizeof(TreeNode));
 for(int i=0;i<MAX;i++)
 {
   if(t->child[i]!=NULL)
     display(t->child[i]);//�ݹ�ֱ��Ҷ�ڵ�
 }
 shownode(t);
 temp=t->brother;
 if(temp!=NULL)
 {
   display(temp);
 }
 return;
}
void parser::shownode(struct TreeNode*t)
{
  t->lineno=NUM++;
  struct TreeNode*temp=(struct TreeNode*)malloc(sizeof(TreeNode));
  cout<<t->lineno<<":";//����к�
  switch(t->nodetype)
  {
   case Stmt:
   {
     string names[10]={"If_statement,",  "While_statement," , "For_statement," , "Compound_statement,","Input_statement,","Output_statement,","Function_statement","Return_statement","Expression_fuction" ,"Function_asked"};
     cout<<names[t->stmttype]<<'\t';
     break;
   }
   case Expr:
   {
     string names[4]={"Expr," , "Const Declaration,", "ID Declaration,","Type Specifier," };
     string types[3]={"integer, ","Char","Void",};
     cout<<names[t->exprtype]<<'\t';
     switch(t->exprtype)
     {
      case Op:
      {
        switch(t->attr.op)
        {
          case PLUS:
          {
            cout<<'\t'<<"op:+"<<'\t';
            break;
          }
          case MINUS:
          {
            cout<<'\t'<<"op:-"<<'\t';
            break;
          }
          case MUL:
          {
            cout<<'\t'<<"op:*"<<'\t';
            break;
          }
          case DIV:
          {
            cout<<'\t'<<"op:/"<<'\t';
            break;
          }
          case REMI:
          {
            cout<<'\t'<<"op:%"<<'\t';
            break;
          }
          case DPLUS:
          {
            cout<<'\t'<<"op:++"<<'\t';
            break;
          }
          case DMINUS:
          {
            cout<<'\t'<<"op:--"<<'\t';
            break;
          }
          case LT:
          {
            cout<<'\t'<<"op:<"<<'\t';
            break;
          }
          case GT:
          {
            cout<<'\t'<<"op:>"<<'\t';
            break;
          }
          case LE:
          {
            cout<<'\t'<<"op:<="<<'\t';
            break;
          }
          case GE:
          {
            cout<<'\t'<<"op:>="<<'\t';
            break;
          }
          case EQ:
          {
            cout<<'\t'<<"op:=="<<'\t';
            break;
          }
           case ASSIGN:
          {
            cout<<'\t'<<"op:="<<'\t';
            break;
          }
          case NEQ:
          {
            cout<<'\t'<<"op:!="<<'\t';
            break;
          }
          case LM:
          {
            cout<<'\t'<<"op:<<"<<'\t';
            break;
          }
           case RM:
          {
            cout<<'\t'<<"op:>>"<<'\t';
            break;
          }
          case NOT:
          {
            cout<<'\t'<<"op:!"<<'\t';
            break;
          }
          case OR:
          {
            cout<<'\t'<<"op:||"<<'\t';
            break;
          }
          case AND:
          {
            cout<<'\t'<<"op:&&"<<'\t';
            break;
          }
        }
          break;
       }
        case Const:
        {
          cout<<"value:"<<t->attr.val<<'\t';
          break;
        }
        case Idk:
        {
          cout<<"symbol:"<<t->attr.symbol<<'\t';
          break;
        }
        case Type:
        {
          cout<<types[t->type]<<'\t';
          break;
        }
      }
      break;
     }
     case Decl:
     {
       string names[2]={"Var Declaration, ", "Fuc Declaration"};
       cout<<names[t->dectype]<<'\t';
       break;
     }
   } 
   cout<<"children:";
   for(int i=0;i<MAX;i++)
   {
     if(t->child[i]!=NULL)
     {
       cout<<t->child[i]->lineno<<" ";
       temp=t->child[i]->brother;
       while(temp!=NULL)
       {
        cout<<temp->lineno;
        temp=temp->brother; 
       }
     }
   }
   cout<<endl;
   return;
}
int main(void)
{
	int n = 1;
	lexer lexer;
	parser parser;
	if (parser.yycreate(&lexer)) {
		if (lexer.yycreate(&parser)) {
			n = parser.yyparse();
		}
	}
	return n;
}

