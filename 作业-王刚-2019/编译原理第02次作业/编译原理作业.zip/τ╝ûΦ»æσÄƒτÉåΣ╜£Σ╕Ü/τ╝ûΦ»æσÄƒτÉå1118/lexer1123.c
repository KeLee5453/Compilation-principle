%{ 
#include "parser.h"
#include <iostream>
#include <string.h>
#include <iomanip>
using namespace std;
 
#define MAX 4
enum NodeType{Stmt=0,Expr,Decl};
enum Statement{If=0,While,For,Block,Input,Output};
enum Expression{Op=0,Const,Idk,Type};
enum Declaration{Var=0};
enum ExpType{Int=0,Char,Void,Bool};
 
struct TreeNode
{
  int lineno;
  struct TreeNode*child[MAX];
  struct TreeNode*brother;//由于匹配的时候可以匹配出一整句话，故可以知道其兄弟节点，但是无法知道其父节点
  int nodetype; 
  int specifictype;
  ExpType type;
  int val;
};
extern YYSTYPE yylval;
extern int line;

struct idNameType
{
	char *name;
	ExpType type;
};
idNameType ids[1000];
int idKount=0;
int lines_num = 0;
%}
/////////////////////////////////////////////////////////////////////////////
// declarations section

// lexical analyser name
%name lexer

// class definition
{
	// place any extra class members here
public:
int getId(char *word);
}

// constructor
{
	// place any extra initialisation code here
}

// destructor
{
	// place any extra cleanup code here
}

newline     [\n]
whitespace  [ \t]+
digit [0-9]
letter	[A-Za-z_]
id	{letter}({letter}|{digit})*
number	{digit}+(\.{digit}+)?(E[+-]?{digit}+)?


%%

%{
	// extract yylval for use later on in actions
	YYSTYPE YYFAR& yylval = *(YYSTYPE YYFAR*)yyparserptr->yylvalptr;
%}

{newline}       {lines_num++;}
{whitespace}    {/* skip whitespace */}

","				        {return COMMA;}
";"					    {return SEMI;}
"("					    {return LP;}
")"					    {return RP;}
"{"					    {return LFP;}
"}"					    {return RFP;}
"["					    {return LSP;}//数组时候使用
"]"				     	{return RSP;}
/*关键字*/
"if"					{return IF;}
"else"					{return ELSE;}
"while"					{return WHILE;}
"for"					{return FOR;}
"cin"					{return CIN;}
"cout"					{return COUT;}
"void"					{return VOID;}
"int"					{return INT;}
"char"					{return CHAR;}
"bool"					{return BOOL;}
"="				    	{return ASSIGN;}
"main"                  {return MAIN;}
"return"                {return RETURN;}
/*操作符*/
"+"				    	{return PLUS;}
"-"				    	{return MINUS;}
"*"				    	{return MUL;}
"/"				    	{return DIV;}
"%"				    	{return REMI;}
"++"				    {return DPLUS;}
"--"				   	{return DMINUS;}
"=="				   	{return EQ;}
/*逻辑运算符*/
">"				    	{return GT;}
"<"				    	{return LT;}
">="				   	{return GE;}
"<="				    {return LE;}
"!="				   	{return NEQ;}
"&&"				   	{return AND;}
"||"				   	{return OR;}
"!"				    	{return NOT;}
"<<"                    {return LM;}
">>"                    {return RM;}
 
{number}        {
					struct TreeNode *node = (struct TreeNode*)malloc (sizeof(struct TreeNode));
					for(int i=0;i<MAX;i++)
                    {
                        node->child[i]=NULL;
                    }
					node->brother=NULL;
					node->nodetype=Expr;
					node->specifictype=Const;
					node->val=atoi(yytext);					
					node->type=Int;
					node->lineno=line++;
					yylval = node;
					return NUMBER;
				}
{id}			{
					struct TreeNode *node = (struct TreeNode*)malloc (sizeof(struct TreeNode));
					for(int i=0;i<MAX;i++)
                    {
                        node->child[i]=NULL;
                    }
					node->brother=NULL;
					node->nodetype=Expr;
					node->specifictype=Idk;	
					node->val=getId(yytext);
					node->type=Void;
					node->lineno=line++;
					yylval = node;
					return ID;
				}	
%%

int lexer::getId(char *word)
{
	for(int i=0;i<idKount;i++)
	{
		if(strcmp(ids[i].name,word)==0)return i;
	}
	int length=strlen(word)+1;
	ids[idKount].name=new char[length];
	strcpy(ids[idKount].name,word);
	ids[idKount].type=Void;
	idKount++;
	return idKount-1;
}
