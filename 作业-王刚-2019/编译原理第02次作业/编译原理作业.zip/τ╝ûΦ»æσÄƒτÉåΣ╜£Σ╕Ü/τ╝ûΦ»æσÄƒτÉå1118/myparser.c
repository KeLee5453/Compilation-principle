%{
/****************************************************************************
myparser.y
ParserWizard generated YACC file.

Date: 2012��12��5��
****************************************************************************/



#include "mylexer.h"

#include <iostream.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>

enum
{
	STMT_NODE = 0,
	EXPR_NODE,
	DECL_NODE
};

enum
{
	IF_STMT = 0,
	WHILE_STMT,
	FOR_STMT,
	COMP_STMT
};

enum
{
	TYPE_EXPR = 0,
	OP_EXPR,
	CONST_EXPR,
	ID_EXPR
};

enum
{
	VAR_DECL = 0,
	ARRAY_DECL
};

enum
{
	Notype = 0,
	Integer,
	Char
};
enum
{
	greatthan = 0,
	greatequal,
	lessthan,
	lessequal,
	equal,
	plu,
	min,
	fmin,
	quo,
	tim,
	ove,
	rem,
	dplu,
	dmin,
	assi,
	notequal
};

//�����ڵ�ṹ
struct TNode
{
	int index;
	int kind;
	int kind_kind;
	int type;
	int val;
	struct TNode *lc;		
	struct TNode *rc;

};
int count=0;		//��¼�ڵ�����
void Display(struct TNode *p);		//��ʾ�﷨��
void ShowNode(struct TNode *p);		//��ʾĳ���ڵ�

struct TNode* createnode(int kind,int kind_kind,int type,int val, struct TNode *lc,struct TNode *rc)
{
	struct TNode *node;
	node=(struct TNode *) malloc (sizeof(struct TNode));
	node -> lc = (struct TNode *) malloc (sizeof(struct TNode));
	node -> rc = (struct TNode *) malloc (sizeof(struct TNode));
	node -> kind = kind;
	node -> kind_kind = kind_kind;
	node -> type = type;
	node -> val = val;
	node -> lc = lc;
	node -> rc = rc;	
	return node;
}
extern char idtable[20][20];		//Ӧ�÷��ű�
	
extern int temp;
%}

/////////////////////////////////////////////////////////////////////////////
// declarations section

// attribute type

%include {
#ifndef YYSTYPE
#define YYSTYPE struct TNode*
#endif
}


%token IF MAIN FOR WHILE 
%token INT CHAR VOID 
%token ID NUM 
%token PLUS MINUS TIMES OVER REMI DPLUS DMINUS
%token LT LE GT GE EQ NEQ ASSIGN QUO 
%token SEMI COMMA LP RP LSP RSP LFP RFP 


 
%left	COMMA 
%right	ASSIGN 
%left	EQ NEQ 
%left	LT LE GT GE 
%left	PLUS MINUS TIMES OVER REMI DPLUS DMINUS
%left	LP RP LSP RSP LFP RFP 
%right	ELSE 

// place any declarations here


%%

program		:MAIN LP RP comp_stmt
			{ 
				Display($4);
			}
			|MAIN LP VOID RP comp_stmt
			{
				Display($5);
			}
			|VOID MAIN LP RP comp_stmt
			{
				Display($5);
			}
			|VOID MAIN LP VOID RP comp_stmt
			{
				Display($6);
			}
			;

var_dec		:type_spec id_list SEMI
			{	
				$$ = createnode (DECL_NODE , VAR_DECL , Notype ,-1, $1 , NULL);
				$1->rc=$2;
			}
			;
			
type_spec	:INT	
			{
				$$ = createnode (EXPR_NODE, TYPE_EXPR , Integer , -1, NULL ,NULL);
			}	
			|CHAR	
			{
				$$ = createnode (EXPR_NODE, TYPE_EXPR , Char ,-1, NULL ,NULL);
			}
			;
			
id_list		:id COMMA id_list	
			{
				$$ = $1;
				$1 -> rc = $3;		
			}
			|id			
			{
				$$ = $1;
			}
			;
			
id          :ID	
			{	
				$$ = $1;
			} 
            ; 

			
comp_stmt	:LFP  stmt_list RFP
			{	
				$$ = createnode(STMT_NODE, COMP_STMT , Notype , -1 , $2, NULL);
			}
			;
			
stmt_list	:stmt stmt_list				
			{
				$1->rc = $2; 
				$$ = $1;
			}
			|stmt						
			{
				$$ = $1 ;
			}
			;
			
stmt		:var_dec					
			{	
				$$ = $1;
			}
			|exp_stmt					
			{	
				$$ = $1;
			}
			|if_stmt					
			{	
				$$ = $1;
			}
			|for_stmt
			{
				$$ = $1;
			}
			|while_stmt 
			{
				$$ = $1;
			}        
			|comp_stmt					
			{	
				$$ = $1;
			}
			;
			
exp_stmt	:exp SEMI		
			{
				$$ = $1;
			}
			|SEMI
			{
				$$ = NULL;
			}
			;
if_stmt		:IF LP exp RP stmt ELSE stmt
			{
				$$ = createnode(STMT_NODE, IF_STMT, Notype, -1 , $3, NULL);
				$3 -> rc = $5;
				$5 -> rc = $7;
			}

			|IF LP exp RP  stmt
			{	
				$$ = createnode(STMT_NODE, IF_STMT , Notype , -1, $3, NULL);
				$3 -> rc = $5;		
			}
			;
			
for_stmt	:FOR LP exp SEMI exp SEMI exp RP stmt
			{
				$$ = createnode(STMT_NODE, FOR_STMT , Notype, -1, $3 , NULL);
				$3 -> rc = $5;
				$5 -> rc = $7;
				$7 -> rc = $9;
			}
			;
			
while_stmt	:WHILE LSP exp RSP stmt
			{
				$$ = createnode(STMT_NODE, WHILE_STMT , Notype , -1 , $3, NULL);
				$3 -> rc = $5;	
			}
			;	
exp			:id ASSIGN exp
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , assi , $1 ,NULL);
				$1 -> rc = $3;
			}			
			|simple_expr				
			{
				$$ = $1;
			}
			|id ASSIGN QUO exp QUO
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , assi , $1 ,NULL);
				$1 -> rc = $4;
			}
			;
			
simple_expr	:simple_expr EQ simp_expr
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , equal , $1, NULL);
				$1 -> rc = $3;
			}
			
			|simple_expr LE simp_expr
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , lessequal , $1, NULL);
				$1 -> rc = $3;
			}
			
			|simple_expr GE simp_expr
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , greatequal , $1, NULL);
				$1 -> rc = $3;
			}
			
			|simple_expr LT simp_expr	
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , lessthan , $1, NULL);
				$1 -> rc = $3;
			}
			
			|simple_expr GT simp_expr	
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , greatthan , $1, NULL);
				$1 -> rc = $3;
			}
			|simple_expr NEQ simp_expr	
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , notequal , $1, NULL);
				$1 -> rc = $3;
			}
			|simp_expr
			{
				$$ = $1;
			}
			;
			
simp_expr	:simp_expr PLUS	term 
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , plu , $1, NULL);
				$1 -> rc = $3;
			}
			|simp_expr MINUS term
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , min , $1, NULL);
				$1 -> rc = $3;
			}
			|MINUS simp_expr
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , fmin , $2, NULL);
			
			}
			|simp_expr DPLUS 
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , dplu , $1, NULL);
				
			}
			|simp_expr DMINUS 
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , dplu , $1, NULL);
				
			}
			|term
			{
				$$ = $1;
			}
			;

term		:term TIMES factor
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , tim , $1, NULL);
				$1 -> rc = $3;
			}
			
			|term OVER factor
			{	
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , ove , $1, NULL);
				$1 -> rc = $3;
			}
			|term REMI factor
			{
				$$ = createnode(EXPR_NODE , OP_EXPR , Notype , rem , $1 , NULL);
				$1 -> rc = $3;
			}
			|factor					
			{
				$$	=	$1;
			}
			;
factor		:LP exp RP				
			{
				$$ = $2;
			}
			|id					
			{
				$$ = $1;
			}
			|NUM				
			{
				$$ = $1;
			}
			;
%%	

/////////////////////////////////////////////////////////////////////////////
// programs section

void Display(struct TNode *p)
{
	
	
	struct TNode *temp ;
	temp =(struct TNode *) malloc (sizeof(struct TNode));

	if(p->lc != NULL)
	{
		Display(p->lc);
	}
	ShowNode(p);	
	
	temp = p->rc;
	if(temp!=NULL)
	{
		Display(temp);
	}
	return;		
}

void ShowNode(struct TNode *p)
{
	struct TNode *temp ;
	temp = (struct TNode *) malloc (sizeof(struct TNode)); 
	p -> index = count;
	printf("%-3d ",count++);
	switch(p->kind)
	{
		case STMT_NODE:
		{
			char *names[4] = {"If_statement",  "While_statement" , "For_statement" , "Compound_statement" };
			printf("%-40s",names[p->kind_kind]);
			break;
		}
			
		case EXPR_NODE:
		{
			char *names[4] = {"Type Specifier,", "Expr,", "Const Declaration,", "ID Declaration," };
			char *types[4] = {"","Integer ", "Bool" , "Char"};
			char *ops[15] = {">" , ">=" , "<" , "<=" , "==" , "+" , "-" , "*" , "/" , "%" , "++" , "--" , "=","!=","'"};
	
			printf("%-20s ", names[ p->kind_kind ]);
			
				
			switch( p->kind_kind )
			{
				case TYPE_EXPR:
					{
						printf("%-20s", types[ p->type ]);
			
						printf(" ");
						break;
					}
				case OP_EXPR:
					{
						printf("op:");
						printf("%-17s ",ops[p->val]);
						break;
					}
				case CONST_EXPR:
					{
						printf("values: %-13d ",p->val);
						break;
					}
				case ID_EXPR:
					{
		
						printf("symbol: %-13s ",idtable[p->val]);
						break;
					}
			}
			break;
		}
		case DECL_NODE:
		{
			char names[2][20] = { "Var Declaration, ", "Array Declaration, "};
			printf("%-40s ",names[p->kind_kind]);
			break;
		}
	}
	printf("children:");
	if(p->lc != NULL)
	{
		printf("%d  ",p->lc->index);
		
		temp = p->lc->rc;
		
		while(temp != NULL)
		{
			printf("%d  ",temp->index);
			temp = temp->rc;
		}
	}
	printf("\n");
	return ;
}

int main(void)
{
	yyin=fopen("test.txt","r");
	if(yyin!=NULL)
		yyparse();
	fclose(yyin);
	return 1;
	
}