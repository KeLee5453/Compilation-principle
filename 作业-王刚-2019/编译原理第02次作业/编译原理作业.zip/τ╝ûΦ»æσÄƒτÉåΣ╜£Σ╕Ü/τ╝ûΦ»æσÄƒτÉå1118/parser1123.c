%{
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
#define MAX 4
enum NodeType{Stmt=0,Expr,Decl};
enum Statement{If=0,While,For,Block,Input,Output,Fuc,Return,Expr_fuc,Fuc_asked};
enum Expression{Op=0,Const,Idk,Type};
enum Declaration{Var=0,FucVar};
enum ExpType{Int=0,Char,Void,Bool};

struct TreeNode
{
  int lineno;
  struct TreeNode*child[MAX];
  struct TreeNode*brother;//由于匹配的时候可以匹配出一整句话，故可以知道其兄弟节点，但是无法知道其父节点
  int nodetype; 
  int specifictype;
  ExpType type;
  int val;
};
int NUM=0;
int line=0;
TreeNode*root;
TreeNode*createNode(int nodetype,int specifictype)
{
	TreeNode*node=(TreeNode*)malloc(sizeof(TreeNode));
	for(int i=0;i<MAX;i++)
	node->child[i]=NULL;
	node->brother=NULL;
	node->nodetype=nodetype;
	node->specifictype=specifictype;
	node->lineno=line++;
	node->type=Void;
	return node;
}
struct idNameType
{
	char *name;
	ExpType type;
};
extern idNameType ids[1000];
struct res
{
	int resLine;
	char *resStr;
};
res checkRes[100];
int resKount=0;
%}
/////////////////////////////////////////////////////////////////////////////
// declarations section
%include{
  class lexer;
 }
 
 %include{
  #include "lexer.h"
 }
// parser name
%name parser

// class definition
{
	// place any extra class members here
void showCheckRes();
void typeError(struct TreeNode* t,char *str);
void checkNode(struct TreeNode * t);
void display(struct TreeNode*node);
void shownode(struct TreeNode*node);
void output1(char *str);
}

// constructor
{
	// place any extra initialisation code here
}

// destructor
{
	// place any extra cleanup code here
}

// attribute type

%include {
#ifndef YYSTYPE
#define YYSTYPE struct TreeNode*
#endif
}

// place any declarations here
%token IF MAIN FOR WHILE CIN COUT//关键字
%token INT CHAR VOID BOOL//
%token ID NUMBER
%token PLUS MINUS MUL DIV REMI DPLUS DMINUS//操作符
%token GT LT GE LE NEQ AND OR NOT ASSIGN//逻辑关系
%token LFP RFP COMMA SEMI LP RP LM RM//标点符号
%token RETURN

%left COMMA
%right ASSIGN
%left EQ NEQ
%left LT LE GT GE
%left PLUS MINUS
%left MUL DIV REMI
%left DPLUS DMINUS
%left LP RP LSP RSP LFP RFP LM RM
%right ELSE

%%
/////////////////////////////////////////////////////////////////////////////
// rules section
start   :MAIN LP RP block  { $$=$4;root=$4;display(root);showCheckRes();}//traverse(root);}//main()
        ;
block   :LFP stmts RFP {$$=createNode(Stmt,Block);$$->child[0]=$2;}//函数体
        ;
stmts   :stmt stmts    {$$=$1;$$->brother=$2;}
        |stmt          {$$=$1;}
        ;
stmt    :expr_stmt     {$$=$1;}
        |var_stmt      {$$=$1;}//变量声明
        |if_stmt       {$$=$1;}
        |while_stmt    {$$=$1;}
        |for_stmt      {$$=$1;}
        |block         {$$=$1;}
        |input_stmt    {$$=$1;}
        |output_stmt   {$$=$1;}
        |fuc_stmt      {$$=$1;}
        |fuc_asked_stmt{$$=$1;}
        |return_stmt   {$$=$1;}
        ;
/*变量声明*/
type_var     :INT                      {$$=createNode(Expr,Type);$$->type=Int;}
             |CHAR                     {$$=createNode(Expr,Type);$$->type=Char;}
             |BOOL                     {$$=createNode(Expr,Type);$$->type=Bool;}
			 |VOID                     {$$=createNode(Expr,Type);$$->type=Void;}
			 ;
id_list      :id_expr COMMA id_list     {$$=$1;$$->brother=$3;}
			 |id_expr					{$$=$1;}
             ;
			 
id_expr      :ID ASSIGN expr           {$$=createNode(Expr,Op);$$->val=ASSIGN;$$->child[0]=$1,$$->child[1]=$3;}
			 |ID                       {$$=$1;}
			 ;
			 
var_stmt     :type_var id_list SEMI    {$$=createNode(Decl,Var);$$->child[0]=$1;$$->child[1]=$2;}//变量声明
             ; 
fuc_var      :fuc1_var COMMA fuc_var    {$$=$1;$$->brother=$3;}//函数中变量的声明
             |fuc1_var                  {$$=$1;}              
             ; 
fuc1_var     :type_var ID              {$$=createNode(Decl,FucVar);$$->child[0]=$1;$$->child[1]=$2;}
             ;     
expr_stmt    :expr SEMI				   {$$=$1;}
             |SEMI
             ;
             /*赋值*/
expr         :expr ASSIGN expr         {$$=createNode(Expr,Op);$$->val=ASSIGN;$$->child[0]=$1;$$->child[1]=$3;}//$$=createNode(Stmt,Assign)
			 |or_expr                  {$$=$1;}  
             ;
             /*与或非*/
or_expr      :or_expr OR and_expr      {$$=createNode(Expr,Op);$$->val=OR;$$->child[0]=$1;$$->child[1]=$3;}
             |and_expr                 {$$=$1;}
             ;
and_expr     :and_expr AND eq_expr     {$$=createNode(Expr,Op);$$->val=AND;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr                  {$$=$1;}
             ;
             /*>/</>=/<=*/
eq_expr      :eq_expr EQ simple_expr   {$$=createNode(Expr,Op);$$->val=EQ;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr GE simple_expr   {$$=createNode(Expr,Op);$$->val=GE;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr LE simple_expr   {$$=createNode(Expr,Op);$$->val=LE;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr GT simple_expr   {$$=createNode(Expr,Op);$$->val=GT;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr LT simple_expr   {$$=createNode(Expr,Op);$$->val=LT;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr NEQ simple_expr  {$$=createNode(Expr,Op);$$->val=NEQ;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr LM simple_expr   {$$=createNode(Expr,Op);$$->val=LM;$$->child[0]=$1;$$->child[1]=$3;}
             |eq_expr RM simple_expr   {$$=createNode(Expr,Op);$$->val=RM;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr			   {$$=$1;}
             ;
             /*+/-/*///++/--*/
simple_expr  :simple_expr PLUS term    {$$=createNode(Expr,Op);$$->val=PLUS;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr MINUS term   {$$=createNode(Expr,Op);$$->val=MINUS;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr MUL term     {$$=createNode(Expr,Op);$$->val=MUL;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr DIV term     {$$=createNode(Expr,Op);$$->val=DIV;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr REMI term    {$$=createNode(Expr,Op);$$->val=REMI;$$->child[0]=$1;$$->child[1]=$3;}
             |simple_expr DPLUS        {$$=createNode(Expr,Op);$$->val=DPLUS;$$->child[0]=$1;}
             |simple_expr DMINUS       {$$=createNode(Expr,Op);$$->val=DMINUS;$$->child[0]=$1;}
             |term					   {$$=$1;}
             ;
term         :LP expr RP               {$$=$2;}
			 |ID					   {$$=$1;}
			 |NUMBER				   {$$=$1;}
			 |NOT term                 {$$=createNode(Expr,Op);$$->val=NOT;$$->child[0]=$2;}
			 ;
/*if语句说明*/
if_stmt      :IF LP expr RP stmt       {$$=createNode(Stmt,If);$$->child[0]=$3;$$->child[1]=$5;}
             |IF LP expr RP stmt ELSE stmt {$$=createNode(Stmt,If);$3->type=Bool;$$->child[0]=$3;$$->child[1]=$5;$$->child[2]=$7;}
             ;
/*for语句说明*/
for_stmt     :FOR LP expr SEMI expr SEMI expr RP stmt {$$=createNode(Stmt,For);$$->child[0]=$3;$$->child[1]=$5;$$->child[2]=$7;$$->child[3]=$9;}
	         |FOR LP SEMI expr SEMI expr RP stmt      {$$=createNode(Stmt,For);$$->child[1]=$4;$$->child[2]=$6;$$->child[3]=$8;}  
             |FOR LP expr SEMI SEMI expr RP stmt      {$$=createNode(Stmt,For);$$->child[0]=$3;$$->child[2]=$6;$$->child[3]=$8;}  
             |FOR LP expr SEMI expr SEMI RP stmt      {$$=createNode(Stmt,For);$$->child[0]=$3;$$->child[1]=$5;$$->child[3]=$8;}  
             |FOR LP SEMI SEMI expr RP stmt			  {$$=createNode(Stmt,For);$$->child[2]=$5;$$->child[3]=$7;} 
             |FOR LP SEMI expr SEMI RP stmt			  {$$=createNode(Stmt,For);$$->child[1]=$4;$$->child[3]=$7;}
             |FOR LP expr SEMI SEMI RP stmt			  {$$=createNode(Stmt,For);$$->child[0]=$3;$$->child[3]=$7;}
             |FOR LP SEMI SEMI RP stmt				  {$$=createNode(Stmt,For);$$->child[3]=$6;}
             ;
                         
/*while语句说明*/
while_stmt   :WHILE LP expr RP stmt                   {$$=createNode(Stmt,While);$$->child[0]=$3;$$->child[1]=$5;}
             ;
/*input语句和output语句*/
input_stmt   :CIN RM ID                               {$$=createNode(Stmt,Input);$$->child[0]=$3;}
             ; 
output_stmt  :COUT LM ID							  {$$=createNode(Stmt,Output);$$->child[0]=$3;}
             ;
/*判断函数，函数声明和函数调用*/
fuc_stmt     :type_var ID LP fuc_var  RP block        {$$=createNode(Stmt,Fuc);$$->child[0]=$1;$$->child[1]=$2;$$->child[2]=$4;$$->child[3]=$6;}
             ;
fuc_asked_stmt:type_var ID ASSIGN fuc_asked1_stmt     {$$=createNode(Stmt,Fuc);$$->child[0]=$1;$$->child[1]=$2;$$->child[2]=$4;}
              |fuc_asked1_stmt                        {$$=$1;}
              ;
fuc_asked1_stmt:ID LP expr_fuc RP SEMI                {$$=createNode(Stmt,Fuc_asked);$$->child[0]=$1;$$->child[1]=$3;}
               ;
expr_fuc      :expr COMMA expr                        {$$=createNode(Stmt,Expr_fuc);$$->child[0]=$1;$$->child[1]=$3;}
              |expr                                   {$$=createNode(Stmt,Expr_fuc);$$->child[0]=$1;}
              ; 
/*返回句型*/
return_stmt  :RETURN term							  {$$=createNode(Stmt,Return);$$->child[0]=$2;}
             ;                        
// place your YACC rules here (there must be at least one)

Grammar
	: /* empty */
	;

%%

/////////////////////////////////////////////////////////////////////////////
// programs section
void parser::showCheckRes()
{
	cout<<"---------------------------------------------------"<<endl;
	for(int i=0;i<resKount;i++)
	{
		cout<<checkRes[i].resLine<<":"<<checkRes[i].resStr<<endl;
	}
}
void parser::typeError(TreeNode* t,char *str)
{
	checkRes[resKount].resLine=t->lineno;
	checkRes[resKount].resStr=str;
	resKount++;
}

void parser::checkNode(TreeNode * t)
{ 
	if(t->nodetype==Expr)
	{
      switch (t->specifictype)
      { 
		case Op:
			if (t->val==ASSIGN)
			{
				ids[t->child[0]->val].type=t->child[1]->type;
				t->child[0]->type=t->child[1]->type;
			}
			else if(t->val==AND||t->val==OR)
			{
				if((t->child[0]->type!=Bool&&t->child[0]->type!=Int&&t->child[0]->type!=Char)||
				(t->child[1]->type!=Bool&&t->child[1]->type!=Int&&t->child[1]->type!=Char)){
					typeError(t,"AND OR -- Operand is not Bool/Int/Char  ");
				}
				t->type=t->child[0]->type;
			}
			else if(t->val==NOT)
			{
				if((t->child[0]->type!=Bool&&t->child[0]->type!=Int&&t->child[0]->type!=Char))
					typeError(t,"NOT -- Operand is not Bool/Int/Char ");
				t->type=t->child[0]->type;
			}
			else if(t->val==PLUS||(t->val==MUL||t->val==REMI||t->val==DIV))
			{
				if((t->child[0]->type!=Int&&t->child[0]->type!=Char)||(t->child [1]->type!=Int&&t->child[1]->type!=Char))
					typeError(t,"PLUS MUL REMI DIV -- Operand is not Int/Char");
				if(t->child[0]->type!=t->child [1]->type )
					typeError(t,"Operand different type" );
					t->type=t->child[0]->type;
			}
			else if(t->val==MINUS)//减或负号
			{
				if(t->child[1]!=NULL)
				{  
					if((t->child[0]->type!=Int&&t->child[0]->type!=Char)||(t->child [1]->type!=Int&&t->child[1]->type!=Char))
						typeError(t,"MINUS -- Operand is not Int/Char ");
					if(t->child[0]->type !=t->child [1]->type )
						typeError(t,"Operand different type");
				}
				else 
				{
					if(t->child[0]->type!=Int&&t->child [0]->type!=Char)
						typeError(t,"MINUS -- Operand is not Int/Char ");
				}	
				t->type=t->child[0]->type;
			}
			else if(t->val==DPLUS||t->val ==DMINUS)
			{
				if(t->child[0]->type!=Int&&t->child[0]->type!=Char)
					typeError(t,"DPLUS DMINUS -- Operand is not Int/Char ");
				t->type=t->child[0]->type;
			}
			else if(t->val==EQ||t->val==GT||t->val==LT||t->val==GE||t->val==LE||t->val==NEQ)    //关系运算运算左右是integer或char
			{
				if((t->child[0]->type!=Int&&t->child[0]->type!=Char)||(t->child [1]->type!=Int&&t->child[1]->type!=Char))
					typeError(t,"关系运算符--Operand is not Int/Char");
				if(t->child[0]->type!=t->child [1]->type )
					typeError(t,"Operand different type");
				t->type=t->child[0]->type;
			}	
          break;
        default:
          break;
      }
	}
    else if(t->nodetype==Stmt)
	{
      switch (t->specifictype)
      { case If:
          if (t->child[0]->type != Bool)
            typeError(t->child[0],"IF --expr not Bool");
          break;
        case While:
          if (t->child[0]->type != Bool)
            typeError(t->child[0],"WHILE --expr not Bool");
          break;
        case For:
          if (t->child[0]!= NULL||t->child[1]!= NULL||t->child[2]!= NULL)
		  {
            if(t->child[0]->type!=Int)
				typeError(t->child[0],"FOR --child[0] is not Int");
			if(t->child[1]->type!=Bool)
				typeError(t->child[1],"FOR --child[1] is not Bool");
			if(t->child[2]->type!=Int)
				typeError(t->child[2],"FOR --child[2] is not Int");
          }
		  break;
        default:
          break;
      }
    }
}

void parser::output1(char *str)
{
	cout.setf(ios::left);
	cout<<setw(25)<<str;
	
}
void parser::display(struct TreeNode*node)//从头开始显示语法树
{
 for(int i=0;i<MAX;i++)
 {
   if(node->child[i]!=NULL)
     display(node->child[i]);//递归直到叶节点
 }
 shownode(node);
 checkNode(node);
 if(node->brother!=NULL)
 {
   display(node->brother);
 }
 return;
}
void parser::shownode(struct TreeNode*node)
{
  node->lineno=NUM++;
  cout<<node->lineno<<":";//输出行号
  switch(node->nodetype)
  {
   case Stmt:
   {
     char* names[10]={"If_statement,",  "While_statement," , "For_statement," , "Compound_statement,","Input_statement,","Output_statement,","Function_statement","Return_statement","Expression_fuction" ,"Function_asked"};
     output1(names[node->specifictype]);
     break;
   }
   case Expr:
   {
     char* names[4]={"Expr," , "Const Declaration,", "ID Declaration,","Type Specifier," };
     char* types[4]={"Int, ","Char","Void","Bool"};
     output1(names[node->specifictype]);
     switch(node->specifictype)
     {
      case Op:
      {
        switch(node->val)
        {
          case PLUS:
          {
            output1("op:+");
            break;
          }
          case MINUS:
          {
            output1("op:-");
            break;
          }
          case MUL:
          {
            output1("op:*");
            break;
          }
          case DIV:
          {
            output1("op:/");
            break;
          }
          case REMI:
          {
            output1("op:%");
            break;
          }
          case DPLUS:
          {
            output1("op:++");
            break;
          }
          case DMINUS:
          {
            output1("op:--");
            break;
          }
          case LT:
          {
            output1("op:<");
            break;
          }
          case GT:
          {
            output1("op:>");
            break;
          }
          case LE:
          {
            output1("op:<=");
            break;
          }
          case GE:
          {
            output1("op:>=");
            break;
          }
          case EQ:
          {
            output1("op:==");
            break;
          }
           case ASSIGN:
          {
            output1("op:=");
            break;
          }
          case NEQ:
          {
            output1("op:!=");
            break;
          }
          case LM:
          {
            output1("op:<<");
            break;
          }
           case RM:
          {
            output1("op:>>");
            break;
          }
          case NOT:
          {
            output1("op:!");
            break;
          }
          case OR:
          {
            output1("op:||");
            break;
          }
          case AND:
          {
            output1("op:&&");
            break;
          }
        }
          break;
       }
        case Const:
        {
			cout.setf(ios::left);
			cout<<setw(7)<<"value:"<<setw(18)<<node->val;
          break;
        }
        case Idk:
        {
			cout.setf(ios::left);
			cout<<setw(8)<<"symbol:"<<setw(17)<<ids[node->val].name;
          break;
        }
        case Type:
        {
			cout.setf(ios::left);
			cout<<setw(25)<<types[node->type];
          break;
        }
      }
      break;
     }
     case Decl:
     {
       char* names[2]={"Var Declaration, ", "Fuc Declaration"};
	   cout.setf(ios::left);
       cout<<setw(25)<<names[node->specifictype];
       break;
     }
   } 
   cout<<"children:";
   for(int i=0;i<MAX;i++)
   {
     if(node->child[i]!=NULL)
     {
       cout<<node->child[i]->lineno<<" ";
       struct TreeNode*temp=node->child[i]->brother;
       while(temp!=NULL)
       {
        cout<<temp->lineno;
        temp=temp->brother; 
       }
     }
   }
   cout<<endl;
   return;
}
int main()
{
	int n = 1;
	lexer lexer;
	parser parser;
	if (parser.yycreate(&lexer)) {
		if (lexer.yycreate(&parser)) {
			n = parser.yyparse();
		}
	}
	return n;
}