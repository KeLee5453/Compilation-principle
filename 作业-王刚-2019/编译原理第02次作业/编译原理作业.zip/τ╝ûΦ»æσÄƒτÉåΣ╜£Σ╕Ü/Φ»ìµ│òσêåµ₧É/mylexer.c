/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
* 
* You are on day 28 of your 30 day trial period.
* 
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* mylexer.c
* C source file generated from mylexer.l.
* 
* Date: 11/14/16
* Time: 19:20:39
* 
* ALex Version: 2.07
****************************************************************************/

#include <yylex.h>

/* namespaces */
#if defined(__cplusplus) && defined(YYSTDCPPLIB)
using namespace std;
#endif
#if defined(__cplusplus) && defined(YYNAMESPACE)
using namespace yl;
#endif

#define YYFASTLEXER

#line 1 ".\\mylexer.l"
 
 #include <stdio.h>
 #include <string.h>

 static int count=0;
 static int nc=0;
 double	yylval=0;
 int num_lines = 0;
 char *Ids[100];//charָ����������,��¼����
 char *Ns[100];
 
#line 52 "mylexer.c"
/* repeated because of possible precompiled header */
#include <yylex.h>

/* namespaces */
#if defined(__cplusplus) && defined(YYSTDCPPLIB)
using namespace std;
#endif
#if defined(__cplusplus) && defined(YYNAMESPACE)
using namespace yl;
#endif

#define YYFASTLEXER

#include ".\mylexer.h"

#ifndef YYTEXT_SIZE
#define YYTEXT_SIZE 100
#endif
#ifndef YYUNPUT_SIZE
#define YYUNPUT_SIZE YYTEXT_SIZE
#endif
#ifndef YYTEXT_MAX
#define YYTEXT_MAX 0
#endif
#ifndef YYUNPUT_MAX
#define YYUNPUT_MAX YYTEXT_MAX
#endif

/* yytext */
static char YYNEAR yysatext[(YYTEXT_SIZE) + 1];		/* extra char for \0 */
char YYFAR *YYNEAR YYDCDECL yystext = yysatext;
char YYFAR *YYNEAR YYDCDECL yytext = yysatext;
int YYNEAR YYDCDECL yystext_size = (YYTEXT_SIZE);
int YYNEAR YYDCDECL yytext_size = (YYTEXT_SIZE);
int YYNEAR YYDCDECL yytext_max = (YYTEXT_MAX);

/* yystatebuf */
#if (YYTEXT_SIZE) != 0
static int YYNEAR yysastatebuf[(YYTEXT_SIZE)];
int YYFAR *YYNEAR YYDCDECL yysstatebuf = yysastatebuf;
int YYFAR *YYNEAR YYDCDECL yystatebuf = yysastatebuf;
#else
int YYFAR *YYNEAR YYDCDECL yysstatebuf = NULL;
int YYFAR *YYNEAR YYDCDECL yystatebuf = NULL;
#endif

/* yyunputbuf */
#if (YYUNPUT_SIZE) != 0
static int YYNEAR yysaunputbuf[(YYUNPUT_SIZE)];
int YYFAR *YYNEAR YYDCDECL yysunputbufptr = yysaunputbuf;
int YYFAR *YYNEAR YYDCDECL yyunputbufptr = yysaunputbuf;
#else
int YYFAR *YYNEAR YYDCDECL yysunputbufptr = NULL;
int YYFAR *YYNEAR YYDCDECL yyunputbufptr = NULL;
#endif
int YYNEAR YYDCDECL yysunput_size = (YYUNPUT_SIZE);
int YYNEAR YYDCDECL yyunput_size = (YYUNPUT_SIZE);
int YYNEAR YYDCDECL yyunput_max = (YYUNPUT_MAX);

/* backwards compatability with lex */
#ifdef input
#ifdef YYPROTOTYPE
int YYCDECL yyinput(void)
#else
int YYCDECL yyinput()
#endif
{
	return input();
}
#else
#define input yyinput
#endif

#ifdef output
#ifdef YYPROTOTYPE
void YYCDECL yyoutput(int ch)
#else
void YYCDECL yyoutput(ch)
int ch;
#endif
{
	output(ch);
}
#else
#define output yyoutput
#endif

#ifdef unput
#ifdef YYPROTOTYPE
void YYCDECL yyunput(int ch)
#else
void YYCDECL yyunput(ch)
int ch;
#endif
{
	unput(ch);
}
#else
#define unput yyunput
#endif

#ifndef YYNBORLANDWARN
#ifdef __BORLANDC__
#pragma warn -rch		/* <warning: unreachable code> off */
#endif
#endif

#ifdef YYPROTOTYPE
int YYCDECL yylexeraction(int action)
#else
int YYCDECL yylexeraction(action)
int action;
#endif
{
	yyreturnflg = YYTRUE;
	switch (action) {
	case 1:
		{
#line 43 ".\\mylexer.l"
num_lines++;
#line 173 "mylexer.c"
		}
		break;
	case 2:
		{
#line 44 ".\\mylexer.l"
/* skip whitespace */
#line 180 "mylexer.c"
		}
		break;
#line 45 ".\\mylexer.l"
		
#line 185 "mylexer.c"
	case 3:
		{
#line 46 ".\\mylexer.l"
printf("INT\t\tint\n");
#line 190 "mylexer.c"
		}
		break;
	case 4:
		{
#line 47 ".\\mylexer.l"
printf("CHAR\t\tchar\n");
#line 197 "mylexer.c"
		}
		break;
	case 5:
		{
#line 48 ".\\mylexer.l"
printf("DOUBLE\t\tdouble\n");
#line 204 "mylexer.c"
		}
		break;
	case 6:
		{
#line 49 ".\\mylexer.l"
printf("FLOAT\t\tfloat\n");
#line 211 "mylexer.c"
		}
		break;
	case 7:
		{
#line 51 ".\\mylexer.l"
printf("IF\t\tif\n");
#line 218 "mylexer.c"
		}
		break;
	case 8:
		{
#line 52 ".\\mylexer.l"
printf("ELSE\t\telse\n");
#line 225 "mylexer.c"
		}
		break;
	case 9:
		{
#line 54 ".\\mylexer.l"
printf("FOR\t\tfor\n");
#line 232 "mylexer.c"
		}
		break;
	case 10:
		{
#line 55 ".\\mylexer.l"
printf("DO\t\tdo\n");
#line 239 "mylexer.c"
		}
		break;
	case 11:
		{
#line 56 ".\\mylexer.l"
printf("WHILE\t\twhile\n");
#line 246 "mylexer.c"
		}
		break;
	case 12:
		{
#line 58 ".\\mylexer.l"
printf("SWITCH\t\tswitch\n");
#line 253 "mylexer.c"
		}
		break;
	case 13:
		{
#line 59 ".\\mylexer.l"
printf("CASE\t\tcase\n");
#line 260 "mylexer.c"
		}
		break;
	case 14:
		{
#line 60 ".\\mylexer.l"
printf("BREAK\t\tbreak\n");
#line 267 "mylexer.c"
		}
		break;
	case 15:
		{
#line 61 ".\\mylexer.l"
printf("DEFAULT\t\tdefault\n");
#line 274 "mylexer.c"
		}
		break;
	case 16:
		{
#line 62 ".\\mylexer.l"
printf("CONTINUE\t\tcontinue\n");
#line 281 "mylexer.c"
		}
		break;
	case 17:
		{
#line 64 ".\\mylexer.l"
printf("TRUE\t\ttrue\n");
#line 288 "mylexer.c"
		}
		break;
	case 18:
		{
#line 65 ".\\mylexer.l"
printf("FALSE\t\tfalse\n");
#line 295 "mylexer.c"
		}
		break;
	case 19:
		{
#line 66 ".\\mylexer.l"
printf("RETURN\t\treturn\n");
#line 302 "mylexer.c"
		}
		break;
	case 20:
		{
#line 68 ".\\mylexer.l"
printf("LBRACE\t\t%s \n",yytext);
#line 309 "mylexer.c"
		}
		break;
	case 21:
		{
#line 69 ".\\mylexer.l"
printf("RBRACE\t\t%s \n",yytext);
#line 316 "mylexer.c"
		}
		break;
	case 22:
		{
#line 70 ".\\mylexer.l"
printf("LPAREN\t\t%s \n",yytext);
#line 323 "mylexer.c"
		}
		break;
	case 23:
		{
#line 71 ".\\mylexer.l"
printf("RPAREN\t\t%s \n",yytext);
#line 330 "mylexer.c"
		}
		break;
	case 24:
		{
#line 72 ".\\mylexer.l"
printf("SIMI\t\t%s \n",yytext);
#line 337 "mylexer.c"
		}
		break;
	case 25:
		{
#line 74 ".\\mylexer.l"
printf("PLUS\t\t%s \n",yytext);
#line 344 "mylexer.c"
		}
		break;
	case 26:
		{
#line 75 ".\\mylexer.l"
printf("MINUS\t\t%s \n",yytext);
#line 351 "mylexer.c"
		}
		break;
	case 27:
		{
#line 76 ".\\mylexer.l"
printf("MUL\t\t%s \n",yytext);
#line 358 "mylexer.c"
		}
		break;
	case 28:
		{
#line 77 ".\\mylexer.l"
printf("DIV\t\t%s \n",yytext);
#line 365 "mylexer.c"
		}
		break;
	case 29:
		{
#line 78 ".\\mylexer.l"
printf("MOD\t\t%s \n",yytext);
#line 372 "mylexer.c"
		}
		break;
	case 30:
		{
#line 80 ".\\mylexer.l"
printf("ASSIGN\t\t%s \n",yytext);
#line 379 "mylexer.c"
		}
		break;
	case 31:
		{
#line 81 ".\\mylexer.l"
printf("EQ\t\t%s \n",yytext);
#line 386 "mylexer.c"
		}
		break;
	case 32:
		{
#line 82 ".\\mylexer.l"
printf("LE\t\t%s \n",yytext);
#line 393 "mylexer.c"
		}
		break;
	case 33:
		{
#line 83 ".\\mylexer.l"
printf("LT\t\t%s \n",yytext);
#line 400 "mylexer.c"
		}
		break;
	case 34:
		{
#line 84 ".\\mylexer.l"
printf("NE\t\t\t%s \n",yytext);
#line 407 "mylexer.c"
		}
		break;
	case 35:
		{
#line 85 ".\\mylexer.l"
printf("GT\t\t%s \n",yytext);
#line 414 "mylexer.c"
		}
		break;
	case 36:
		{
#line 86 ".\\mylexer.l"
printf("GE\t\t%s \n",yytext);
#line 421 "mylexer.c"
		}
		break;
	case 37:
		{
#line 88 ".\\mylexer.l"
printf("AND\t\t%s \n",yytext);
#line 428 "mylexer.c"
		}
		break;
	case 38:
		{
#line 89 ".\\mylexer.l"
printf("OR\t\t%s \n",yytext);
#line 435 "mylexer.c"
		}
		break;
	case 39:
		{
#line 90 ".\\mylexer.l"
printf("NOT\t\t%s \n",yytext);
#line 442 "mylexer.c"
		}
		break;
	case 40:
		{
#line 92 ".\\mylexer.l"
char *str=yytext;
           printf("NUMBER\t\t%s\t\t%d\n",yytext,installNUM(str));
#line 450 "mylexer.c"
		}
		break;
	case 41:
		{
#line 94 ".\\mylexer.l"
char *string=yytext;
			printf("ID\t\t%s\t\t%d\n",string,installID(string));
#line 458 "mylexer.c"
		}
		break;
	default:
		yyassert(0);
		break;
	}
	yyreturnflg = YYFALSE;
	return 0;
}

#ifndef YYNBORLANDWARN
#ifdef __BORLANDC__
#pragma warn .rch		/* <warning: unreachable code> to the old state */
#endif
#endif
YYCONST yymatch_t YYNEARFAR YYBASED_CODE YYDCDECL yymatch[] = {
	0
};

int YYNEAR YYDCDECL yytransitionmax = 207;
YYCONST yytransition_t YYNEARFAR YYBASED_CODE YYDCDECL yytransition[] = {
	{ 0, 0 },
	{ 3, 1 },
	{ 4, 1 },
	{ 3, 3 },
	{ 46, 23 },
	{ 47, 24 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 57, 57 },
	{ 48, 24 },
	{ 37, 16 },
	{ 44, 22 },
	{ 49, 24 },
	{ 58, 36 },
	{ 38, 17 },
	{ 58, 36 },
	{ 50, 25 },
	{ 3, 1 },
	{ 5, 1 },
	{ 3, 3 },
	{ 36, 57 },
	{ 45, 22 },
	{ 6, 1 },
	{ 7, 1 },
	{ 51, 25 },
	{ 8, 1 },
	{ 9, 1 },
	{ 10, 1 },
	{ 11, 1 },
	{ 52, 26 },
	{ 12, 1 },
	{ 53, 27 },
	{ 13, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 14, 1 },
	{ 41, 21 },
	{ 15, 1 },
	{ 16, 1 },
	{ 17, 1 },
	{ 18, 1 },
	{ 54, 28 },
	{ 55, 29 },
	{ 42, 21 },
	{ 56, 31 },
	{ 0, 35 },
	{ 39, 18 },
	{ 60, 40 },
	{ 61, 41 },
	{ 35, 14 },
	{ 43, 21 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 14, 14 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 59, 59 },
	{ 62, 42 },
	{ 63, 43 },
	{ 64, 44 },
	{ 65, 45 },
	{ 66, 46 },
	{ 20, 1 },
	{ 21, 1 },
	{ 22, 1 },
	{ 23, 1 },
	{ 24, 1 },
	{ 67, 47 },
	{ 68, 48 },
	{ 25, 1 },
	{ 69, 49 },
	{ 70, 51 },
	{ 71, 52 },
	{ 72, 53 },
	{ 73, 54 },
	{ 74, 55 },
	{ 40, 20 },
	{ 34, 7 },
	{ 26, 1 },
	{ 27, 1 },
	{ 28, 1 },
	{ 75, 60 },
	{ 76, 61 },
	{ 29, 1 },
	{ 77, 62 },
	{ 78, 63 },
	{ 79, 64 },
	{ 30, 1 },
	{ 31, 1 },
	{ 32, 1 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 80, 65 },
	{ 81, 66 },
	{ 82, 67 },
	{ 83, 68 },
	{ 84, 71 },
	{ 85, 72 },
	{ 86, 73 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 87, 74 },
	{ 88, 75 },
	{ 89, 78 },
	{ 90, 79 },
	{ 19, 104 },
	{ 91, 80 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 19, 104 },
	{ 92, 82 },
	{ 93, 83 },
	{ 94, 84 },
	{ 95, 85 },
	{ 96, 87 },
	{ 97, 89 },
	{ 98, 90 },
	{ 99, 91 },
	{ 100, 94 },
	{ 101, 95 },
	{ 102, 97 },
	{ 103, 98 },
	{ 104, 102 },
	{ 33, 5 }
};

YYCONST yystate_t YYNEARFAR YYBASED_CODE YYDCDECL yystate[] = {
	{ 0, 0, 0 },
	{ 104, -8, 0 },
	{ 1, 0, 0 },
	{ 0, -6, 2 },
	{ 0, 0, 1 },
	{ 0, 145, 39 },
	{ 0, 0, 29 },
	{ 0, 67, 0 },
	{ 0, 0, 22 },
	{ 0, 0, 23 },
	{ 0, 0, 27 },
	{ 0, 0, 25 },
	{ 0, 0, 26 },
	{ 0, 0, 28 },
	{ 57, 17, 40 },
	{ 0, 0, 24 },
	{ 0, -44, 33 },
	{ 0, -40, 30 },
	{ 0, -1, 35 },
	{ 104, 0, 41 },
	{ 104, -10, 41 },
	{ 104, -47, 41 },
	{ 104, -83, 41 },
	{ 104, -104, 41 },
	{ 104, -92, 41 },
	{ 104, -79, 41 },
	{ 104, -65, 41 },
	{ 104, -81, 41 },
	{ 104, -59, 41 },
	{ 104, -48, 41 },
	{ 0, 0, 20 },
	{ 0, -66, 0 },
	{ 0, 0, 21 },
	{ 0, 0, 34 },
	{ 0, 0, 37 },
	{ 57, -10, 0 },
	{ 59, -23, 0 },
	{ 0, 0, 32 },
	{ 0, 0, 31 },
	{ 0, 0, 36 },
	{ 104, -40, 41 },
	{ 104, -53, 41 },
	{ 104, -12, 41 },
	{ 104, -24, 41 },
	{ 104, -15, 41 },
	{ 104, -29, 10 },
	{ 104, -26, 41 },
	{ 104, -13, 41 },
	{ 104, -15, 41 },
	{ 104, -16, 41 },
	{ 104, 0, 7 },
	{ 104, -17, 41 },
	{ 104, -16, 41 },
	{ 104, -4, 41 },
	{ 104, -15, 41 },
	{ 104, -2, 41 },
	{ 0, 0, 38 },
	{ 0, -42, 40 },
	{ 59, 0, 0 },
	{ 0, 27, 40 },
	{ 104, 12, 41 },
	{ 104, 9, 41 },
	{ 104, -2, 41 },
	{ 104, -3, 41 },
	{ 104, 17, 41 },
	{ 104, 30, 41 },
	{ 104, 28, 41 },
	{ 104, 15, 41 },
	{ 104, 34, 41 },
	{ 104, 0, 9 },
	{ 104, 0, 3 },
	{ 104, 15, 41 },
	{ 104, 17, 41 },
	{ 104, 33, 41 },
	{ 104, 53, 41 },
	{ 104, 55, 41 },
	{ 104, 0, 13 },
	{ 104, 0, 4 },
	{ 104, 58, 41 },
	{ 104, 47, 41 },
	{ 104, 58, 41 },
	{ 104, 0, 8 },
	{ 104, 92, 41 },
	{ 104, 78, 41 },
	{ 104, 81, 41 },
	{ 104, 97, 41 },
	{ 104, 0, 17 },
	{ 104, 96, 41 },
	{ 104, 0, 14 },
	{ 104, 88, 41 },
	{ 104, 91, 41 },
	{ 104, 99, 41 },
	{ 104, 0, 18 },
	{ 104, 0, 6 },
	{ 104, 91, 41 },
	{ 104, 98, 41 },
	{ 104, 0, 11 },
	{ 104, 86, 41 },
	{ 104, 88, 41 },
	{ 104, 0, 5 },
	{ 104, 0, 19 },
	{ 104, 0, 12 },
	{ 104, 104, 41 },
	{ 104, 0, 15 },
	{ 0, 70, 16 }
};

YYCONST yybackup_t YYNEARFAR YYBASED_CODE YYDCDECL yybackup[] = {
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
};

#line 96 ".\\mylexer.l"



int check(char *word)
{
	for(int i=0;i<count;i++)
	{
	
		if(strcmp(Ids[i],word)==0)//���ֹ�
			return i;
	}
	return -1;
}
int installID(char *word)
{
	int retn=check(word);
	if(retn==-1){
		retn=count;
		int n=strlen(word)+1;
		Ids[count]=(char*)malloc(n*sizeof(char));
		strcpy_s(Ids[count],n,word);
		count=count+1;
		}
	return retn;
}

int checkn(char *name)
{
    for(int j=0;j<nc;j++)
	{
		if(strcmp(Ns[j],name)==0)//���ֹ�
			return j;
	}
	return -1;
}
int installNUM(char *name)
{
    int rn=checkn(name);
    if(rn==-1){
        rn=nc;
        int m=strlen(name)+1;
		Ns[nc]=(char*)malloc(m*sizeof(char));
		strcpy_s(Ns[nc],m,name);
		nc=nc+1;
		}
	return rn;
         
}

int main(int argc,char *argv[])
{ 
	printf("����\t\t����\t\t����\n");
	errno_t err;//errno_t��һ���������ͣ�ʵ������һ�����Σ������������
	if ( argc > 0){
	err=fopen_s(&yyin,argv[1], "r" );
	}
	yylex();
	return 0;
}

