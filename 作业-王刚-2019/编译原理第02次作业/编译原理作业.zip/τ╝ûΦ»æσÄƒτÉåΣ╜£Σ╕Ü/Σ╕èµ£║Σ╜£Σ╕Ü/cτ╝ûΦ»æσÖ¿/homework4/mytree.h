#pragma once
#include<iostream>
#include<string>
#include<string.h>
#include<map>
using namespace std;
enum allstation
{
	STMT=0,
	EXP,DECL
};
enum decl_type
{
	VAR_DECL=0,
	ID_DECL,TYPE_DECL
};
enum TYPE
{
	Char = 0,
	Int, Bool
};
enum stmt_type
{
	VAR_DEC=0,
	EXP_STMT,IF_STMT,FOR_STMT,COMP_STMT,WHILE_STMT
};
enum exp_type
{
	ASSIGN_EXP=0,
	COMP_EXP,OP_EXP
};
//string Type[3]={ "CHAR","INT","BOOL" };
//string Decl[3] = { "VAR_DECL","ID_DECL,TYPE_DECL" };
//string stmt[6] = { "VAR_DEC","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
//string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP" };
struct IDtable
{
	string name;
	double value;
	string type;
};
struct treenode
{
	string begin_label;
	string next_label;
	string true_label;
	string false_label;
	int temp_var;
	int nodetype;
	int type_type;
	int wordtype;
	int IDaddr;
	int val;
	int linenum;
	int nodenum;
	string op;
	string mykind;
	treenode *childlist;
	treenode *bro;
	char constchar;
};
class mytree
{
	int linenu;
	int nodenu;
	struct treenode *start;
	struct treenode *now;
public:
	mytree();
	treenode *creatnode(int node_type ,int type_type,string op,int wordtype, int ID_addr,treenode *child0,treenode *child1,treenode * child2, char constchar = 'a');
	treenode *createnode(int node_type, int type_type, string op, int wordtype, int ID_addr, treenode *child0, treenode *child1, treenode * child2,treenode *child3);
	void DFS(treenode *node);
	void shownode(treenode * node);
	void startshow(treenode* node);
	int addID(string a);
	int getnum(char *str);
	void stmt_code(ostream &out, treenode *t);
	void expr_gen_code(ostream &out, treenode *t);
	void gen_header(ostream &out);
	void gen_code(ostream &out,treenode *root);
	void gen_decl(ostream &out, treenode *t);
	void recursive_gen_code(ostream &out, treenode *t);
	void get_temp_var(treenode *t);
	void stmt_get_label(treenode *t);
	void expr_get_label(treenode *t);
	void recursive_get_label(treenode *root);
	~mytree();
};

