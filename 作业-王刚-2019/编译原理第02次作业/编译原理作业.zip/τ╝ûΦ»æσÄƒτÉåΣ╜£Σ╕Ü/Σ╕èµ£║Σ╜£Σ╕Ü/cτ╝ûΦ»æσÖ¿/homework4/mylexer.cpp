/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
* 
* You are on day 103 of your 30 day trial period.
* 
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* mylexer.cpp
* C++ source file generated from mylexer.l.
* 
* Date: 01/01/19
* Time: 12:40:13
* 
* ALex Version: 2.07
****************************************************************************/

#include <yyclex.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#line 1 ".\\mylexer.l"

/****************************************************************************
mylexer.l
ParserWizard generated Lex file.

Date: 2018��11��22��
****************************************************************************/
#ifndef MY_H_FILE
#define MY_H_FILE
#include "myparser.h"
#include "mytree.h"
#include<iostream>
#endif
using namespace std;
extern IDtable mytable[1000];
treenode *node;
extern mytree m1;
extern int tableuse;

#line 58 "mylexer.cpp"
// repeated because of possible precompiled header
#include <yyclex.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#include ".\mylexer.h"

/////////////////////////////////////////////////////////////////////////////
// constructor

YYLEXERNAME::YYLEXERNAME()
{
	yytables();
#line 33 ".\\mylexer.l"

	// place any extra initialisation code here

#line 82 "mylexer.cpp"
}

/////////////////////////////////////////////////////////////////////////////
// destructor

YYLEXERNAME::~YYLEXERNAME()
{
#line 38 ".\\mylexer.l"

	// place any extra cleanup code here

#line 94 "mylexer.cpp"
}

#ifndef YYTEXT_SIZE
#define YYTEXT_SIZE 100
#endif
#ifndef YYUNPUT_SIZE
#define YYUNPUT_SIZE YYTEXT_SIZE
#endif
#ifndef YYTEXT_MAX
#define YYTEXT_MAX 0
#endif
#ifndef YYUNPUT_MAX
#define YYUNPUT_MAX YYTEXT_MAX
#endif

/****************************************************************************
* N O T E
* 
* If the compiler generates a YYLEXERNAME error then you have not declared
* the name of the lexical analyser. The easiest way to do this is to use a
* name declaration. This is placed in the declarations section of your Lex
* source file and is introduced with the %name keyword. For instance, the
* following name declaration declares the lexer mylexer:
* 
* %name mylexer
* 
* For more information see help.
****************************************************************************/

// backwards compatability with lex
#ifdef input
int YYLEXERNAME::yyinput()
{
	return input();
}
#else
#define input yyinput
#endif

#ifdef output
void YYLEXERNAME::yyoutput(int ch)
{
	output(ch);
}
#else
#define output yyoutput
#endif

#ifdef unput
void YYLEXERNAME::yyunput(int ch)
{
	unput(ch);
}
#else
#define unput yyunput
#endif

#ifndef YYNBORLANDWARN
#ifdef __BORLANDC__
#pragma warn -rch		// <warning: unreachable code> off
#endif
#endif

int YYLEXERNAME::yyaction(int action)
{
#line 55 ".\\mylexer.l"
	// extract yylval for use later on in actions
	YYSTYPE YYFAR& yylval = *(YYSTYPE YYFAR*)yyparserptr->yylvalptr;

#line 165 "mylexer.cpp"
	yyreturnflg = yytrue;
	switch (action) {
	case 1:
		{
#line 61 ".\\mylexer.l"

#line 172 "mylexer.cpp"
		}
		break;
	case 2:
		{
#line 62 ".\\mylexer.l"
return MAIN;
#line 179 "mylexer.cpp"
		}
		break;
	case 3:
		{
#line 63 ".\\mylexer.l"
return INT;
#line 186 "mylexer.cpp"
		}
		break;
	case 4:
		{
#line 64 ".\\mylexer.l"
return CHAR;
#line 193 "mylexer.cpp"
		}
		break;
	case 5:
		{
#line 65 ".\\mylexer.l"
return VOID;
#line 200 "mylexer.cpp"
		}
		break;
	case 6:
		{
#line 66 ".\\mylexer.l"
return BOOL;
#line 207 "mylexer.cpp"
		}
		break;
	case 7:
		{
#line 67 ".\\mylexer.l"
return DOUBLE;
#line 214 "mylexer.cpp"
		}
		break;
	case 8:
		{
#line 69 ".\\mylexer.l"
return PLUS;
#line 221 "mylexer.cpp"
		}
		break;
	case 9:
		{
#line 70 ".\\mylexer.l"
return MINUS;
#line 228 "mylexer.cpp"
		}
		break;
	case 10:
		{
#line 71 ".\\mylexer.l"
return MUL;
#line 235 "mylexer.cpp"
		}
		break;
	case 11:
		{
#line 72 ".\\mylexer.l"
return DIV;
#line 242 "mylexer.cpp"
		}
		break;
	case 12:
		{
#line 73 ".\\mylexer.l"
return ASSIGN;
#line 249 "mylexer.cpp"
		}
		break;
	case 13:
		{
#line 75 ".\\mylexer.l"
return LBRACE;
#line 256 "mylexer.cpp"
		}
		break;
	case 14:
		{
#line 76 ".\\mylexer.l"
return RBRACE;
#line 263 "mylexer.cpp"
		}
		break;
	case 15:
		{
#line 77 ".\\mylexer.l"
return LPRACE;
#line 270 "mylexer.cpp"
		}
		break;
	case 16:
		{
#line 78 ".\\mylexer.l"
return RPRACE;
#line 277 "mylexer.cpp"
		}
		break;
	case 17:
		{
#line 79 ".\\mylexer.l"
return LSBRACE;
#line 284 "mylexer.cpp"
		}
		break;
	case 18:
		{
#line 80 ".\\mylexer.l"
return RSBRACE;
#line 291 "mylexer.cpp"
		}
		break;
	case 19:
		{
#line 81 ".\\mylexer.l"
return SIMICOLON;
#line 298 "mylexer.cpp"
		}
		break;
	case 20:
		{
#line 82 ".\\mylexer.l"
return COMMA;
#line 305 "mylexer.cpp"
		}
		break;
	case 21:
		{
#line 85 ".\\mylexer.l"
return EQ;
#line 312 "mylexer.cpp"
		}
		break;
	case 22:
		{
#line 86 ".\\mylexer.l"
return GT;
#line 319 "mylexer.cpp"
		}
		break;
	case 23:
		{
#line 87 ".\\mylexer.l"
return LT;
#line 326 "mylexer.cpp"
		}
		break;
	case 24:
		{
#line 88 ".\\mylexer.l"
return GE;
#line 333 "mylexer.cpp"
		}
		break;
	case 25:
		{
#line 89 ".\\mylexer.l"
return LE;
#line 340 "mylexer.cpp"
		}
		break;
	case 26:
		{
#line 90 ".\\mylexer.l"
return NEQ;
#line 347 "mylexer.cpp"
		}
		break;
	case 27:
		{
#line 92 ".\\mylexer.l"
return IF;
#line 354 "mylexer.cpp"
		}
		break;
	case 28:
		{
#line 93 ".\\mylexer.l"
return ELSE;
#line 361 "mylexer.cpp"
		}
		break;
	case 29:
		{
#line 94 ".\\mylexer.l"
return WHILE;
#line 368 "mylexer.cpp"
		}
		break;
	case 30:
		{
#line 95 ".\\mylexer.l"
return DO;
#line 375 "mylexer.cpp"
		}
		break;
	case 31:
		{
#line 96 ".\\mylexer.l"
return FOR;
#line 382 "mylexer.cpp"
		}
		break;
	case 32:
		{
#line 97 ".\\mylexer.l"
return BREAK;
#line 389 "mylexer.cpp"
		}
		break;
	case 33:
		{
#line 98 ".\\mylexer.l"
return RETURN;
#line 396 "mylexer.cpp"
		}
		break;
	case 34:
		{
#line 100 ".\\mylexer.l"
return CIN;
#line 403 "mylexer.cpp"
		}
		break;
	case 35:
		{
#line 101 ".\\mylexer.l"
return COUT;
#line 410 "mylexer.cpp"
		}
		break;
	case 36:
		{
#line 102 ".\\mylexer.l"
return SHL;
#line 417 "mylexer.cpp"
		}
		break;
	case 37:
		{
#line 103 ".\\mylexer.l"
return SHR;
#line 424 "mylexer.cpp"
		}
		break;
	case 38:
		{
#line 108 ".\\mylexer.l"
   node=new treenode;
                   yylval=node;
                   yylval->constchar=yytext[1];
                   return CONSTCHAR;
                   
#line 435 "mylexer.cpp"
		}
		break;
#line 113 ".\\mylexer.l"
 
#line 440 "mylexer.cpp"
	case 39:
		{
#line 114 ".\\mylexer.l"

               node=new treenode;
               int flag=m1.addID(yytext);
               int address;
               if(flag==-1)  address=tableuse-1;
               else address=flag;
               mytable[address].type="";
               yylval=node;
               yylval->IDaddr=address; 
               return ID;
               
#line 455 "mylexer.cpp"
		}
		break;
	case 40:
		{
#line 125 ".\\mylexer.l"

             node=new treenode;
             yylval=node;
             yylval->val=m1.getnum(yytext);
             return NUMBER;
            
#line 467 "mylexer.cpp"
		}
		break;
	case 41:
		{
#line 131 ".\\mylexer.l"

#line 474 "mylexer.cpp"
		}
		break;
	default:
		yyassert(0);
		break;
	}
	yyreturnflg = yyfalse;
	return 0;
}

#ifndef YYNBORLANDWARN
#ifdef __BORLANDC__
#pragma warn .rch		// <warning: unreachable code> to the old state
#endif
#endif

void YYLEXERNAME::yytables()
{
	yystext_size = YYTEXT_SIZE;
	yysunput_size = YYUNPUT_SIZE;
	yytext_max = YYTEXT_MAX;
	yyunput_max = YYUNPUT_MAX;

	static const yymatch_t YYNEARFAR YYBASED_CODE match[] = {
		0
	};
	yymatch = match;

	yytransitionmax = 236;
	static const yytransition_t YYNEARFAR YYBASED_CODE transition[] = {
		{ 0, 0 },
		{ 4, 1 },
		{ 4, 1 },
		{ 41, 18 },
		{ 42, 18 },
		{ 4, 1 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 58, 58 },
		{ 51, 27 },
		{ 4, 4 },
		{ 4, 4 },
		{ 45, 23 },
		{ 46, 23 },
		{ 4, 4 },
		{ 38, 16 },
		{ 39, 16 },
		{ 52, 27 },
		{ 5, 1 },
		{ 47, 23 },
		{ 37, 58 },
		{ 59, 37 },
		{ 50, 26 },
		{ 59, 37 },
		{ 6, 1 },
		{ 7, 1 },
		{ 8, 1 },
		{ 9, 1 },
		{ 10, 1 },
		{ 11, 1 },
		{ 12, 1 },
		{ 34, 5 },
		{ 13, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 14, 1 },
		{ 53, 28 },
		{ 15, 1 },
		{ 16, 1 },
		{ 17, 1 },
		{ 18, 1 },
		{ 54, 29 },
		{ 55, 30 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 20, 1 },
		{ 56, 31 },
		{ 21, 1 },
		{ 57, 35 },
		{ 19, 1 },
		{ 0, 36 },
		{ 19, 1 },
		{ 22, 1 },
		{ 23, 1 },
		{ 24, 1 },
		{ 25, 1 },
		{ 26, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 27, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 28, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 29, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 30, 1 },
		{ 31, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 19, 1 },
		{ 32, 1 },
		{ 0, 6 },
		{ 33, 1 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 43, 22 },
		{ 61, 43 },
		{ 62, 44 },
		{ 44, 22 },
		{ 63, 45 },
		{ 64, 46 },
		{ 65, 47 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 66, 48 },
		{ 67, 49 },
		{ 68, 50 },
		{ 69, 52 },
		{ 19, 89 },
		{ 70, 53 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 19, 89 },
		{ 36, 14 },
		{ 71, 54 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 14, 14 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 60, 60 },
		{ 72, 55 },
		{ 73, 56 },
		{ 40, 17 },
		{ 48, 24 },
		{ 74, 61 },
		{ 75, 62 },
		{ 76, 63 },
		{ 77, 65 },
		{ 78, 66 },
		{ 79, 67 },
		{ 80, 70 },
		{ 81, 71 },
		{ 82, 72 },
		{ 83, 73 },
		{ 84, 75 },
		{ 85, 78 },
		{ 86, 81 },
		{ 87, 83 },
		{ 88, 85 },
		{ 89, 86 },
		{ 49, 25 }
	};
	yytransition = transition;

	static const yystate_t YYNEARFAR YYBASED_CODE state[] = {
		{ 0, 0, 0 },
		{ -3, -8, 0 },
		{ 1, 0, 0 },
		{ 0, 0, 41 },
		{ 0, 8, 1 },
		{ 0, -23, 41 },
		{ -35, 106, 41 },
		{ 0, 0, 15 },
		{ 0, 0, 16 },
		{ 0, 0, 10 },
		{ 0, 0, 8 },
		{ 0, 0, 20 },
		{ 0, 0, 9 },
		{ 0, 0, 11 },
		{ 58, 147, 40 },
		{ 0, 0, 19 },
		{ 0, -38, 23 },
		{ 0, 156, 12 },
		{ 0, -58, 22 },
		{ 89, 0, 39 },
		{ 0, 0, 17 },
		{ 0, 0, 18 },
		{ 89, 17, 39 },
		{ 89, -85, 39 },
		{ 89, 107, 39 },
		{ 89, 127, 39 },
		{ 89, -82, 39 },
		{ 89, -86, 39 },
		{ 89, -47, 39 },
		{ 89, -46, 39 },
		{ 89, -55, 39 },
		{ 89, -20, 39 },
		{ 0, 0, 13 },
		{ 0, 0, 14 },
		{ 0, 0, 26 },
		{ 0, 47, 0 },
		{ 58, 19, 0 },
		{ 60, -15, 0 },
		{ 0, 0, 36 },
		{ 0, 0, 25 },
		{ 0, 0, 21 },
		{ 0, 0, 24 },
		{ 0, 0, 37 },
		{ 89, 18, 39 },
		{ 89, 29, 39 },
		{ 89, 35, 39 },
		{ 89, 23, 39 },
		{ 89, 17, 39 },
		{ 89, 44, 30 },
		{ 89, 47, 39 },
		{ 89, 49, 39 },
		{ 89, 0, 27 },
		{ 89, 48, 39 },
		{ 89, 61, 39 },
		{ 89, 78, 39 },
		{ 89, 110, 39 },
		{ 89, 111, 39 },
		{ 0, 0, 38 },
		{ 0, -42, 40 },
		{ 60, 0, 0 },
		{ 0, 157, 40 },
		{ 89, 111, 39 },
		{ 89, 123, 39 },
		{ 89, 107, 39 },
		{ 89, 0, 34 },
		{ 89, 106, 39 },
		{ 89, 125, 39 },
		{ 89, 123, 39 },
		{ 89, 0, 31 },
		{ 89, 0, 3 },
		{ 89, 115, 39 },
		{ 89, 109, 39 },
		{ 89, 127, 39 },
		{ 89, 120, 39 },
		{ 89, 0, 6 },
		{ 89, 122, 39 },
		{ 89, 0, 4 },
		{ 89, 0, 35 },
		{ 89, 122, 39 },
		{ 89, 0, 28 },
		{ 89, 0, 2 },
		{ 89, 117, 39 },
		{ 89, 0, 5 },
		{ 89, 131, 39 },
		{ 89, 0, 32 },
		{ 89, 132, 39 },
		{ 89, 124, 39 },
		{ 89, 0, 29 },
		{ 89, 0, 7 },
		{ 0, 70, 33 }
	};
	yystate = state;

	static const yybackup_t YYNEARFAR YYBASED_CODE backup[] = {
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	};
	yybackup = backup;
}
#line 132 ".\\mylexer.l"


/////////////////////////////////////////////////////////////////////////////
// programs section


