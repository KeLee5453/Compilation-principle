#include "mytree.h"
//enum allstation
//{
//	STMT = 0,
//	EXP, DECL
//};
//enum decl_type
//{
//	VAR_DECL = 0,
//	ID_DECL, TYPE_DECL
//};
//enum TYPE
//{
//	Char = 0,
//	Int, Bool
//};
//enum stmt_type
//{
//	VAR_DEC = 0,
//	EXP_STMT, IF_STMT, FOR_STMT, COMP_STMT, WHILE_STMT
//};
//enum exp_type
//{
//	ASSIGN_EXP = 0,
//	COMP_EXP, OP_EXP
//};

//string Type[3] = { "CHAR","INT","BOOL" };
//string Decl[3] = { "VAR_DECL","ID_DECL,TYPE_DECL" };
//string stmt[6] = { "VAR_DEC","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
//string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP" };
mytree m1;
IDtable mytable[1000];
int tableuse = 0;
int temp_var_seq = 0;
int label_count = 0;
mytree::mytree()
{
	nodenu = 0;
	start = new struct treenode;
	start->childlist = NULL;
	now = start;
}


mytree::~mytree()
{
}

int mytree::getnum(char *str)
{
	int tempnum=0;
	for (int i = 0; i < (int)strlen(str); i++)
	{
		tempnum = tempnum * 10 + str[i] - '0';
	}
	return tempnum;
}
treenode * mytree::creatnode(int node_type, int type_type, string op, int wordtype, int ID_addr, treenode *child0, treenode *child1, treenode * child2,char constchar)
{
	string Type[3] = { "CHAR","INT","BOOL" };
	string Decl[3] = { "VAR_DECL","ID_DECL,TYPE_DECL" };
	string stmt[6] = { "VAR_DEC","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
	string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP" };
	struct treenode *node = new treenode;
	if (node == NULL) cout << "����" << endl;
	else
	{
		node->nodetype = node_type;
		node->type_type = type_type;
		node->IDaddr = ID_addr;
		node->wordtype = wordtype;
		node->childlist = child0;
		node->constchar = constchar;
		treenode *temp;
		temp = child0;
		while (temp!=NULL&&temp->bro != NULL)
		{
			temp = temp->bro;
		}
		if(temp!=NULL)
		temp->bro = child1;
		temp = child1;
		while (temp != NULL && temp->bro != NULL)
		{
			temp = temp->bro;
		}
		if (temp != NULL)
		temp->bro = child2;
		node->bro = NULL;
		node->linenum = linenu;
		node->nodenum = nodenu++;
		node->op = op;
		//shownode(node);
	}
	return node;
}
void mytree::shownode(treenode *node)
{
	string Type[3] = { "CHAR","INT","BOOL" };
	string Decl[3] = { "VAR_DECL","ID_DECL ","TYPE_DECL" };
	string stmt[6] = { "DEC_STMT","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
	string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP  " };
	cout << node->nodenum << "\t";
	if (node->nodetype == -1)
	{
		cout << "COMP_STMT" << "\t" << "\t";
	}
	if (node->nodetype == STMT)
	{
		cout << stmt[node->type_type]<<"\t"<<"\t";
	}
	else if (node->nodetype == EXP)
	{
		cout << myexp[node->type_type] << "\t" << "OP:" << node->op << "\t";
	}
	else if (node->nodetype == DECL)
	{
		cout << Decl[node->type_type] << "\t";
		if (node->type_type == VAR_DECL)
		{
			cout << node->IDaddr<<"\t";
		}
		else if (node->type_type == ID_DECL)
		{
			cout << "symbol:" <<mytable[node->IDaddr].name << "\t";
		}
		else
		{
			cout << Type[node->wordtype] << "\t";
		}
	}
	else if (node->nodetype == -2)
	{
		cout << "666";
	}
		cout << "Children:";
		treenode * temp = node->childlist;
		while (temp != NULL)
		{
			cout << temp->nodenum<<" ";
			temp = temp->bro;
		}
		cout << "\tProperty:" << node->mykind;
		cout << endl;
}
int mytree::addID(string a)
{
	for (int i = 0; i < tableuse; i++)
	{
		if (mytable[i].name.compare(a)==0)
		{
			return i;
		}
	}
	tableuse++;
	mytable[tableuse - 1].name = a;
	return -1;
}
treenode * mytree::createnode(int node_type, int type_type, string op, int wordtype, int ID_addr, treenode *child0, treenode *child1, treenode * child2,treenode *child3)
{
	string Type[3] = { "CHAR","INT","BOOL" };
	string Decl[3] = { "VAR_DECL","ID_DECL,TYPE_DECL" };
	string stmt[6] = { "VAR_DEC","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
	string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP" };
	struct treenode *node = new treenode;
	if (node == NULL) cout << "����" << endl;
	else
	{
		node->begin_label = "";
		node->false_label = "";
		node->next_label = "";
		node->true_label = "";
		node->nodetype = node_type;
		node->type_type = type_type;
		node->IDaddr = ID_addr;
		node->wordtype = wordtype;
		node->childlist = child0;
		treenode *temp;
		temp = child0;
		while (temp != NULL && temp->bro != NULL)
		{
			temp = temp->bro;
		}
		if (temp != NULL)
			temp->bro = child1;
		temp = child1;
		while (temp != NULL && temp->bro != NULL)
		{
			temp = temp->bro;
		}
		if (temp != NULL)
			temp->bro = child2;
		temp = child2;
		while (temp != NULL && temp->bro != NULL)
		{
			temp = temp->bro;
		}
		if (temp != NULL)
			temp->bro = child3;
		node->bro = NULL;
		node->linenum = linenu;
		node->nodenum = nodenu++;
		node->op = op;
		//shownode(node);
	}
	return node;
}
void mytree::DFS(treenode *node)
{
	string Type[3] = { "CHAR","INT","BOOL" };
	string Decl[3] = { "VAR_DECL","ID_DECL ","TYPE_DECL" };
	string stmt[6] = { "DEC_STMT","EXP_STMT","IF_STMT","FOR_STMT","COMP_STMT","WHILE_STMT" };
	string myexp[3] = { "ASSIGN_EXP","COMP_EXP","OP_EXP" };
	treenode *temp;
	if (node->nodetype == STMT)
	{
		temp = node;
		if (stmt[node->type_type] == "DEC_STMT")
		{
			treenode *mytemp = node;
			temp = temp->childlist;
			temp->mykind = Type[temp->wordtype];

		    while (temp->bro!= NULL)
			{
				temp->bro->mykind = temp->mykind;
				temp = temp->bro;
			}
		}
	}
    if (node->nodetype == DECL)
	{
		if (node->type_type ==ID_DECL)
		{
			if(node->mykind!="")
			mytable[node->IDaddr].type = node->mykind;
			else
			{
				node->mykind = mytable[node->IDaddr].type;
			}
		}
		else if (node->type_type ==VAR_DECL)
		{
			if (char(node->IDaddr) == node->constchar)
			{
				node->mykind = "CHAR";
			}
			else 
			node->mykind = "INT";
		}
	}

	if (node != NULL)
	{
		//if(node)
		temp = node->childlist;
		if (temp != NULL)
		{
			DFS(temp);
			get_temp_var(temp);
		}
	}
	//shownode(node);
	if (node->bro != NULL)
	{
		temp = node->bro;
		DFS(temp);
		get_temp_var(temp);
	}
	if (node->nodetype == STMT)
	{
		temp = node;
		if (stmt[node->type_type] == "IF_STMT")
		{
			treenode *mytemp = node;
			temp = temp->childlist;
			if (temp->mykind == "BOOL")
			{
				mytemp->mykind = "BOOL";
			}
			else {
				mytemp->mykind = "IF������";
			}
		}
		if (stmt[node->type_type] == "FOR_STMT")
		{
			treenode *mytemp = node;
			temp = temp->childlist;
			treenode *temp1 = temp->bro;
			treenode *temp2 = temp1->bro;
			if (temp->mykind == "INT")
			{
				if (temp1->mykind == "BOOL")
				{
					mytemp->mykind = "INT";
				}
				else mytemp->mykind = "FOR������";
			}
			else {
				mytemp->mykind = "FOR������";
			}
		}
	}

	if (node->nodetype == EXP)
	{
		if (myexp[node->type_type] == "ASSIGN_EXP")
		{
			temp = node->childlist;
			if (mytable[temp->IDaddr].type.length() == 0)
			{
				node->mykind = "δ��������";
			}
			treenode *mytemp = node;
			mytemp = temp->bro;
			if (mytemp->mykind != temp->mykind)
			{
				node->mykind = "��ֵ����";
			}
			else node->mykind = temp->mykind;
		}
		if (myexp[node->type_type] == "OP_EXP")
		{
			temp = node->childlist;
			if (temp->type_type == ID_DECL)
			{
				if (mytable[temp->IDaddr].type.length() == 0)
				{
					node->mykind = "δ��������";
				}
			}
			treenode *mytemp = node;
			mytemp = temp->bro;
			if (mytemp->mykind != temp->mykind)
			{
				node->mykind = "�������";
			}
			else node->mykind = temp->mykind;
		}
		if (myexp[node->type_type] == "COMP_EXP")
		{
			temp = node->childlist;
			if (temp->type_type == ID_DECL)
			{
				if (mytable[temp->IDaddr].type.length() == 0)
				{
					node->mykind = "δ��������";
				}
			}
			if (temp->nodetype != DECL)
			{
				node->mykind = "��ֵ����";
				
			}
			else
			{
				treenode *mytemp = node;
				mytemp = temp->bro;
				if (mytemp->mykind != temp->mykind)
				{
					node->mykind = "�������";
				}
				else
					node->mykind = "BOOL";
			}
		}
	}
	//shownode(node);
}
void mytree::startshow(treenode *node)
{
	treenode *temp;
	if (node != NULL)
	{
		//if(node)
		temp = node->childlist;
		if (temp != NULL)
			startshow(temp);
	}
	shownode(node);
	if (node->bro != NULL)
	{
		temp = node->bro;
		startshow(temp);
	}
}
void mytree::gen_code(ostream &out, treenode *root)
{
	gen_header(out);			// ���ɻ�����ͷ��
	treenode *p = root->childlist;
	if (p->nodetype == STMT && p->type_type == VAR_DEC)
	{
		gen_decl(out, p);
	}
	out << endl << endl << "\t.code" << endl;
	out << "\tstart:" << endl;
	recursive_gen_code(out, root);	// ���������ɵݹ麯��
	if (root->next_label != "")
		out << root->next_label << ":" << endl;
	out << "\tWaitKeyCrt PROC" << endl;
	out << "\tinvoke crt_printf, SADD(13,10,\"Press any key to continue...\")" << endl;
	out << "\tinvoke crt__getch" << endl;
	out << "\t.if (eax == 0) || (eax == 0E0h)" << endl;
	out << "\t\tinvoke crt__getch" << endl;
	out << "\t.endif" << endl;
	out << "\tinvoke crt_printf, OFFSET LF" << endl;
	out << "\tret" << endl;
	out << "WaitKeyCrt ENDP" << endl;
	out << "end  " << "start" << endl;
	//out << "\tret" << endl;
	//out << "\tmain  ENDP" << endl;
	//out << "\tWaitKeyCrt PROC" << endl;
	//out << "\tinvoke crt_printf, SADD(13,10,\"Press any key to continue...\")" << endl;
	//out << "\tinvoke crt__getch" << endl;
	//out << "\t.if (eax == 0) || (eax == 0E0h)" << endl;
	//out << "\t\tinvoke crt__getch" << endl;
	//out << "\t.endif" << endl;
	//out << "\tinvoke crt_printf, OFFSET LF" << endl;
	//out << "\tret" << endl;
	//out << "WaitKeyCrt ENDP" << endl;
	//out << "end " << "start" << endl;//root->begin_label << endl;
}
void mytree::gen_header(ostream &out)
{
	out << "\t.586" << endl;
	out << "\t.model flat, stdcall" << endl;
	out << "\toption casemap :none" << endl;
	out << endl;
	out << "\tinclude \\masm32\\include\\windows.inc" << endl;
	out << "\tinclude \\masm32\\include\\user32.inc" << endl;
	out << "\tinclude \\masm32\\include\\kernel32.inc" << endl;
	out << "\tinclude \\masm32\\include\\masm32.inc" << endl;
	out << "\tinclude \\masm32\\include\\msvcrt.inc" << endl;
	out << "\tinclude \\masm32\\include\\gdi32.inc" << endl;
	out << "\tinclude \\masm32\\macros\\macros.asm" << endl;
	out << endl;
	out << "\tincludelib \\masm32\\lib\\user32.lib" << endl;
	out << "\tincludelib \\masm32\\lib\\kernel32.lib" << endl;
	out << "\tincludelib \\masm32\\lib\\masm32.lib" << endl;
	out << "\tincludelib \\masm32\\lib\\msvcrt.lib" << endl;
	out << "\tincludelib \\masm32\\lib\\gdi32.lib" << endl;
}
void mytree::gen_decl(ostream &out, treenode *t)
{
	out << endl << endl << "\t.data" << endl;
	for(; t != NULL&&t->type_type == VAR_DEC; t = t->bro)
	{
		for (treenode *p = t->childlist->bro;p;p=p->bro)
		{
			if (p->mykind == "INT")
				out << "\t\t_" << mytable[p->IDaddr].name << " DWORD 0" << endl;
			else if(p->mykind=="CHAR")
				out << "\t\t_" << mytable[p->IDaddr].name << " BYTE 0" << endl;
		}
	}
	for (int i = 0; i < temp_var_seq; i++)
	{
		out << "\t\tt" << i << " DWORD 0" << endl;
	}
	out << "\t\tbuffer BYTE 128 dup(0)" << endl;
	out << "\t\tLF BYTE 13, 10, 0" << endl;
}
void mytree::recursive_gen_code(ostream &out, treenode *t)
{
	if (t == NULL) return;
	if (t->nodetype == STMT && t->type_type == VAR_DEC);
	else if (t->nodetype == STMT )
	{
		stmt_code(out, t);
	}
	else if (t->nodetype == EXP )
	{
		if (t->type_type == ASSIGN_EXP)
		{
			if (t->childlist->bro->nodenum = EXP)
			{
				recursive_gen_code(out,t->childlist->bro);
			}
			expr_gen_code(out, t);
		}
		if (t->type_type == OP_EXP || t->type_type == COMP_EXP)
		{
			expr_gen_code(out, t);
		}
	}
	else if (t->nodetype == -1)
	{
		stmt_code(out, t);
	}
	else if (t->nodetype == -2)
	{
		stmt_code(out, t);
	}
}
void mytree::expr_gen_code(ostream &out, treenode  *t)
{
	recursive_gen_code(out, t->childlist);
	recursive_gen_code(out, t->childlist->bro);
	treenode *e1 = t->childlist;
	treenode *e2 = t->childlist->bro;
	if (t->op == "+")
	{
		out << "\tMOV eax,";
		if (e1->nodetype == DECL)
		{
			if (e1->type_type == ID_DECL)
			{
				out << "_" << mytable[e1->IDaddr].name;
			}
			else if (e1->type_type == VAR_DECL)
			{
				out << e1->IDaddr;
			}
		}
		else
		{
			out << "t" << e1->temp_var;
		}
		out << endl;
		out << "\tADD eax,";
		if (e2->nodetype == DECL)
		{
			if (e2->type_type == ID_DECL)
			{
				out << "_" << mytable[e2->IDaddr].name;
			}
			else if (e2->type_type == VAR_DECL)
			{
				out << e2->IDaddr;
			}
		}
		else
		{
			out << "t" << e2->temp_var;
		}
		out << endl;
		out << "\tMOV t" << t->temp_var << ",eax" << endl;
	}
	else if (t->op == "*")
	{
		out << "\tMOV eax,";
		if (e1->nodetype == DECL)
		{
			if (e1->type_type == ID_DECL)
			{
				out << "_" << mytable[e1->IDaddr].name;
			}
			else if (e1->type_type == VAR_DECL)
			{
				out << e1->IDaddr;
			}
		}
		else
		{
			out << "t" << e1->temp_var;
		}
		out << endl;
		out << "\tIMUL eax,";
		if (e2->nodetype == DECL)
		{
			if (e2->type_type == ID_DECL)
			{
				out << "_" << mytable[e2->IDaddr].name;
			}
			else if (e2->type_type == VAR_DECL)
			{
				out << e2->IDaddr;
			}
		}
		else
		{
			out << "t" << e2->temp_var;
		}
		out << endl;
		out << "\tMOV t" << t->temp_var << ",eax" << endl;
	}
	else if (t->op == "<")
	{
		out << "\tMOV eax,";
		if (e1->nodetype == DECL && e1->type_type == ID_DECL)
		{
			out << "_" << mytable[e1->IDaddr].name;
		}
		else if (e1->nodetype == DECL && e1->type_type == VAR_DECL)
		{
			out << e1->IDaddr;
		}
		else out << "t" << e1->temp_var;
		out << endl;
		out << "\tCMP eax,";
		if (e2->nodetype == DECL && e2->type_type == ID_DECL)
		{
			out << "_" << mytable[e2->IDaddr].name;
		}
		else if (e2->nodetype == DECL && e2->type_type == VAR_DECL)
		{
			out << e2->IDaddr;
		}
		else out << "t" << e2->temp_var;
		out << endl;
		out << "\t jl " << t->true_label << endl;
		out << "\t jmp " << t->false_label << endl;
		out << t->true_label << ":" << endl;
	}
	else if (t->op == "=")
	{
		//out << "\t MOV eax," << mytable[e1->IDaddr].name << "";
		out << "\t MOV eax,";
		if (e2->nodetype == DECL && e2->type_type == ID_DECL)
		{
			out << "_" << mytable[e2->IDaddr].name;
		}
		else if (e2->nodetype == DECL && e2->type_type == VAR_DECL)
		{
			out << e2->IDaddr;
		}
		else out << "t" << e2->temp_var;
		out << endl;
		out << "\t MOV _" << mytable[e1->IDaddr].name << ",eax";
		out << endl;
	}
	else if (t->op == "-")
	{
		out << "\tMOV eax,";
		if (e1->nodetype == DECL)
		{
			if (e1->type_type == ID_DECL)
			{
				out << "_" << mytable[e1->IDaddr].name;
			}
			else if (e1->type_type == VAR_DECL)
			{
				out << e1->IDaddr;
			}
		}
		else
		{
			out << "t" << e1->temp_var;
		}
		out << endl;
		out << "\tSUB eax,";
		if (e2->nodetype == DECL)
		{
			if (e2->type_type == ID_DECL)
			{
				out << "_" << mytable[e2->IDaddr].name;
			}
			else if (e2->type_type == VAR_DECL)
			{
				out << e2->IDaddr;
			}
		}
		else
		{
			out << "t" << e2->temp_var;
		}
		out << endl;
		out << "\tMOV t" << t->temp_var << ",eax" << endl;
	}
	else if (t->op == ">")
	{
	out << "\tMOV eax,";
	if (e1->nodetype == DECL && e1->type_type == ID_DECL)
	{
		out << "_" << mytable[e1->IDaddr].name;
	}
	else if (e1->nodetype == DECL && e1->type_type == VAR_DECL)
	{
		out << e1->IDaddr;
	}
	else out << "t" << e1->temp_var;
	out << endl;
	out << "\tCMP eax,";
	if (e2->nodetype == DECL && e2->type_type == ID_DECL)
	{
		out << "_" << mytable[e2->IDaddr].name;
	}
	else if (e2->nodetype == DECL && e2->type_type == VAR_DECL)
	{
		out << e2->IDaddr;
	}
	else out << "t" << e2->temp_var;
	out << endl;
	out << "\t jg " << t->true_label << endl;
	out << "\t jmp " << t->false_label << endl;
	out << t->true_label << ":" << endl;
    }
	else if (t->op == "==")
	{
	out << "\tMOV eax,";
	if (e1->nodetype == DECL && e1->type_type == ID_DECL)
	{
		out << "_" << mytable[e1->IDaddr].name;
	}
	else if (e1->nodetype == DECL && e1->type_type == VAR_DECL)
	{
		out << e1->IDaddr;
	}
	else out << "t" << e1->temp_var;
	out << endl;
	out << "\tCMP eax,";
	if (e2->nodetype == DECL && e2->type_type == ID_DECL)
	{
		out << "_" << mytable[e2->IDaddr].name;
	}
	else if (e2->nodetype == DECL && e2->type_type == VAR_DECL)
	{
		out << e2->IDaddr;
	}
	else out << "t" << e2->temp_var;
	out << endl;
	out << "\t je " << t->true_label << endl;
	out << "\t jmp " << t->false_label << endl;
	out << t->true_label << ":" << endl;
    }
	else if (t->op == "!=")
	{
	out << "\tMOV eax,";
	if (e1->nodetype == DECL && e1->type_type == ID_DECL)
	{
		out << "_" << mytable[e1->IDaddr].name;
	}
	else if (e1->nodetype == DECL && e1->type_type == VAR_DECL)
	{
		out << e1->IDaddr;
	}
	else out << "t" << e1->temp_var;
	out << endl;
	out << "\tCMP eax,";
	if (e2->nodetype == DECL && e2->type_type == ID_DECL)
	{
		out << "_" << mytable[e2->IDaddr].name;
	}
	else if (e2->nodetype == DECL && e2->type_type == VAR_DECL)
	{
		out << e2->IDaddr;
	}
	else out << "t" << e2->temp_var;
	out << endl;
	out << "\t jne " << t->true_label << endl;
	out << "\t jmp " << t->false_label << endl;
	out << t->true_label << ":" << endl;
    }

}
void mytree::stmt_code(ostream &out, treenode *t)
{
	if (t->type_type == -1)
	{
		treenode * p = t->childlist;
		for (; p; p = p->bro)
		{
			recursive_gen_code(out, p);
		}
	}
	else if (t->type_type == WHILE_STMT)
	{
		if (t->begin_label != "")
		{
			out << t->begin_label << ":" << endl;
		}
		recursive_gen_code(out, t->childlist);
		recursive_gen_code(out, t->childlist->bro);
		out << "\t jmp " << t->begin_label << endl;
		out << t->next_label << ":" << endl;
	} 
	else if (t->type_type == EXP_STMT)
	{
		recursive_gen_code(out, t->childlist);
		recursive_gen_code(out, t->childlist->bro);
	}
	else if (t->nodetype == -2)
	{
		if (t->type_type == -2)
		{
			out << "\tMOV eax,sval(input())"<<endl;
			out << "\tMOV _" << mytable[t->childlist->IDaddr].name << ",eax";
			out << endl;
		}
		else
		{
			out << "\t invoke crt_printf,SADD('%d',13,10),";
			out << "_" << mytable[t->childlist->IDaddr].name << endl;
		}
	}
	else if (t->type_type == FOR_STMT)
	{
		
	}
	else if (t->type_type == IF_STMT)
	{
		if (t->begin_label != "")
		{
			out << t->begin_label << ":" << endl;
		}
		recursive_gen_code(out, t->childlist);
		recursive_gen_code(out, t->childlist->bro);
		out << "\t jmp " << t->next_label << endl;
		if (t->childlist->bro->bro != NULL)
		{
			if (t->childlist->false_label != "")
			{
				out << t->childlist->false_label << ":" << endl;
			}
			recursive_gen_code(out, t->childlist->bro->bro);
		}
		else
		{
			if (t->childlist->false_label != "")
			{
				out << t->childlist->false_label << ":" << endl;
			}
		}
		out << "\t jmp " << t->next_label << endl;
		out << t->next_label << ":" << endl;

	}
}
void mytree::get_temp_var(treenode *t)
{
	if (t->nodetype != EXP) return;
	if (t->type_type == ASSIGN_EXP) return;
	treenode *arg1 = t->childlist;
	treenode *arg2 = t->childlist->bro;
	if (arg1->type_type == OP_EXP)
		temp_var_seq--;
	if (arg2&&arg2->type_type == OP_EXP)
	{
		temp_var_seq--;
	}
	t->temp_var = temp_var_seq;
	temp_var_seq++;
}
void mytree::stmt_get_label(treenode *t)
{
	switch (t->type_type)
	{
	case WHILE_STMT:
	{
		treenode *e = t->childlist;
		treenode *s = t->childlist->bro;
		if (t->begin_label == "")
		{
			t->begin_label.append("L");
			t->begin_label.append(to_string(label_count++));
		}
		s->next_label = t->begin_label;
		e->true_label.append("L");
		e->true_label.append(to_string(label_count++));
		s->begin_label = e->true_label;
		if (t->next_label == "")
		{
			t->next_label.append("L");
			t->next_label.append(to_string(label_count++));
		}
		e->false_label = t->next_label;
		if (t->bro != NULL)
		{
			t->bro->begin_label = t->next_label;
		}
		recursive_get_label(e);		// �ݹ�����ɲ�������ʽ�ڱ��
		recursive_get_label(s);		// �ݹ������ѭ�����ڱ��
	}
	break;
	case IF_STMT:
	{
		treenode *e = t->childlist;
		treenode *s = t->childlist->bro;
		treenode *s1=NULL;
		if(s->bro!=NULL)
		    s1 = s->bro;
		if (t->begin_label == "")
		{
			t->begin_label.append("L");
			t->begin_label.append(to_string(label_count++));
		}
		//s->next_label = t->begin_label;
		e->true_label.append("L");
		e->true_label.append(to_string(label_count++));
		s->begin_label = e->true_label;
		e->false_label.append("L");
		e->false_label.append(to_string(label_count++));
		if(s1!=NULL)
		s1->begin_label = e->false_label;
		if (t->next_label == "")
		{
			t->next_label.append("L");
			t->next_label.append(to_string(label_count++));
		}
		if (t->bro != NULL)
		{
			t->bro->begin_label = t->next_label;
		}
		recursive_get_label(e);		// �ݹ�����ɲ�������ʽ�ڱ��
		recursive_get_label(s);		// �ݹ������ѭ�����ڱ��
		recursive_get_label(s1);	// �ݹ������ѭ�����ڱ��
	}
	break;
	default:
	{
	//treenode *s = t->childlist->bro;
	//recursive_get_label(s);
	}
		break;
	}
}
void mytree::expr_get_label(treenode *t)
{
	treenode *e1 = t->childlist;
	treenode *e2 = t->childlist->bro;
	if (t->op == "&&")
	{
		e1->true_label.append("L");
		e1->true_label.append(to_string(label_count++));
		e2->true_label = t->true_label;
		e2->false_label = t->false_label;
		e1->false_label = e2->false_label;
	}
	else if (t->op == "||")
	{
		e1->false_label.append("L");
		e1->false_label.append(to_string(label_count++));
		e2->true_label = t->true_label;
		e2->false_label = t->false_label;
		e1->true_label = e2->true_label;
	}
	  if (e1)  recursive_get_label(e1);
      if (e2)  recursive_get_label(e2);
	//if(t->op=="")
}
void mytree::recursive_get_label(treenode *root)
{
	if (root == NULL) return;
	if (root->nodetype == STMT)
	{
		stmt_get_label(root);
	}
	else if (root->nodetype == -1)
	{
		treenode *t;
		t = root->childlist;
		while (t != NULL)
		{
			stmt_get_label(t);
			t = t->bro;
		}
	}
	else if (root->nodetype == EXP)
	{
		//�߼�����
		//if (root->type_type == )
		//{
		    //exp_get_label(t);
		//}
	}
}