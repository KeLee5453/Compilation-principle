/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
* 
* You are on day 104 of your 30 day trial period.
* 
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* myparser.cpp
* C++ source file generated from myparser.y.
* 
* Date: 01/02/19
* Time: 16:04:51
* 
* AYACC Version: 2.07
****************************************************************************/

#include <yycpars.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#line 1 ".\\myparser.y"

/****************************************************************************
myparser.y
ParserWizard generated YACC file.

Date: 2018��11��22��
****************************************************************************/
#ifndef MY_H_FILE 
#define MY_H_FILE 
#include<iostream>
#include<fstream>
#include "mylexer.h"
#include "mytree.h"
#include "string"
#include "string.h"
#endif
using namespace std;
extern mytree m1;
extern IDtable table[1000];
extern int tableuse;

#line 60 "myparser.cpp"
// repeated because of possible precompiled header
#include <yycpars.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#include ".\myparser.h"

/////////////////////////////////////////////////////////////////////////////
// constructor

YYPARSERNAME::YYPARSERNAME()
{
	yytables();
#line 35 ".\\myparser.y"

	// place any extra initialisation code here

#line 84 "myparser.cpp"
}

/////////////////////////////////////////////////////////////////////////////
// destructor

YYPARSERNAME::~YYPARSERNAME()
{
	// allows virtual functions to be called properly for correct cleanup
	yydestroy();
#line 40 ".\\myparser.y"

	// place any extra cleanup code here

#line 98 "myparser.cpp"
}

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#ifndef YYSTACK_SIZE
#define YYSTACK_SIZE 100
#endif
#ifndef YYSTACK_MAX
#define YYSTACK_MAX 0
#endif

/****************************************************************************
* N O T E
* 
* If the compiler generates a YYPARSERNAME error then you have not declared
* the name of the parser. The easiest way to do this is to use a name
* declaration. This is placed in the declarations section of your YACC
* source file and is introduced with the %name keyword. For instance, the
* following name declaration declares the parser myparser:
* 
* %name myparser
* 
* For more information see help.
****************************************************************************/

// yyattribute
#ifdef YYDEBUG
void YYFAR* YYPARSERNAME::yyattribute1(int index) const
{
	YYSTYPE YYFAR* p = &((YYSTYPE YYFAR*)yyattributestackptr)[yytop + index];
	return p;
}
#define yyattribute(index) (*(YYSTYPE YYFAR*)yyattribute1(index))
#else
#define yyattribute(index) (((YYSTYPE YYFAR*)yyattributestackptr)[yytop + (index)])
#endif

void YYPARSERNAME::yystacktoval(int index)
{
	yyassert(index >= 0);
	*(YYSTYPE YYFAR*)yyvalptr = ((YYSTYPE YYFAR*)yyattributestackptr)[index];
}

void YYPARSERNAME::yyvaltostack(int index)
{
	yyassert(index >= 0);
	((YYSTYPE YYFAR*)yyattributestackptr)[index] = *(YYSTYPE YYFAR*)yyvalptr;
}

void YYPARSERNAME::yylvaltoval()
{
	*(YYSTYPE YYFAR*)yyvalptr = *(YYSTYPE YYFAR*)yylvalptr;
}

void YYPARSERNAME::yyvaltolval()
{
	*(YYSTYPE YYFAR*)yylvalptr = *(YYSTYPE YYFAR*)yyvalptr;
}

void YYPARSERNAME::yylvaltostack(int index)
{
	yyassert(index >= 0);
	((YYSTYPE YYFAR*)yyattributestackptr)[index] = *(YYSTYPE YYFAR*)yylvalptr;
}

void YYFAR* YYPARSERNAME::yynewattribute(int count)
{
	yyassert(count >= 0);
	return new YYFAR YYSTYPE[count];
}

void YYPARSERNAME::yydeleteattribute(void YYFAR* attribute)
{
	delete[] (YYSTYPE YYFAR*)attribute;
}

void YYPARSERNAME::yycopyattribute(void YYFAR* dest, const void YYFAR* src, int count)
{
	for (int i = 0; i < count; i++) {
		((YYSTYPE YYFAR*)dest)[i] = ((YYSTYPE YYFAR*)src)[i];
	}
}

#ifdef YYDEBUG
void YYPARSERNAME::yyinitdebug(void YYFAR** p, int count) const
{
	yyassert(p != NULL);
	yyassert(count >= 1);

	YYSTYPE YYFAR** p1 = (YYSTYPE YYFAR**)p;
	for (int i = 0; i < count; i++) {
		p1[i] = &((YYSTYPE YYFAR*)yyattributestackptr)[yytop + i - (count - 1)];
	}
}
#endif

void YYPARSERNAME::yyaction(int action)
{
	switch (action) {
	case 0:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 74 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(4 - 4); 
                                        treenode *t=(*(YYSTYPE YYFAR*)yyvalptr);
                                        m1.DFS(t);
                                       m1.startshow(t);
                                       m1.recursive_get_label(t);
                                       	ofstream out("D:\\�����ļ�\\ps����\\1.asm");
			                             m1.gen_code(out,t);;
                                       
#line 215 "myparser.cpp"
			}
		}
		break;
	case 1:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 82 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(5 - 5); 
                                          treenode *t=(*(YYSTYPE YYFAR*)yyvalptr);                                       
                                        m1.DFS(t);
                                       m1.startshow(t);
                                       m1.recursive_get_label(t);
                                       	ofstream out("D:\\�����ļ�\\ps����\\1.asm");
			                             m1.gen_code(out,t);
			                             
#line 235 "myparser.cpp"
			}
		}
		break;
	case 2:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 90 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(5 - 5); 
                                         treenode *t=(*(YYSTYPE YYFAR*)yyvalptr);
                                        m1.startshow(t);
                                       m1.recursive_get_label(t);
                                       	ofstream out("D:\\�����ļ�\\ps����\\1.asm");
			                             m1.gen_code(out,t);
			                             
#line 254 "myparser.cpp"
			}
		}
		break;
	case 3:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[7];
			yyinitdebug((void YYFAR**)yya, 7);
#endif
			{
#line 97 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(6 - 6); 
                                          treenode *t=(*(YYSTYPE YYFAR*)yyvalptr);                                       
                                        m1.DFS(t);
                                       m1.startshow(t);
                                       m1.recursive_get_label(t);
                                       	ofstream out("D:\\�����ļ�\\ps����\\1.asm");
			                             m1.gen_code(out,t);
                                       
#line 274 "myparser.cpp"
			}
		}
		break;
	case 4:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 106 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(-1,-1,"1",0,0,yyattribute(2 - 3),NULL,NULL);
#line 287 "myparser.cpp"
			}
		}
		break;
	case 5:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 107 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=NULL;
#line 300 "myparser.cpp"
			}
		}
		break;
	case 6:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 109 ".\\myparser.y"
treenode* t=yyattribute(1 - 2);
                            if(t!=NULL)
                            
                            {
                                while(t->bro!=NULL)
                                   t=t->bro;
                                t->bro=yyattribute(2 - 2);
                                (*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 2);
                            }
                            else (*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(2 - 2);
                           
#line 323 "myparser.cpp"
			}
		}
		break;
	case 7:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 120 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 336 "myparser.cpp"
			}
		}
		break;
	case 8:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 122 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 349 "myparser.cpp"
			}
		}
		break;
	case 9:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 123 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 362 "myparser.cpp"
			}
		}
		break;
	case 10:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 124 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 375 "myparser.cpp"
			}
		}
		break;
	case 11:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 125 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 388 "myparser.cpp"
			}
		}
		break;
	case 12:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 126 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 401 "myparser.cpp"
			}
		}
		break;
	case 13:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 127 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 414 "myparser.cpp"
			}
		}
		break;
	case 14:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 128 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 427 "myparser.cpp"
			}
		}
		break;
	case 15:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 129 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 440 "myparser.cpp"
			}
		}
		break;
	case 16:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 131 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(-2,-2,"1",0,0,yyattribute(3 - 4),NULL,NULL);
#line 453 "myparser.cpp"
			}
		}
		break;
	case 17:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 132 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(-2,-3,"1",0,0,yyattribute(3 - 4),NULL,NULL);
#line 466 "myparser.cpp"
			}
		}
		break;
	case 18:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 134 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,VAR_DEC,"1",0,0,yyattribute(1 - 3),yyattribute(2 - 3),NULL);
                                         
#line 480 "myparser.cpp"
			}
		}
		break;
	case 19:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 137 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,TYPE_DECL,"1",Int,0,NULL,NULL,NULL);
#line 493 "myparser.cpp"
			}
		}
		break;
	case 20:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 138 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,TYPE_DECL,"1",Char,0,NULL,NULL,NULL);
#line 506 "myparser.cpp"
			}
		}
		break;
	case 21:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 139 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,TYPE_DECL,"1",Bool,0,NULL,NULL,NULL);
#line 519 "myparser.cpp"
			}
		}
		break;
	case 22:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 141 ".\\myparser.y"
 treenode* t=yyattribute(1 - 3);
                            if(t!=NULL)
                            {
                                while(t->bro!=NULL)
                                   t=t->bro;
                                t->bro=yyattribute(3 - 3);
                                (*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 3);
                            }
                            else (*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(3 - 3);
                            
#line 541 "myparser.cpp"
			}
		}
		break;
	case 23:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 153 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 554 "myparser.cpp"
			}
		}
		break;
	case 24:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 154 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(3 - 3);(*(YYSTYPE YYFAR*)yyvalptr)->bro=yyattribute(1 - 3); 
#line 567 "myparser.cpp"
			}
		}
		break;
	case 25:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 155 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 580 "myparser.cpp"
			}
		}
		break;
	case 26:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 157 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,ID_DECL,"1",0,yyattribute(1 - 1)->IDaddr,NULL,NULL,NULL);
#line 593 "myparser.cpp"
			}
		}
		break;
	case 27:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[8];
			yyinitdebug((void YYFAR**)yya, 8);
#endif
			{
#line 159 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,IF_STMT,"1",0,0,yyattribute(3 - 7),yyattribute(5 - 7),yyattribute(7 - 7));
#line 606 "myparser.cpp"
			}
		}
		break;
	case 28:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 160 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,IF_STMT,"1",0,0,yyattribute(3 - 5),yyattribute(5 - 5),NULL);
#line 619 "myparser.cpp"
			}
		}
		break;
	case 29:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[10];
			yyinitdebug((void YYFAR**)yya, 10);
#endif
			{
#line 162 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.createnode(STMT,FOR_STMT,"1",0,0,yyattribute(3 - 9),yyattribute(5 - 9),yyattribute(7 - 9),yyattribute(9 - 9));
#line 632 "myparser.cpp"
			}
		}
		break;
	case 30:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 164 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,WHILE_STMT,"1",0,0,yyattribute(3 - 5),yyattribute(5 - 5),NULL);
#line 645 "myparser.cpp"
			}
		}
		break;
	case 31:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[7];
			yyinitdebug((void YYFAR**)yya, 7);
#endif
			{
#line 165 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,WHILE_STMT,"1",0,0,yyattribute(2 - 6),yyattribute(5 - 6),NULL);
#line 658 "myparser.cpp"
			}
		}
		break;
	case 32:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 167 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(STMT,EXP_STMT,"1",0,0,yyattribute(1 - 2),NULL,NULL);
#line 671 "myparser.cpp"
			}
		}
		break;
	case 33:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 168 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=NULL;
#line 684 "myparser.cpp"
			}
		}
		break;
	case 34:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 170 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 697 "myparser.cpp"
			}
		}
		break;
	case 35:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 171 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 710 "myparser.cpp"
			}
		}
		break;
	case 36:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 172 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 723 "myparser.cpp"
			}
		}
		break;
	case 37:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 174 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,ASSIGN_EXP,"=",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 736 "myparser.cpp"
			}
		}
		break;
	case 38:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 176 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,"==",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 749 "myparser.cpp"
			}
		}
		break;
	case 39:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 177 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,"!=",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 762 "myparser.cpp"
			}
		}
		break;
	case 40:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 178 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,"<",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 775 "myparser.cpp"
			}
		}
		break;
	case 41:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 179 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,">",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 788 "myparser.cpp"
			}
		}
		break;
	case 42:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 180 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,"<=",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 801 "myparser.cpp"
			}
		}
		break;
	case 43:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 181 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,COMP_EXP,">=",0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 814 "myparser.cpp"
			}
		}
		break;
	case 44:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 182 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 827 "myparser.cpp"
			}
		}
		break;
	case 45:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 184 ".\\myparser.y"
     string s1="+";
                                  (*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,OP_EXP,s1,0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 841 "myparser.cpp"
			}
		}
		break;
	case 46:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 186 ".\\myparser.y"
string s1="-";(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,OP_EXP,s1,0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 854 "myparser.cpp"
			}
		}
		break;
	case 47:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 187 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 867 "myparser.cpp"
			}
		}
		break;
	case 48:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 188 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 880 "myparser.cpp"
			}
		}
		break;
	case 49:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 190 ".\\myparser.y"
string s1="*";(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,OP_EXP,s1,0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 893 "myparser.cpp"
			}
		}
		break;
	case 50:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 191 ".\\myparser.y"
string s1="/";(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(EXP,OP_EXP,s1,0,0,yyattribute(1 - 3),yyattribute(3 - 3),NULL);
#line 906 "myparser.cpp"
			}
		}
		break;
	case 51:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 192 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 919 "myparser.cpp"
			}
		}
		break;
	case 52:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 194 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(2 - 3);
#line 932 "myparser.cpp"
			}
		}
		break;
	case 53:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 195 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 945 "myparser.cpp"
			}
		}
		break;
	case 54:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 196 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,VAR_DECL,"1",0,yyattribute(1 - 1)->val,NULL,NULL,NULL,char(yyattribute(1 - 1)->val-1));
#line 958 "myparser.cpp"
			}
		}
		break;
	case 55:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 197 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=m1.creatnode(DECL,VAR_DECL,"1",0,yyattribute(1 - 1)->constchar,NULL,NULL,NULL,yyattribute(1 - 1)->constchar);
#line 971 "myparser.cpp"
			}
		}
		break;
	default:
		yyassert(0);
		break;
	}
}

void YYPARSERNAME::yytables()
{
	yyattribute_size = sizeof(YYSTYPE);
	yysstack_size = YYSTACK_SIZE;
	yystack_max = YYSTACK_MAX;

#ifdef YYDEBUG
	static const yysymbol_t YYNEARFAR YYBASED_CODE symbol[] = {
		{ "$end", 0 },
		{ "error", 256 },
		{ "INT", 257 },
		{ "CHAR", 258 },
		{ "VOID", 259 },
		{ "BOOL", 260 },
		{ "MAIN", 262 },
		{ "ID", 263 },
		{ "PLUS", 264 },
		{ "MINUS", 265 },
		{ "MUL", 266 },
		{ "DIV", 267 },
		{ "ASSIGN", 268 },
		{ "LBRACE", 269 },
		{ "RBRACE", 270 },
		{ "LPRACE", 271 },
		{ "RPRACE", 272 },
		{ "SIMICOLON", 275 },
		{ "COMMA", 276 },
		{ "EQ", 277 },
		{ "GT", 278 },
		{ "LT", 279 },
		{ "GE", 280 },
		{ "LE", 281 },
		{ "NEQ", 282 },
		{ "IF", 283 },
		{ "ELSE", 284 },
		{ "WHILE", 285 },
		{ "DO", 286 },
		{ "FOR", 287 },
		{ "CIN", 290 },
		{ "COUT", 291 },
		{ "SHL", 292 },
		{ "SHR", 293 },
		{ "NUMBER", 294 },
		{ "CONSTCHAR", 296 },
		{ NULL, 0 }
	};
	yysymbol = symbol;

	static const char* const YYNEARFAR YYBASED_CODE rule[] = {
		"$accept: mainstmt",
		"mainstmt: MAIN LPRACE RPRACE comp_stmt",
		"mainstmt: MAIN LPRACE VOID RPRACE comp_stmt",
		"mainstmt: VOID MAIN LPRACE RPRACE comp_stmt",
		"mainstmt: VOID MAIN LPRACE VOID RPRACE comp_stmt",
		"comp_stmt: LBRACE stmt_list RBRACE",
		"comp_stmt: LBRACE RBRACE",
		"stmt_list: stmt_list stmt",
		"stmt_list: stmt",
		"stmt: var_dec",
		"stmt: exp_stmt",
		"stmt: if_stmt",
		"stmt: for_stmt",
		"stmt: exp_stmt",
		"stmt: while_stmt",
		"stmt: io_stmt",
		"stmt: SIMICOLON",
		"io_stmt: CIN SHR id SIMICOLON",
		"io_stmt: COUT SHL id SIMICOLON",
		"var_dec: type idlist SIMICOLON",
		"type: INT",
		"type: CHAR",
		"type: BOOL",
		"idlist: idlist COMMA id",
		"idlist: id",
		"idlist: idlist COMMA assign_exp",
		"idlist: assign_exp",
		"id: ID",
		"if_stmt: IF LPRACE exp RPRACE comp_stmt ELSE comp_stmt",
		"if_stmt: IF LPRACE exp RPRACE comp_stmt",
		"for_stmt: FOR LPRACE exp SIMICOLON exp SIMICOLON exp RPRACE stmt",
		"while_stmt: WHILE LPRACE exp RPRACE comp_stmt",
		"while_stmt: DO stmt WHILE LPRACE exp RPRACE",
		"exp_stmt: exp SIMICOLON",
		"exp_stmt: SIMICOLON",
		"exp: assign_exp",
		"exp: comp_exp",
		"exp: op_exp",
		"assign_exp: id ASSIGN exp",
		"comp_exp: comp_exp EQ op_exp",
		"comp_exp: comp_exp NEQ op_exp",
		"comp_exp: comp_exp LT op_exp",
		"comp_exp: comp_exp GT op_exp",
		"comp_exp: comp_exp LE op_exp",
		"comp_exp: comp_exp GE op_exp",
		"comp_exp: op_exp",
		"op_exp: op_exp PLUS term",
		"op_exp: op_exp MINUS term",
		"op_exp: term",
		"op_exp: comp_exp",
		"term: term MUL factor",
		"term: term DIV factor",
		"term: factor",
		"factor: LPRACE op_exp RPRACE",
		"factor: id",
		"factor: NUMBER",
		"factor: CONSTCHAR"
	};
	yyrule = rule;
#endif

	static const yyreduction_t YYNEARFAR YYBASED_CODE reduction[] = {
		{ 0, 1, -1 },
		{ 1, 4, 0 },
		{ 1, 5, 1 },
		{ 1, 5, 2 },
		{ 1, 6, 3 },
		{ 2, 3, 4 },
		{ 2, 2, 5 },
		{ 3, 2, 6 },
		{ 3, 1, 7 },
		{ 4, 1, 8 },
		{ 4, 1, 9 },
		{ 4, 1, 10 },
		{ 4, 1, 11 },
		{ 4, 1, 12 },
		{ 4, 1, 13 },
		{ 4, 1, 14 },
		{ 4, 1, 15 },
		{ 5, 4, 16 },
		{ 5, 4, 17 },
		{ 6, 3, 18 },
		{ 7, 1, 19 },
		{ 7, 1, 20 },
		{ 7, 1, 21 },
		{ 8, 3, 22 },
		{ 8, 1, 23 },
		{ 8, 3, 24 },
		{ 8, 1, 25 },
		{ 9, 1, 26 },
		{ 10, 7, 27 },
		{ 10, 5, 28 },
		{ 11, 9, 29 },
		{ 12, 5, 30 },
		{ 12, 6, 31 },
		{ 13, 2, 32 },
		{ 13, 1, 33 },
		{ 14, 1, 34 },
		{ 14, 1, 35 },
		{ 14, 1, 36 },
		{ 15, 3, 37 },
		{ 16, 3, 38 },
		{ 16, 3, 39 },
		{ 16, 3, 40 },
		{ 16, 3, 41 },
		{ 16, 3, 42 },
		{ 16, 3, 43 },
		{ 16, 1, 44 },
		{ 17, 3, 45 },
		{ 17, 3, 46 },
		{ 17, 1, 47 },
		{ 17, 1, 48 },
		{ 18, 3, 49 },
		{ 18, 3, 50 },
		{ 18, 1, 51 },
		{ 19, 3, 52 },
		{ 19, 1, 53 },
		{ 19, 1, 54 },
		{ 19, 1, 55 }
	};
	yyreduction = reduction;

	yytokenaction_size = 91;

	static const yytokenaction_t YYNEARFAR YYBASED_CODE tokenaction[] = {
		{ 112, YYAT_SHIFT, 17 },
		{ 112, YYAT_SHIFT, 18 },
		{ 109, YYAT_SHIFT, 22 },
		{ 112, YYAT_SHIFT, 19 },
		{ 46, YYAT_SHIFT, 67 },
		{ 46, YYAT_SHIFT, 68 },
		{ 47, YYAT_REDUCE, 49 },
		{ 47, YYAT_REDUCE, 49 },
		{ 0, YYAT_SHIFT, 1 },
		{ 50, YYAT_SHIFT, 67 },
		{ 50, YYAT_SHIFT, 68 },
		{ 0, YYAT_SHIFT, 2 },
		{ 46, YYAT_REDUCE, 37 },
		{ 94, YYAT_SHIFT, 67 },
		{ 94, YYAT_SHIFT, 68 },
		{ 46, YYAT_REDUCE, 37 },
		{ 46, YYAT_REDUCE, 37 },
		{ 50, YYAT_SHIFT, 75 },
		{ 112, YYAT_SHIFT, 23 },
		{ 47, YYAT_SHIFT, 69 },
		{ 47, YYAT_SHIFT, 70 },
		{ 47, YYAT_SHIFT, 71 },
		{ 47, YYAT_SHIFT, 72 },
		{ 47, YYAT_SHIFT, 73 },
		{ 47, YYAT_SHIFT, 74 },
		{ 109, YYAT_SHIFT, 30 },
		{ 112, YYAT_SHIFT, 24 },
		{ 109, YYAT_SHIFT, 31 },
		{ 112, YYAT_SHIFT, 25 },
		{ 112, YYAT_SHIFT, 26 },
		{ 112, YYAT_SHIFT, 27 },
		{ 6, YYAT_SHIFT, 9 },
		{ 5, YYAT_SHIFT, 7 },
		{ 112, YYAT_SHIFT, 28 },
		{ 112, YYAT_SHIFT, 29 },
		{ 51, YYAT_SHIFT, 69 },
		{ 51, YYAT_SHIFT, 70 },
		{ 51, YYAT_SHIFT, 71 },
		{ 51, YYAT_SHIFT, 72 },
		{ 51, YYAT_SHIFT, 73 },
		{ 51, YYAT_SHIFT, 74 },
		{ 93, YYAT_SHIFT, 67 },
		{ 93, YYAT_SHIFT, 68 },
		{ 111, YYAT_SHIFT, 112 },
		{ 6, YYAT_SHIFT, 10 },
		{ 5, YYAT_SHIFT, 8 },
		{ 92, YYAT_SHIFT, 67 },
		{ 92, YYAT_SHIFT, 68 },
		{ 91, YYAT_SHIFT, 67 },
		{ 91, YYAT_SHIFT, 68 },
		{ 90, YYAT_SHIFT, 67 },
		{ 90, YYAT_SHIFT, 68 },
		{ 89, YYAT_SHIFT, 67 },
		{ 89, YYAT_SHIFT, 68 },
		{ 88, YYAT_SHIFT, 64 },
		{ 88, YYAT_SHIFT, 65 },
		{ 87, YYAT_SHIFT, 64 },
		{ 87, YYAT_SHIFT, 65 },
		{ 60, YYAT_SHIFT, 82 },
		{ 60, YYAT_SHIFT, 83 },
		{ 42, YYAT_SHIFT, 64 },
		{ 42, YYAT_SHIFT, 65 },
		{ 107, YYAT_SHIFT, 12 },
		{ 106, YYAT_SHIFT, 109 },
		{ 105, YYAT_SHIFT, 108 },
		{ 103, YYAT_SHIFT, 107 },
		{ 101, YYAT_SHIFT, 63 },
		{ 83, YYAT_SHIFT, 20 },
		{ 81, YYAT_SHIFT, 100 },
		{ 80, YYAT_SHIFT, 99 },
		{ 79, YYAT_SHIFT, 98 },
		{ 78, YYAT_SHIFT, 97 },
		{ 77, YYAT_SHIFT, 96 },
		{ 76, YYAT_SHIFT, 95 },
		{ 61, YYAT_SHIFT, 63 },
		{ 54, YYAT_SHIFT, 78 },
		{ 45, YYAT_SHIFT, 66 },
		{ 40, YYAT_SHIFT, 63 },
		{ 34, YYAT_SHIFT, 58 },
		{ 29, YYAT_SHIFT, 57 },
		{ 28, YYAT_SHIFT, 56 },
		{ 27, YYAT_SHIFT, 55 },
		{ 25, YYAT_SHIFT, 53 },
		{ 24, YYAT_SHIFT, 52 },
		{ 12, YYAT_SHIFT, 21 },
		{ 9, YYAT_SHIFT, 14 },
		{ 7, YYAT_SHIFT, 11 },
		{ 4, YYAT_SHIFT, 6 },
		{ 3, YYAT_ACCEPT, 0 },
		{ 2, YYAT_SHIFT, 5 },
		{ 1, YYAT_SHIFT, 4 }
	};
	yytokenaction = tokenaction;

	static const yystateaction_t YYNEARFAR YYBASED_CODE stateaction[] = {
		{ -251, 1, YYAT_ERROR, 0 },
		{ -172, 1, YYAT_ERROR, 0 },
		{ -182, 1, YYAT_ERROR, 0 },
		{ 88, 1, YYAT_ERROR, 0 },
		{ -184, 1, YYAT_ERROR, 0 },
		{ -227, 1, YYAT_ERROR, 0 },
		{ -228, 1, YYAT_ERROR, 0 },
		{ -186, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ -187, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ -186, 1, YYAT_DEFAULT, 112 },
		{ 0, 0, YYAT_REDUCE, 1 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ 0, 0, YYAT_REDUCE, 3 },
		{ 0, 0, YYAT_REDUCE, 2 },
		{ 0, 0, YYAT_REDUCE, 20 },
		{ 0, 0, YYAT_REDUCE, 21 },
		{ 0, 0, YYAT_REDUCE, 22 },
		{ 0, 0, YYAT_REDUCE, 27 },
		{ 0, 0, YYAT_REDUCE, 6 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_REDUCE, 16 },
		{ -188, 1, YYAT_ERROR, 0 },
		{ -189, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_DEFAULT, 112 },
		{ -190, 1, YYAT_ERROR, 0 },
		{ -213, 1, YYAT_ERROR, 0 },
		{ -213, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 55 },
		{ 0, 0, YYAT_REDUCE, 56 },
		{ 0, 0, YYAT_REDUCE, 9 },
		{ 0, 0, YYAT_REDUCE, 8 },
		{ -192, 1, YYAT_DEFAULT, 112 },
		{ 0, 0, YYAT_REDUCE, 11 },
		{ 0, 0, YYAT_REDUCE, 15 },
		{ 0, 0, YYAT_REDUCE, 14 },
		{ 0, 0, YYAT_REDUCE, 10 },
		{ 0, 0, YYAT_DEFAULT, 83 },
		{ -191, 1, YYAT_REDUCE, 54 },
		{ 0, 0, YYAT_REDUCE, 12 },
		{ -206, 1, YYAT_REDUCE, 48 },
		{ 0, 0, YYAT_REDUCE, 52 },
		{ 0, 0, YYAT_REDUCE, 35 },
		{ -199, 1, YYAT_ERROR, 0 },
		{ -260, 1, YYAT_REDUCE, 45 },
		{ -258, 1, YYAT_REDUCE, 36 },
		{ 0, 0, YYAT_REDUCE, 4 },
		{ 0, 0, YYAT_REDUCE, 54 },
		{ -255, 1, YYAT_REDUCE, 45 },
		{ -242, 1, YYAT_REDUCE, 49 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ -210, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 83 },
		{ 0, 0, YYAT_DEFAULT, 83 },
		{ 0, 0, YYAT_REDUCE, 5 },
		{ 0, 0, YYAT_REDUCE, 7 },
		{ -217, 1, YYAT_ERROR, 0 },
		{ -194, 1, YYAT_REDUCE, 24 },
		{ 0, 0, YYAT_REDUCE, 26 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_REDUCE, 33 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_REDUCE, 53 },
		{ -199, 1, YYAT_ERROR, 0 },
		{ -200, 1, YYAT_ERROR, 0 },
		{ -200, 1, YYAT_ERROR, 0 },
		{ -205, 1, YYAT_ERROR, 0 },
		{ -206, 1, YYAT_ERROR, 0 },
		{ -207, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 19 },
		{ -196, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 38 },
		{ 0, 0, YYAT_REDUCE, 50 },
		{ 0, 0, YYAT_REDUCE, 51 },
		{ -210, 1, YYAT_REDUCE, 46 },
		{ -212, 1, YYAT_REDUCE, 47 },
		{ -212, 1, YYAT_REDUCE, 39 },
		{ -214, 1, YYAT_REDUCE, 42 },
		{ -216, 1, YYAT_REDUCE, 41 },
		{ -218, 1, YYAT_REDUCE, 44 },
		{ -223, 1, YYAT_REDUCE, 43 },
		{ -251, 1, YYAT_REDUCE, 40 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ 0, 0, YYAT_DEFAULT, 107 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_REDUCE, 17 },
		{ 0, 0, YYAT_REDUCE, 18 },
		{ -202, 1, YYAT_REDUCE, 23 },
		{ 0, 0, YYAT_REDUCE, 25 },
		{ -219, 1, YYAT_REDUCE, 29 },
		{ 0, 0, YYAT_REDUCE, 31 },
		{ -208, 1, YYAT_ERROR, 0 },
		{ -212, 1, YYAT_ERROR, 0 },
		{ -207, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 32 },
		{ -269, 1, YYAT_DEFAULT, 83 },
		{ 0, 0, YYAT_REDUCE, 28 },
		{ -229, 1, YYAT_ERROR, 0 },
		{ -257, 1, YYAT_DEFAULT, 109 },
		{ 0, 0, YYAT_REDUCE, 30 }
	};
	yystateaction = stateaction;

	yynontermgoto_size = 54;

	static const yynontermgoto_t YYNEARFAR YYBASED_CODE nontermgoto[] = {
		{ 112, 113 },
		{ 112, 36 },
		{ 112, 32 },
		{ 112, 39 },
		{ 65, 49 },
		{ 107, 110 },
		{ 112, 35 },
		{ 112, 41 },
		{ 112, 37 },
		{ 112, 38 },
		{ 112, 45 },
		{ 109, 40 },
		{ 68, 88 },
		{ 68, 43 },
		{ 65, 86 },
		{ 98, 106 },
		{ 109, 111 },
		{ 109, 44 },
		{ 109, 47 },
		{ 109, 46 },
		{ 39, 60 },
		{ 39, 61 },
		{ 83, 101 },
		{ 74, 51 },
		{ 74, 94 },
		{ 74, 42 },
		{ 97, 105 },
		{ 39, 62 },
		{ 83, 102 },
		{ 12, 34 },
		{ 12, 33 },
		{ 96, 104 },
		{ 95, 103 },
		{ 73, 93 },
		{ 72, 92 },
		{ 71, 91 },
		{ 70, 90 },
		{ 69, 89 },
		{ 67, 87 },
		{ 64, 85 },
		{ 63, 84 },
		{ 57, 81 },
		{ 56, 80 },
		{ 55, 79 },
		{ 53, 77 },
		{ 52, 76 },
		{ 34, 59 },
		{ 26, 54 },
		{ 22, 50 },
		{ 14, 48 },
		{ 11, 16 },
		{ 10, 15 },
		{ 8, 13 },
		{ 0, 3 }
	};
	yynontermgoto = nontermgoto;

	static const yystategoto_t YYNEARFAR YYBASED_CODE stategoto[] = {
		{ 52, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 50, -1 },
		{ 0, -1 },
		{ 49, -1 },
		{ 48, -1 },
		{ 26, 112 },
		{ 0, -1 },
		{ 47, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 31, 74 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 43, 112 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 42, 112 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 12, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 31, 109 },
		{ 30, 109 },
		{ 0, -1 },
		{ 29, 109 },
		{ 33, -1 },
		{ 32, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 26, 109 },
		{ 20, 65 },
		{ -5, -1 },
		{ 0, -1 },
		{ 20, 68 },
		{ -6, 65 },
		{ 20, 74 },
		{ 19, 74 },
		{ 18, 74 },
		{ 17, 74 },
		{ 16, 74 },
		{ 7, 68 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 13, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 30, -1 },
		{ 29, -1 },
		{ 12, 109 },
		{ 1, 109 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 3, -1 },
		{ 0, -1 },
		{ 2, 74 },
		{ 0, -1 },
		{ 0, -1 },
		{ -4, 109 },
		{ 0, -1 }
	};
	yystategoto = stategoto;

	yydestructorptr = NULL;

	yytokendestptr = NULL;
	yytokendest_size = 0;

	yytokendestbaseptr = NULL;
	yytokendestbase_size = 0;
}
#line 199 ".\\myparser.y"


/////////////////////////////////////////////////////////////////////////////
// programs section

int main(void)
{
	int n = 1;
	mylexer lexer;
	myparser parser;
	if (parser.yycreate(&lexer)) {
		if (lexer.yycreate(&parser)) {
		//freopen("D:\\�����ļ�\\ps����\\1.txt", "r", stdin);
			n = parser.yyparse();
		}
	}
	return n;
}


