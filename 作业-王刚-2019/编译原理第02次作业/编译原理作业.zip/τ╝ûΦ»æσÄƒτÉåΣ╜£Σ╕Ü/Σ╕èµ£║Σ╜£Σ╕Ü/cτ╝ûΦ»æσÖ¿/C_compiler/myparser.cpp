/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
* 
* You are on day 88 of your 30 day trial period.
* 
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* myparser.cpp
* C++ source file generated from myparser.y.
* 
* Date: 01/04/19
* Time: 23:52:38
* 
* AYACC Version: 2.07
****************************************************************************/

#include <yycpars.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#line 1 ".\\myparser.y"

/****************************************************************************
myparser.y
ParserWizard generated YACC file.

Date: 2019��1��4��
****************************************************************************/

#include "mylexer.h"
#include <iostream>
#include <fstream>
#include <cctype>
#include "datastruct.h"
using namespace std;

TreeNode *root;
int rownum = 0;
int lineno = 0;

#line 58 "myparser.cpp"
// repeated because of possible precompiled header
#include <yycpars.h>

// namespaces
#ifdef YYSTDCPPLIB
using namespace std;
#endif
#ifdef YYNAMESPACE
using namespace yl;
#endif

#include ".\myparser.h"

/////////////////////////////////////////////////////////////////////////////
// constructor

YYPARSERNAME::YYPARSERNAME()
{
	yytables();
#line 33 ".\\myparser.y"

	// place any extra initialisation code here

#line 82 "myparser.cpp"
}

/////////////////////////////////////////////////////////////////////////////
// destructor

YYPARSERNAME::~YYPARSERNAME()
{
	// allows virtual functions to be called properly for correct cleanup
	yydestroy();
#line 38 ".\\myparser.y"

	// place any extra cleanup code here

#line 96 "myparser.cpp"
}

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#ifndef YYSTACK_SIZE
#define YYSTACK_SIZE 100
#endif
#ifndef YYSTACK_MAX
#define YYSTACK_MAX 0
#endif

/****************************************************************************
* N O T E
* 
* If the compiler generates a YYPARSERNAME error then you have not declared
* the name of the parser. The easiest way to do this is to use a name
* declaration. This is placed in the declarations section of your YACC
* source file and is introduced with the %name keyword. For instance, the
* following name declaration declares the parser myparser:
* 
* %name myparser
* 
* For more information see help.
****************************************************************************/

// yyattribute
#ifdef YYDEBUG
void YYFAR* YYPARSERNAME::yyattribute1(int index) const
{
	YYSTYPE YYFAR* p = &((YYSTYPE YYFAR*)yyattributestackptr)[yytop + index];
	return p;
}
#define yyattribute(index) (*(YYSTYPE YYFAR*)yyattribute1(index))
#else
#define yyattribute(index) (((YYSTYPE YYFAR*)yyattributestackptr)[yytop + (index)])
#endif

void YYPARSERNAME::yystacktoval(int index)
{
	yyassert(index >= 0);
	*(YYSTYPE YYFAR*)yyvalptr = ((YYSTYPE YYFAR*)yyattributestackptr)[index];
}

void YYPARSERNAME::yyvaltostack(int index)
{
	yyassert(index >= 0);
	((YYSTYPE YYFAR*)yyattributestackptr)[index] = *(YYSTYPE YYFAR*)yyvalptr;
}

void YYPARSERNAME::yylvaltoval()
{
	*(YYSTYPE YYFAR*)yyvalptr = *(YYSTYPE YYFAR*)yylvalptr;
}

void YYPARSERNAME::yyvaltolval()
{
	*(YYSTYPE YYFAR*)yylvalptr = *(YYSTYPE YYFAR*)yyvalptr;
}

void YYPARSERNAME::yylvaltostack(int index)
{
	yyassert(index >= 0);
	((YYSTYPE YYFAR*)yyattributestackptr)[index] = *(YYSTYPE YYFAR*)yylvalptr;
}

void YYFAR* YYPARSERNAME::yynewattribute(int count)
{
	yyassert(count >= 0);
	return new YYFAR YYSTYPE[count];
}

void YYPARSERNAME::yydeleteattribute(void YYFAR* attribute)
{
	delete[] (YYSTYPE YYFAR*)attribute;
}

void YYPARSERNAME::yycopyattribute(void YYFAR* dest, const void YYFAR* src, int count)
{
	for (int i = 0; i < count; i++) {
		((YYSTYPE YYFAR*)dest)[i] = ((YYSTYPE YYFAR*)src)[i];
	}
}

#ifdef YYDEBUG
void YYPARSERNAME::yyinitdebug(void YYFAR** p, int count) const
{
	yyassert(p != NULL);
	yyassert(count >= 1);

	YYSTYPE YYFAR** p1 = (YYSTYPE YYFAR**)p;
	for (int i = 0; i < count; i++) {
		p1[i] = &((YYSTYPE YYFAR*)yyattributestackptr)[yytop + i - (count - 1)];
	}
}
#endif

void YYPARSERNAME::yyaction(int action)
{
	switch (action) {
	case 0:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 72 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(4 - 4);
				root=(*(YYSTYPE YYFAR*)yyvalptr);
				typeCheck(root);
				showTree(root);
			
#line 211 "myparser.cpp"
			}
		}
		break;
	case 1:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 80 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr) = newStmtNode(Block);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[0] = yyattribute(2 - 3);
			
#line 227 "myparser.cpp"
			}
		}
		break;
	case 2:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 84 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr) = newStmtNode(Block);
#line 240 "myparser.cpp"
			}
		}
		break;
	case 3:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 87 ".\\myparser.y"

				yyattribute(1 - 2)->brother=yyattribute(2 - 2);
				(*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 2);
			
#line 256 "myparser.cpp"
			}
		}
		break;
	case 4:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 91 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 269 "myparser.cpp"
			}
		}
		break;
	case 5:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 93 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 282 "myparser.cpp"
			}
		}
		break;
	case 6:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 94 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 295 "myparser.cpp"
			}
		}
		break;
	case 7:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 95 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 308 "myparser.cpp"
			}
		}
		break;
	case 8:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 96 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 321 "myparser.cpp"
			}
		}
		break;
	case 9:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 97 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 334 "myparser.cpp"
			}
		}
		break;
	case 10:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 98 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 347 "myparser.cpp"
			}
		}
		break;
	case 11:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 99 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 360 "myparser.cpp"
			}
		}
		break;
	case 12:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 100 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 373 "myparser.cpp"
			}
		}
		break;
	case 13:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 101 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr) = yyattribute(1 - 1);
#line 386 "myparser.cpp"
			}
		}
		break;
	case 14:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 104 ".\\myparser.y"
 
					(*(YYSTYPE YYFAR*)yyvalptr)=newDeclNode(Var);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(2 - 3);
				
#line 403 "myparser.cpp"
			}
		}
		break;
	case 15:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 111 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Int;
			
#line 419 "myparser.cpp"
			}
		}
		break;
	case 16:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 116 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Char;
			
#line 435 "myparser.cpp"
			}
		}
		break;
	case 17:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 121 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Void;
			
#line 451 "myparser.cpp"
			}
		}
		break;
	case 18:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 126 ".\\myparser.y"
 
				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Bool;
			
#line 467 "myparser.cpp"
			}
		}
		break;
	case 19:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 131 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Float;
			
#line 483 "myparser.cpp"
			}
		}
		break;
	case 20:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 136 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Type);
				(*(YYSTYPE YYFAR*)yyvalptr)->varType=Double;
			
#line 499 "myparser.cpp"
			}
		}
		break;
	case 21:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 142 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 3);
				(*(YYSTYPE YYFAR*)yyvalptr)->brother=yyattribute(3 - 3);
			
#line 515 "myparser.cpp"
			}
		}
		break;
	case 22:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 146 ".\\myparser.y"
 (*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 528 "myparser.cpp"
			}
		}
		break;
	case 23:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 148 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 2);
#line 541 "myparser.cpp"
			}
		}
		break;
	case 24:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 151 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 554 "myparser.cpp"
			}
		}
		break;
	case 25:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 152 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 567 "myparser.cpp"
			}
		}
		break;
	case 26:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 153 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 580 "myparser.cpp"
			}
		}
		break;
	case 27:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 154 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 593 "myparser.cpp"
			}
		}
		break;
	case 28:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 157 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=ASSIGN;
				
#line 611 "myparser.cpp"
			}
		}
		break;
	case 29:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 165 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=OR;
				
#line 629 "myparser.cpp"
			}
		}
		break;
	case 30:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 172 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=AND;
				
#line 647 "myparser.cpp"
			}
		}
		break;
	case 31:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 179 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(2 - 2);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=OPPSITE;
				
#line 664 "myparser.cpp"
			}
		}
		break;
	case 32:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 184 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 677 "myparser.cpp"
			}
		}
		break;
	case 33:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 187 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=EQ;
				
#line 695 "myparser.cpp"
			}
		}
		break;
	case 34:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 194 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=NEQ;
				
#line 713 "myparser.cpp"
			}
		}
		break;
	case 35:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 201 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=GE;
				
#line 731 "myparser.cpp"
			}
		}
		break;
	case 36:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 208 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=LE;
				
#line 749 "myparser.cpp"
			}
		}
		break;
	case 37:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 215 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=GT;
				
#line 767 "myparser.cpp"
			}
		}
		break;
	case 38:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 222 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=LT;
				
#line 785 "myparser.cpp"
			}
		}
		break;
	case 39:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 228 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 798 "myparser.cpp"
			}
		}
		break;
	case 40:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 231 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=PLUS;
				
#line 816 "myparser.cpp"
			}
		}
		break;
	case 41:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 238 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=MINUS;
				
#line 834 "myparser.cpp"
			}
		}
		break;
	case 42:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 245 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=MUL;
				
#line 852 "myparser.cpp"
			}
		}
		break;
	case 43:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 252 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=DIV;
				
#line 870 "myparser.cpp"
			}
		}
		break;
	case 44:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 259 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(3 - 3);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=MOD;
				
#line 888 "myparser.cpp"
			}
		}
		break;
	case 45:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 266 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 2);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=DPLUS;
				
#line 905 "myparser.cpp"
			}
		}
		break;
	case 46:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[3];
			yyinitdebug((void YYFAR**)yya, 3);
#endif
			{
#line 272 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newExprNode(Op);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(1 - 2);
					(*(YYSTYPE YYFAR*)yyvalptr)->attr.op=DMINUS;
				
#line 922 "myparser.cpp"
			}
		}
		break;
	case 47:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 277 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 935 "myparser.cpp"
			}
		}
		break;
	case 48:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 279 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(2 - 3);
#line 948 "myparser.cpp"
			}
		}
		break;
	case 49:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 280 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 961 "myparser.cpp"
			}
		}
		break;
	case 50:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[2];
			yyinitdebug((void YYFAR**)yya, 2);
#endif
			{
#line 281 ".\\myparser.y"
(*(YYSTYPE YYFAR*)yyvalptr)=yyattribute(1 - 1);
#line 974 "myparser.cpp"
			}
		}
		break;
	case 51:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 285 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(If);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 5);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(5 - 5);
			
#line 991 "myparser.cpp"
			}
		}
		break;
	case 52:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[8];
			yyinitdebug((void YYFAR**)yya, 8);
#endif
			{
#line 291 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(If);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 7);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(5 - 7);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[2]=yyattribute(7 - 7);
			
#line 1009 "myparser.cpp"
			}
		}
		break;
	case 53:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[10];
			yyinitdebug((void YYFAR**)yya, 10);
#endif
			{
#line 299 ".\\myparser.y"

				(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(For);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 9);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(5 - 9);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[2]=yyattribute(7 - 9);
				(*(YYSTYPE YYFAR*)yyvalptr)->child[3]=yyattribute(9 - 9);
			
#line 1028 "myparser.cpp"
			}
		}
		break;
	case 54:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[6];
			yyinitdebug((void YYFAR**)yya, 6);
#endif
			{
#line 308 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(While);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 5);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[1]=yyattribute(5 - 5);
				
#line 1045 "myparser.cpp"
			}
		}
		break;
	case 55:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 315 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(Input);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 4);
				
#line 1061 "myparser.cpp"
			}
		}
		break;
	case 56:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[5];
			yyinitdebug((void YYFAR**)yya, 5);
#endif
			{
#line 321 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(Output);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(3 - 4);
				
#line 1077 "myparser.cpp"
			}
		}
		break;
	case 57:
		{
#ifdef YYDEBUG
			YYSTYPE YYFAR* yya[4];
			yyinitdebug((void YYFAR**)yya, 4);
#endif
			{
#line 327 ".\\myparser.y"

					(*(YYSTYPE YYFAR*)yyvalptr)=newStmtNode(Return);
					(*(YYSTYPE YYFAR*)yyvalptr)->child[0]=yyattribute(2 - 3);
				
#line 1093 "myparser.cpp"
			}
		}
		break;
	default:
		yyassert(0);
		break;
	}
}

void YYPARSERNAME::yytables()
{
	yyattribute_size = sizeof(YYSTYPE);
	yysstack_size = YYSTACK_SIZE;
	yystack_max = YYSTACK_MAX;

#ifdef YYDEBUG
	static const yysymbol_t YYNEARFAR YYBASED_CODE symbol[] = {
		{ "$end", 0 },
		{ "error", 256 },
		{ "INT", 257 },
		{ "CHAR", 258 },
		{ "VOID", 259 },
		{ "BOOL", 260 },
		{ "FLOAT", 261 },
		{ "DOUBLE", 262 },
		{ "IF", 263 },
		{ "ELSE", 264 },
		{ "WHILE", 265 },
		{ "FOR", 266 },
		{ "RETURN", 267 },
		{ "ASSIGN", 268 },
		{ "PLUS", 269 },
		{ "MINUS", 270 },
		{ "MUL", 271 },
		{ "DIV", 272 },
		{ "LPAREN", 273 },
		{ "RPAREN", 274 },
		{ "MOD", 275 },
		{ "DPLUS", 276 },
		{ "DMINUS", 277 },
		{ "SHL", 278 },
		{ "SHR", 279 },
		{ "EQ", 280 },
		{ "GT", 281 },
		{ "LT", 282 },
		{ "GE", 283 },
		{ "LE", 284 },
		{ "NEQ", 285 },
		{ "AND", 286 },
		{ "OR", 287 },
		{ "OPPSITE", 288 },
		{ "LBRACE", 289 },
		{ "RBRACE", 290 },
		{ "SEMI", 291 },
		{ "COMMA", 292 },
		{ "ID", 293 },
		{ "NUMBER", 294 },
		{ "MAIN", 295 },
		{ "CIN", 296 },
		{ "COUT", 297 },
		{ NULL, 0 }
	};
	yysymbol = symbol;

	static const char* const YYNEARFAR YYBASED_CODE rule[] = {
		"$accept: start",
		"start: MAIN LPAREN RPAREN block",
		"block: LBRACE stmts RBRACE",
		"block: LBRACE RBRACE",
		"stmts: stmt stmts",
		"stmts: stmt",
		"stmt: block",
		"stmt: exprstmt",
		"stmt: varstmt",
		"stmt: ifstmt",
		"stmt: whilestmt",
		"stmt: forstmt",
		"stmt: returnstmt",
		"stmt: inputstmt",
		"stmt: outputstmt",
		"varstmt: vartype idlist SEMI",
		"vartype: INT",
		"vartype: CHAR",
		"vartype: VOID",
		"vartype: BOOL",
		"vartype: FLOAT",
		"vartype: DOUBLE",
		"idlist: expr COMMA idlist",
		"idlist: expr",
		"exprstmt: expr SEMI",
		"exprstmt: SEMI",
		"expr: assignexpr",
		"expr: logitexpr",
		"expr: equalexpr",
		"expr: simpleexpr",
		"assignexpr: ID ASSIGN expr",
		"logitexpr: logitexpr OR equalexpr",
		"logitexpr: logitexpr AND equalexpr",
		"logitexpr: OPPSITE logitexpr",
		"logitexpr: equalexpr",
		"equalexpr: simpleexpr EQ simpleexpr",
		"equalexpr: simpleexpr NEQ simpleexpr",
		"equalexpr: simpleexpr GE simpleexpr",
		"equalexpr: simpleexpr LE simpleexpr",
		"equalexpr: simpleexpr GT simpleexpr",
		"equalexpr: simpleexpr LT simpleexpr",
		"equalexpr: simpleexpr",
		"simpleexpr: simpleexpr PLUS term",
		"simpleexpr: simpleexpr MINUS term",
		"simpleexpr: simpleexpr MUL term",
		"simpleexpr: simpleexpr DIV term",
		"simpleexpr: simpleexpr MOD term",
		"simpleexpr: simpleexpr DPLUS",
		"simpleexpr: simpleexpr DMINUS",
		"simpleexpr: term",
		"term: LPAREN expr RPAREN",
		"term: ID",
		"term: NUMBER",
		"term:",
		"ifstmt: IF LPAREN logitexpr RPAREN stmt",
		"ifstmt: IF LPAREN logitexpr RPAREN stmt ELSE stmt",
		"forstmt: FOR LPAREN expr SEMI logitexpr SEMI expr RPAREN stmt",
		"whilestmt: WHILE LPAREN logitexpr RPAREN stmt",
		"inputstmt: CIN SHR ID SEMI",
		"outputstmt: COUT SHL ID SEMI",
		"returnstmt: RETURN expr SEMI"
	};
	yyrule = rule;
#endif

	static const yyreduction_t YYNEARFAR YYBASED_CODE reduction[] = {
		{ 0, 1, -1 },
		{ 1, 4, 0 },
		{ 2, 3, 1 },
		{ 2, 2, 2 },
		{ 3, 2, 3 },
		{ 3, 1, 4 },
		{ 4, 1, 5 },
		{ 4, 1, 6 },
		{ 4, 1, 7 },
		{ 4, 1, 8 },
		{ 4, 1, 9 },
		{ 4, 1, 10 },
		{ 4, 1, 11 },
		{ 4, 1, 12 },
		{ 4, 1, 13 },
		{ 5, 3, 14 },
		{ 6, 1, 15 },
		{ 6, 1, 16 },
		{ 6, 1, 17 },
		{ 6, 1, 18 },
		{ 6, 1, 19 },
		{ 6, 1, 20 },
		{ 7, 3, 21 },
		{ 7, 1, 22 },
		{ 8, 2, 23 },
		{ 8, 1, -1 },
		{ 9, 1, 24 },
		{ 9, 1, 25 },
		{ 9, 1, 26 },
		{ 9, 1, 27 },
		{ 10, 3, 28 },
		{ 11, 3, 29 },
		{ 11, 3, 30 },
		{ 11, 2, 31 },
		{ 11, 1, 32 },
		{ 12, 3, 33 },
		{ 12, 3, 34 },
		{ 12, 3, 35 },
		{ 12, 3, 36 },
		{ 12, 3, 37 },
		{ 12, 3, 38 },
		{ 12, 1, 39 },
		{ 13, 3, 40 },
		{ 13, 3, 41 },
		{ 13, 3, 42 },
		{ 13, 3, 43 },
		{ 13, 3, 44 },
		{ 13, 2, 45 },
		{ 13, 2, 46 },
		{ 13, 1, 47 },
		{ 14, 3, 48 },
		{ 14, 1, 49 },
		{ 14, 1, 50 },
		{ 14, 0, -1 },
		{ 15, 5, 51 },
		{ 15, 7, 52 },
		{ 16, 9, 53 },
		{ 17, 5, 54 },
		{ 18, 4, 55 },
		{ 19, 4, 56 },
		{ 20, 3, 57 }
	};
	yyreduction = reduction;

	yytokenaction_size = 337;

	static const yytokenaction_t YYNEARFAR YYBASED_CODE tokenaction[] = {
		{ 36, YYAT_SHIFT, 7 },
		{ 36, YYAT_SHIFT, 8 },
		{ 36, YYAT_SHIFT, 9 },
		{ 36, YYAT_SHIFT, 10 },
		{ 36, YYAT_SHIFT, 11 },
		{ 36, YYAT_SHIFT, 12 },
		{ 36, YYAT_SHIFT, 13 },
		{ 110, YYAT_SHIFT, 111 },
		{ 36, YYAT_SHIFT, 14 },
		{ 36, YYAT_SHIFT, 15 },
		{ 36, YYAT_SHIFT, 16 },
		{ 49, YYAT_SHIFT, 59 },
		{ 49, YYAT_SHIFT, 60 },
		{ 76, YYAT_SHIFT, 99 },
		{ 42, YYAT_REDUCE, 34 },
		{ 42, YYAT_REDUCE, 34 },
		{ 36, YYAT_SHIFT, 17 },
		{ 38, YYAT_SHIFT, 59 },
		{ 38, YYAT_SHIFT, 60 },
		{ 5, YYAT_SHIFT, 7 },
		{ 5, YYAT_SHIFT, 8 },
		{ 5, YYAT_SHIFT, 9 },
		{ 5, YYAT_SHIFT, 10 },
		{ 5, YYAT_SHIFT, 11 },
		{ 5, YYAT_SHIFT, 12 },
		{ 5, YYAT_SHIFT, 13 },
		{ 104, YYAT_SHIFT, 107 },
		{ 5, YYAT_SHIFT, 14 },
		{ 5, YYAT_SHIFT, 15 },
		{ 5, YYAT_SHIFT, 16 },
		{ 76, YYAT_ERROR, 0 },
		{ 36, YYAT_SHIFT, 18 },
		{ 36, YYAT_SHIFT, 5 },
		{ 36, YYAT_REDUCE, 5 },
		{ 36, YYAT_SHIFT, 20 },
		{ 5, YYAT_SHIFT, 17 },
		{ 36, YYAT_SHIFT, 21 },
		{ 36, YYAT_SHIFT, 22 },
		{ 82, YYAT_SHIFT, 102 },
		{ 36, YYAT_SHIFT, 23 },
		{ 36, YYAT_SHIFT, 24 },
		{ 97, YYAT_SHIFT, 62 },
		{ 97, YYAT_SHIFT, 63 },
		{ 97, YYAT_SHIFT, 64 },
		{ 97, YYAT_SHIFT, 65 },
		{ 81, YYAT_SHIFT, 101 },
		{ 77, YYAT_SHIFT, 100 },
		{ 97, YYAT_SHIFT, 66 },
		{ 97, YYAT_SHIFT, 67 },
		{ 97, YYAT_SHIFT, 68 },
		{ 5, YYAT_SHIFT, 18 },
		{ 5, YYAT_SHIFT, 5 },
		{ 5, YYAT_SHIFT, 19 },
		{ 5, YYAT_SHIFT, 20 },
		{ 74, YYAT_SHIFT, 17 },
		{ 5, YYAT_SHIFT, 21 },
		{ 5, YYAT_SHIFT, 22 },
		{ 75, YYAT_SHIFT, 98 },
		{ 5, YYAT_SHIFT, 23 },
		{ 5, YYAT_SHIFT, 24 },
		{ 111, YYAT_SHIFT, 7 },
		{ 111, YYAT_SHIFT, 8 },
		{ 111, YYAT_SHIFT, 9 },
		{ 111, YYAT_SHIFT, 10 },
		{ 111, YYAT_SHIFT, 11 },
		{ 111, YYAT_SHIFT, 12 },
		{ 111, YYAT_SHIFT, 13 },
		{ 56, YYAT_SHIFT, 84 },
		{ 111, YYAT_SHIFT, 14 },
		{ 111, YYAT_SHIFT, 15 },
		{ 111, YYAT_SHIFT, 16 },
		{ 55, YYAT_SHIFT, 83 },
		{ 54, YYAT_SHIFT, 82 },
		{ 53, YYAT_SHIFT, 81 },
		{ 74, YYAT_SHIFT, 48 },
		{ 74, YYAT_SHIFT, 22 },
		{ 111, YYAT_SHIFT, 17 },
		{ 107, YYAT_SHIFT, 7 },
		{ 107, YYAT_SHIFT, 8 },
		{ 107, YYAT_SHIFT, 9 },
		{ 107, YYAT_SHIFT, 10 },
		{ 107, YYAT_SHIFT, 11 },
		{ 107, YYAT_SHIFT, 12 },
		{ 107, YYAT_SHIFT, 13 },
		{ 73, YYAT_SHIFT, 17 },
		{ 107, YYAT_SHIFT, 14 },
		{ 107, YYAT_SHIFT, 15 },
		{ 107, YYAT_SHIFT, 16 },
		{ 47, YYAT_SHIFT, 79 },
		{ 46, YYAT_SHIFT, 78 },
		{ 39, YYAT_SHIFT, 61 },
		{ 111, YYAT_SHIFT, 18 },
		{ 111, YYAT_SHIFT, 5 },
		{ 107, YYAT_SHIFT, 17 },
		{ 111, YYAT_SHIFT, 20 },
		{ 35, YYAT_SHIFT, 57 },
		{ 111, YYAT_SHIFT, 21 },
		{ 111, YYAT_SHIFT, 22 },
		{ 24, YYAT_SHIFT, 54 },
		{ 111, YYAT_SHIFT, 23 },
		{ 111, YYAT_SHIFT, 24 },
		{ 106, YYAT_SHIFT, 59 },
		{ 106, YYAT_SHIFT, 60 },
		{ 23, YYAT_SHIFT, 53 },
		{ 73, YYAT_SHIFT, 48 },
		{ 73, YYAT_SHIFT, 22 },
		{ 106, YYAT_SHIFT, 108 },
		{ 21, YYAT_SHIFT, 52 },
		{ 107, YYAT_SHIFT, 18 },
		{ 107, YYAT_SHIFT, 5 },
		{ 108, YYAT_SHIFT, 17 },
		{ 107, YYAT_SHIFT, 20 },
		{ 72, YYAT_SHIFT, 17 },
		{ 107, YYAT_SHIFT, 21 },
		{ 107, YYAT_SHIFT, 22 },
		{ 15, YYAT_SHIFT, 45 },
		{ 107, YYAT_SHIFT, 23 },
		{ 107, YYAT_SHIFT, 24 },
		{ 99, YYAT_SHIFT, 7 },
		{ 99, YYAT_SHIFT, 8 },
		{ 99, YYAT_SHIFT, 9 },
		{ 99, YYAT_SHIFT, 10 },
		{ 99, YYAT_SHIFT, 11 },
		{ 99, YYAT_SHIFT, 12 },
		{ 99, YYAT_SHIFT, 13 },
		{ 108, YYAT_SHIFT, 18 },
		{ 99, YYAT_SHIFT, 14 },
		{ 99, YYAT_SHIFT, 15 },
		{ 99, YYAT_SHIFT, 16 },
		{ 14, YYAT_SHIFT, 44 },
		{ 108, YYAT_SHIFT, 21 },
		{ 108, YYAT_SHIFT, 22 },
		{ 72, YYAT_SHIFT, 48 },
		{ 72, YYAT_SHIFT, 22 },
		{ 99, YYAT_SHIFT, 17 },
		{ 98, YYAT_SHIFT, 7 },
		{ 98, YYAT_SHIFT, 8 },
		{ 98, YYAT_SHIFT, 9 },
		{ 98, YYAT_SHIFT, 10 },
		{ 98, YYAT_SHIFT, 11 },
		{ 98, YYAT_SHIFT, 12 },
		{ 98, YYAT_SHIFT, 13 },
		{ 71, YYAT_SHIFT, 17 },
		{ 98, YYAT_SHIFT, 14 },
		{ 98, YYAT_SHIFT, 15 },
		{ 98, YYAT_SHIFT, 16 },
		{ 13, YYAT_SHIFT, 43 },
		{ 4, YYAT_SHIFT, 5 },
		{ 3, YYAT_SHIFT, 4 },
		{ 99, YYAT_SHIFT, 18 },
		{ 99, YYAT_SHIFT, 5 },
		{ 98, YYAT_SHIFT, 17 },
		{ 99, YYAT_SHIFT, 20 },
		{ 2, YYAT_ACCEPT, 0 },
		{ 99, YYAT_SHIFT, 21 },
		{ 99, YYAT_SHIFT, 22 },
		{ 1, YYAT_SHIFT, 3 },
		{ 99, YYAT_SHIFT, 23 },
		{ 99, YYAT_SHIFT, 24 },
		{ 0, YYAT_SHIFT, 1 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 71, YYAT_SHIFT, 48 },
		{ 71, YYAT_SHIFT, 22 },
		{ -1, YYAT_ERROR, 0 },
		{ 100, YYAT_SHIFT, 17 },
		{ 98, YYAT_SHIFT, 18 },
		{ 98, YYAT_SHIFT, 5 },
		{ -1, YYAT_ERROR, 0 },
		{ 98, YYAT_SHIFT, 20 },
		{ -1, YYAT_ERROR, 0 },
		{ 98, YYAT_SHIFT, 21 },
		{ 98, YYAT_SHIFT, 22 },
		{ -1, YYAT_ERROR, 0 },
		{ 98, YYAT_SHIFT, 23 },
		{ 98, YYAT_SHIFT, 24 },
		{ 40, YYAT_SHIFT, 62 },
		{ 40, YYAT_SHIFT, 63 },
		{ 40, YYAT_SHIFT, 64 },
		{ 40, YYAT_SHIFT, 65 },
		{ 100, YYAT_SHIFT, 18 },
		{ -1, YYAT_ERROR, 0 },
		{ 40, YYAT_SHIFT, 66 },
		{ 40, YYAT_SHIFT, 67 },
		{ 40, YYAT_SHIFT, 68 },
		{ 100, YYAT_SHIFT, 48 },
		{ 100, YYAT_SHIFT, 22 },
		{ 40, YYAT_SHIFT, 69 },
		{ 40, YYAT_SHIFT, 70 },
		{ 40, YYAT_SHIFT, 71 },
		{ 40, YYAT_SHIFT, 72 },
		{ 40, YYAT_SHIFT, 73 },
		{ 40, YYAT_SHIFT, 74 },
		{ 40, YYAT_REDUCE, 41 },
		{ 40, YYAT_REDUCE, 41 },
		{ 50, YYAT_SHIFT, 62 },
		{ 50, YYAT_SHIFT, 63 },
		{ 50, YYAT_SHIFT, 64 },
		{ 50, YYAT_SHIFT, 65 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 50, YYAT_SHIFT, 66 },
		{ 50, YYAT_SHIFT, 67 },
		{ 50, YYAT_SHIFT, 68 },
		{ -1, YYAT_ERROR, 0 },
		{ 70, YYAT_SHIFT, 17 },
		{ 50, YYAT_SHIFT, 69 },
		{ 50, YYAT_SHIFT, 70 },
		{ 50, YYAT_SHIFT, 71 },
		{ 50, YYAT_SHIFT, 72 },
		{ 50, YYAT_SHIFT, 73 },
		{ 50, YYAT_SHIFT, 74 },
		{ 96, YYAT_SHIFT, 62 },
		{ 96, YYAT_SHIFT, 63 },
		{ 96, YYAT_SHIFT, 64 },
		{ 96, YYAT_SHIFT, 65 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 96, YYAT_SHIFT, 66 },
		{ 96, YYAT_SHIFT, 67 },
		{ 96, YYAT_SHIFT, 68 },
		{ 95, YYAT_SHIFT, 62 },
		{ 95, YYAT_SHIFT, 63 },
		{ 95, YYAT_SHIFT, 64 },
		{ 95, YYAT_SHIFT, 65 },
		{ 70, YYAT_SHIFT, 48 },
		{ 70, YYAT_SHIFT, 22 },
		{ 95, YYAT_SHIFT, 66 },
		{ 95, YYAT_SHIFT, 67 },
		{ 95, YYAT_SHIFT, 68 },
		{ 94, YYAT_SHIFT, 62 },
		{ 94, YYAT_SHIFT, 63 },
		{ 94, YYAT_SHIFT, 64 },
		{ 94, YYAT_SHIFT, 65 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 94, YYAT_SHIFT, 66 },
		{ 94, YYAT_SHIFT, 67 },
		{ 94, YYAT_SHIFT, 68 },
		{ 93, YYAT_SHIFT, 62 },
		{ 93, YYAT_SHIFT, 63 },
		{ 93, YYAT_SHIFT, 64 },
		{ 93, YYAT_SHIFT, 65 },
		{ 84, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 93, YYAT_SHIFT, 66 },
		{ 93, YYAT_SHIFT, 67 },
		{ 93, YYAT_SHIFT, 68 },
		{ 92, YYAT_SHIFT, 62 },
		{ 92, YYAT_SHIFT, 63 },
		{ 92, YYAT_SHIFT, 64 },
		{ 92, YYAT_SHIFT, 65 },
		{ 52, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 92, YYAT_SHIFT, 66 },
		{ 92, YYAT_SHIFT, 67 },
		{ 92, YYAT_SHIFT, 68 },
		{ -1, YYAT_ERROR, 0 },
		{ 84, YYAT_SHIFT, 18 },
		{ 45, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 44, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 84, YYAT_SHIFT, 21 },
		{ 84, YYAT_SHIFT, 22 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 52, YYAT_SHIFT, 18 },
		{ 43, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 34, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 52, YYAT_SHIFT, 21 },
		{ 52, YYAT_SHIFT, 22 },
		{ 45, YYAT_SHIFT, 18 },
		{ 69, YYAT_SHIFT, 17 },
		{ 44, YYAT_SHIFT, 18 },
		{ 18, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 45, YYAT_SHIFT, 21 },
		{ 45, YYAT_SHIFT, 22 },
		{ 44, YYAT_SHIFT, 48 },
		{ 44, YYAT_SHIFT, 22 },
		{ 43, YYAT_SHIFT, 18 },
		{ 17, YYAT_SHIFT, 17 },
		{ 34, YYAT_SHIFT, 18 },
		{ 16, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 43, YYAT_SHIFT, 48 },
		{ 43, YYAT_SHIFT, 22 },
		{ 34, YYAT_SHIFT, 21 },
		{ 34, YYAT_SHIFT, 22 },
		{ 18, YYAT_SHIFT, 18 },
		{ 66, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 69, YYAT_SHIFT, 48 },
		{ 69, YYAT_SHIFT, 22 },
		{ 18, YYAT_SHIFT, 48 },
		{ 18, YYAT_SHIFT, 22 },
		{ 17, YYAT_SHIFT, 18 },
		{ 65, YYAT_SHIFT, 17 },
		{ 16, YYAT_SHIFT, 18 },
		{ 64, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 17, YYAT_SHIFT, 21 },
		{ 17, YYAT_SHIFT, 22 },
		{ 16, YYAT_SHIFT, 21 },
		{ 16, YYAT_SHIFT, 22 },
		{ 63, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 62, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ 60, YYAT_SHIFT, 17 },
		{ 66, YYAT_SHIFT, 48 },
		{ 66, YYAT_SHIFT, 22 },
		{ 59, YYAT_SHIFT, 17 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 65, YYAT_SHIFT, 48 },
		{ 65, YYAT_SHIFT, 22 },
		{ 64, YYAT_SHIFT, 48 },
		{ 64, YYAT_SHIFT, 22 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ -1, YYAT_ERROR, 0 },
		{ 63, YYAT_SHIFT, 48 },
		{ 63, YYAT_SHIFT, 22 },
		{ 62, YYAT_SHIFT, 48 },
		{ 62, YYAT_SHIFT, 22 },
		{ 60, YYAT_SHIFT, 48 },
		{ 60, YYAT_SHIFT, 22 },
		{ -1, YYAT_ERROR, 0 },
		{ 59, YYAT_SHIFT, 48 },
		{ 59, YYAT_SHIFT, 22 }
	};
	yytokenaction = tokenaction;

	static const yystateaction_t YYNEARFAR YYBASED_CODE stateaction[] = {
		{ -136, 1, YYAT_ERROR, 0 },
		{ -117, 1, YYAT_ERROR, 0 },
		{ 153, 1, YYAT_ERROR, 0 },
		{ -126, 1, YYAT_ERROR, 0 },
		{ -142, 1, YYAT_ERROR, 0 },
		{ -238, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 1 },
		{ 0, 0, YYAT_REDUCE, 16 },
		{ 0, 0, YYAT_REDUCE, 17 },
		{ 0, 0, YYAT_REDUCE, 18 },
		{ 0, 0, YYAT_REDUCE, 19 },
		{ 0, 0, YYAT_REDUCE, 20 },
		{ 0, 0, YYAT_REDUCE, 21 },
		{ -127, 1, YYAT_ERROR, 0 },
		{ -144, 1, YYAT_ERROR, 0 },
		{ -158, 1, YYAT_ERROR, 0 },
		{ 13, 1, YYAT_REDUCE, 53 },
		{ 11, 1, YYAT_REDUCE, 53 },
		{ 4, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 3 },
		{ 0, 0, YYAT_REDUCE, 25 },
		{ -161, 1, YYAT_REDUCE, 51 },
		{ 0, 0, YYAT_REDUCE, 52 },
		{ -176, 1, YYAT_ERROR, 0 },
		{ -180, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 8 },
		{ 0, 0, YYAT_REDUCE, 9 },
		{ 0, 0, YYAT_REDUCE, 10 },
		{ 0, 0, YYAT_REDUCE, 12 },
		{ 0, 0, YYAT_REDUCE, 11 },
		{ 0, 0, YYAT_REDUCE, 13 },
		{ 0, 0, YYAT_REDUCE, 6 },
		{ 0, 0, YYAT_REDUCE, 7 },
		{ 0, 0, YYAT_REDUCE, 14 },
		{ -3, 1, YYAT_REDUCE, 53 },
		{ -195, 1, YYAT_ERROR, 0 },
		{ -257, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 49 },
		{ -269, 1, YYAT_REDUCE, 27 },
		{ -201, 1, YYAT_ERROR, 0 },
		{ -93, 1, YYAT_REDUCE, 29 },
		{ 0, 0, YYAT_REDUCE, 26 },
		{ -272, 1, YYAT_REDUCE, 28 },
		{ -5, 1, YYAT_REDUCE, 53 },
		{ -12, 1, YYAT_REDUCE, 53 },
		{ -14, 1, YYAT_REDUCE, 53 },
		{ -202, 1, YYAT_ERROR, 0 },
		{ -186, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 51 },
		{ -275, 1, YYAT_REDUCE, 33 },
		{ -74, 1, YYAT_REDUCE, 41 },
		{ 0, 0, YYAT_REDUCE, 34 },
		{ -21, 1, YYAT_REDUCE, 53 },
		{ -220, 1, YYAT_ERROR, 0 },
		{ -221, 1, YYAT_ERROR, 0 },
		{ -220, 1, YYAT_ERROR, 0 },
		{ -225, 1, YYAT_REDUCE, 23 },
		{ 0, 0, YYAT_REDUCE, 2 },
		{ 0, 0, YYAT_REDUCE, 4 },
		{ 42, 1, YYAT_REDUCE, 53 },
		{ 39, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 24 },
		{ 37, 1, YYAT_REDUCE, 53 },
		{ 35, 1, YYAT_REDUCE, 53 },
		{ 29, 1, YYAT_REDUCE, 53 },
		{ 27, 1, YYAT_REDUCE, 53 },
		{ 20, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 47 },
		{ 0, 0, YYAT_REDUCE, 48 },
		{ 2, 1, YYAT_REDUCE, 53 },
		{ -68, 1, YYAT_REDUCE, 53 },
		{ -131, 1, YYAT_REDUCE, 53 },
		{ -161, 1, YYAT_REDUCE, 53 },
		{ -189, 1, YYAT_REDUCE, 53 },
		{ -219, 1, YYAT_REDUCE, 53 },
		{ -217, 1, YYAT_DEFAULT, 76 },
		{ -261, 1, YYAT_DEFAULT, 106 },
		{ -245, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 60 },
		{ 0, 0, YYAT_REDUCE, 50 },
		{ 0, 0, YYAT_REDUCE, 30 },
		{ -246, 1, YYAT_ERROR, 0 },
		{ -253, 1, YYAT_ERROR, 0 },
		{ 0, 0, YYAT_REDUCE, 15 },
		{ -30, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 32 },
		{ 0, 0, YYAT_REDUCE, 31 },
		{ 0, 0, YYAT_REDUCE, 42 },
		{ 0, 0, YYAT_REDUCE, 43 },
		{ 0, 0, YYAT_REDUCE, 44 },
		{ 0, 0, YYAT_REDUCE, 45 },
		{ 0, 0, YYAT_REDUCE, 46 },
		{ -21, 1, YYAT_REDUCE, 35 },
		{ -30, 1, YYAT_REDUCE, 39 },
		{ -39, 1, YYAT_REDUCE, 40 },
		{ -48, 1, YYAT_REDUCE, 37 },
		{ -57, 1, YYAT_REDUCE, 38 },
		{ -228, 1, YYAT_REDUCE, 36 },
		{ -122, 1, YYAT_REDUCE, 53 },
		{ -139, 1, YYAT_REDUCE, 53 },
		{ -108, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 58 },
		{ 0, 0, YYAT_REDUCE, 59 },
		{ 0, 0, YYAT_REDUCE, 22 },
		{ -238, 1, YYAT_REDUCE, 54 },
		{ 0, 0, YYAT_REDUCE, 57 },
		{ -185, 1, YYAT_ERROR, 0 },
		{ -180, 1, YYAT_REDUCE, 53 },
		{ -163, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 55 },
		{ -267, 1, YYAT_ERROR, 0 },
		{ -197, 1, YYAT_REDUCE, 53 },
		{ 0, 0, YYAT_REDUCE, 56 }
	};
	yystateaction = stateaction;

	yynontermgoto_size = 53;

	static const yynontermgoto_t YYNEARFAR YYBASED_CODE nontermgoto[] = {
		{ 111, 31 },
		{ 107, 109 },
		{ 111, 112 },
		{ 111, 25 },
		{ 111, 34 },
		{ 99, 105 },
		{ 111, 32 },
		{ 111, 39 },
		{ 108, 110 },
		{ 108, 41 },
		{ 108, 38 },
		{ 108, 42 },
		{ 108, 40 },
		{ 111, 26 },
		{ 111, 29 },
		{ 111, 27 },
		{ 111, 30 },
		{ 111, 33 },
		{ 111, 28 },
		{ 100, 106 },
		{ 100, 51 },
		{ 100, 50 },
		{ 84, 103 },
		{ 98, 104 },
		{ 84, 56 },
		{ 74, 97 },
		{ 74, 37 },
		{ 60, -1 },
		{ 60, 86 },
		{ 36, 58 },
		{ 36, 36 },
		{ 73, 96 },
		{ 72, 95 },
		{ 71, 94 },
		{ 70, 93 },
		{ 69, 92 },
		{ 66, 91 },
		{ 65, 90 },
		{ 64, 89 },
		{ 63, 88 },
		{ 62, 87 },
		{ 59, 85 },
		{ 52, 80 },
		{ 45, 77 },
		{ 44, 76 },
		{ 43, 75 },
		{ 34, 55 },
		{ 18, 49 },
		{ 17, 47 },
		{ 16, 46 },
		{ 5, 35 },
		{ 4, 6 },
		{ 0, 2 }
	};
	yynontermgoto = nontermgoto;

	static const yystategoto_t YYNEARFAR YYBASED_CODE stategoto[] = {
		{ 51, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 49, -1 },
		{ 47, 36 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 40, 108 },
		{ 39, 108 },
		{ 36, 100 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 39, 84 },
		{ 0, -1 },
		{ 26, 111 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 34, 100 },
		{ 33, 100 },
		{ 34, 108 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 33, 108 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 29, 60 },
		{ 16, 100 },
		{ 0, -1 },
		{ 26, -1 },
		{ 25, -1 },
		{ 24, -1 },
		{ 23, -1 },
		{ 22, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 22, 74 },
		{ 21, 74 },
		{ 20, 74 },
		{ 19, 74 },
		{ 18, 74 },
		{ 12, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 15, 108 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 19, 111 },
		{ 1, 111 },
		{ 8, 74 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ 0, -1 },
		{ -3, 111 },
		{ -1, 100 },
		{ 0, -1 },
		{ 0, -1 },
		{ -2, 108 },
		{ 0, -1 }
	};
	yystategoto = stategoto;

	yydestructorptr = NULL;

	yytokendestptr = NULL;
	yytokendest_size = 0;

	yytokendestbaseptr = NULL;
	yytokendestbase_size = 0;
}
#line 333 ".\\myparser.y"


/////////////////////////////////////////////////////////////////////////////
// programs section

int main(void)
{
	int n = 1;
	mylexer lexer;
	myparser parser;
	lexer.yyin=new ifstream("test.txt");
	if (parser.yycreate(&lexer)) {
		if (lexer.yycreate(&parser)) {
			n = parser.yyparse();
			makeAsm();
		}
	}
	return n;
}


