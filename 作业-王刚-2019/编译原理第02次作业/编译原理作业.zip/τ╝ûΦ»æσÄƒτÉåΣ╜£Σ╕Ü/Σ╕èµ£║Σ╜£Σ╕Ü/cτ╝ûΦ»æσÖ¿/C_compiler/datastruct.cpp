#include "datastruct.h"
#include<map>
#include<iomanip>
using namespace std;

extern TreeNode *root;
extern int rownum;
extern int lineno;
map<string, VarType> _idTable;

TreeNode* newStmtNode(StmtType type)
{
	TreeNode* t = new TreeNode();
	int i;
	for(i=0;i<MAX;i++)
		t->child[i]=NULL;
	t->brother = NULL;
	t->nodeType = Stmt;
	t->type.stmtType = type;
	t->lineNo = lineno++;
	t->beginLabel = new char[10];
	t->nextLabel = new char[10];
	t->trueLabel = new char[10];
	t->falseLabel = new char[10];
	memset(t->beginLabel, 0, 10);
	memset(t->nextLabel, 0, 10);
	memset(t->trueLabel, 0, 10);
	memset(t->falseLabel, 0, 10);
	return t;
}
TreeNode* newExprNode(ExprType type)
{
	TreeNode* t = new TreeNode();
	int i;
	for(i=0;i<MAX;i++)
		t->child[i]=NULL;
	t->brother = NULL;
	t->nodeType = Expr;
	t->type.exprType = type;
	t->lineNo = lineno++;
	t->varType = Void;		
	t->beginLabel = new char[10];
	t->nextLabel = new char[10];
	t->trueLabel = new char[10];
	t->falseLabel = new char[10];
	memset(t->beginLabel, 0, 10);
	memset(t->nextLabel, 0, 10);
	memset(t->trueLabel, 0, 10);
	memset(t->falseLabel, 0, 10);
	return t;
}
TreeNode * newDeclNode(DeclType type)
{
	TreeNode * t = new TreeNode();
	int i;
	for (i = 0; i<MAX; i++) 
		t->child[i] = NULL;
	t->brother = NULL;
	t->nodeType = Decl;
	t->type.declType = type;
	t->lineNo = lineno++;
	t->beginLabel = new char[10];
	t->nextLabel = new char[10];
	t->trueLabel = new char[10];
	t->falseLabel = new char[10];
	memset(t->beginLabel, 0, 10);
	memset(t->nextLabel, 0, 10);
	memset(t->trueLabel, 0, 10);
	memset(t->falseLabel, 0, 10);
	return t;
}

void showTree(TreeNode* root)
{
	if(root==NULL)
		return;
	else
	{
		for(int i=0;i<MAX;i++)
		{
			if(root->child[i]==NULL)
				break;
			else
				showTree(root->child[i]);
		}
		getTemp(root);
		showNode(root);
		TreeNode* temp = root -> brother;
		if(temp!=NULL)
			showTree(temp);
		return;
	}
}

void showNode(TreeNode* node)
{
	node->lineNo=rownum++;
	cout<<node->lineNo<<":\t";
	switch(node->nodeType)
	{	
		case Stmt:
		{
			char names[8][30]={"Block statement,","If statement,\t","While statement,","For statement\t","Return statement,","Input statement\t","Output statement\t" };
			cout<<names[node->type.stmtType]<<"\t\t\t";
			break;
		}
		case Expr:
		{
			char names[4][30]={"Expr,\t\t","Const Declaration,","ID Declaration,\t","Type,\t\t"};
			char types[6][10]={"Void,\t","Integer,","Boolean,\t","Char,\t","Float,\t","Double,\t"};
			cout<<names[node->type.exprType]<<"\t";
			switch(node->type.exprType)
			{
				case Op:
				{
					switch(node->attr.op)
					{
						case ASSIGN:
						{
							cout<<"op:=\t";
							break;
						}
						case OR:
						{
							cout<<"op:||\t";
							break;
						}
						case AND:
						{
							cout<<"op:&&\t";
							break;
						}
						case EQ:
						{
							cout<<"op:==\t";
							break;
						}
						case NEQ:
						{
							cout<<"op:!=\t";
							break;
						}
						case LT:
						{
							cout<<"op:<\t";
							break;
						}
						case GT:
						{
							cout<<"op:>\t";
							break;
						}
						case LE:
						{
							cout<<"op:<=\t";
							break;
						}
						case GE:
						{
							cout<<"op:>=\t";
							break;
						}
						case PLUS:
						{
							cout<<"op:+\t";
							break;
						}
						case MINUS:
						{
							cout<<"op:-\t";
							break;
						}
						case MUL:
						{
							cout<<"op:*\t";
							break;
						}
						case DIV:
						{
							cout<<"op:/\t";
							break;
						}
						case MOD:
						{
							cout<<"op:%\t";
							break;
						}
						case DPLUS:
						{
							cout<<"op:++\t";
							break;
						}
						case DMINUS:
						{
							cout<<"op:--\t";
							break;
						}
						case OPPSITE:
						{
							cout<<"op:!\t";
							break;
						}
					}
					cout<<"\t";
					break;
				}
				case Const:
				{
					cout<<"value: "<<node->attr.value<<"\t";
					break;
				}
				case Id:
				{
					cout<<"symbol: "<<node->attr.id<<"\t";
					break;
				}
				case Type:
				{
					cout<<types[node->varType]<<"\t";
					break;
				}
			}
			break;
		}	
		case Decl:
		{
			char names[2][20] = { "Var Declaration, ", "Undefined" };
			cout << names[node->type.declType] << "\t\t\t";
			break;
		}
	}
	cout<<"children: ";
	for(int i=0;i<MAX;i++)
	{
		if(node->child[i]==NULL)
			break;
		cout<<node->child[i]->lineNo<<"   ";
		TreeNode* temp = node->child[i]->brother;
		while(temp!=NULL)
		{
			cout<<temp->lineNo<<"   ";
			temp = temp->brother;
		}
	}
	cout<<endl;
	return;
}

void typeCheck(TreeNode *root)
{
	traverse(root, assignType, checkNode);
}
static void traverse(TreeNode * node, void(*preProc) (TreeNode *),void(*postProc) (TreeNode *))
{
	if (node != NULL)
	{
		preProc(node);
		{ 
			int i;
			for (i = 0; i < MAX; i++)
				traverse(node->child[i], preProc, postProc);
		}
		postProc(node);
		traverse(node->brother, preProc, postProc);
	}
}
static void assignType(TreeNode* node)
{
	if (node->nodeType == Decl&&node->type.declType == Var)
	{
		VarType vartype = node->child[0]->varType;
		TreeNode* temp = node->child[1];
		while (temp != NULL)
		{
			if (temp->type.exprType == Id)
			{
				_idTable[temp->attr.id] = vartype;
				temp->varType = vartype;
				node->varType = vartype;
			}
			if (temp->type.exprType == Op && temp->attr.op == ASSIGN)
			{
				TreeNode* idNode = temp->child[0];
				if (idNode->type.exprType == Id)
				{
					_idTable[idNode->attr.id] = vartype;
					idNode->varType = vartype;
					node->varType = vartype;
				}
			}
			temp = temp->brother;
		}
	}
}
static void checkNode(TreeNode *node)
{
	switch (node->nodeType)
	{
		case Expr:
			switch (node->type.exprType)
			{
				case Op:
					switch(node->attr.op)	
					{
						case ASSIGN:
							{
								node->varType = node->child[0]->varType;
								//if(node->child[0]->varType!=node->child[1]->varType)
								//	cout<<"----------"<<left<<setw(3)<<node->lineNo<<": assign Expr type error."<<endl;
								break;
							}
						case PLUS:
						case MINUS:
						case MUL:
						case DIV:
						case MOD:
							{
								node->varType = Int;
								//if(node->child[0]->varType!=Int||node->child[1]->varType!=Int)
								//	cout<<"----------"<<left<<setw(3)<<node->lineNo<<": simple(2) Expr type error."<<endl;
								break;
							}
						case DPLUS:
						case DMINUS:
							{
								node->varType = node->child[0]->varType;
								//if(node->child[0]->varType!=Int)
								//	cout<<"----------"<<left<<setw(3)<<node->lineNo<<": simple(1) Expr type error."<<endl;
								break;
							}
						case EQ:
						case NEQ:
						case GT:
						case LT:
						case GE:
						case LE:
							{
								node->varType = Bool;
								if(node->child[0]->varType!=node->child[1]->varType)
									cout<<"----------"<<left<<setw(3)<<node->lineNo<<": equal Expr type error."<<endl;
								break;
							}
						case AND:
						case OR:
							{
								node->varType = Bool;
								if(node->child[0]->varType!=Bool||node->child[1]->varType!=Bool)
									cout<<"----------"<<left<<setw(3)<<node->lineNo<<": logit Expr type error."<<endl;
								break;
							}
						case OPPSITE:
							{
								node->varType = Bool;
								if(node->child[0]->varType!=Bool)
									cout<<"----------"<<left<<setw(3)<<node->lineNo<<": logit Expr type error."<<endl;
								break;
							}
					}
					break;
				case Const:
					node->varType = Int;
					break;
				case Id:
					node->varType = _idTable[node->attr.id];
					break;
				case Type:
					break;
				default:
					break;
			}
			break;
		case Stmt:
			switch (node->type.stmtType)
			{
				case Block:
					break;
				case If:
					{
						if(node->child[0]->varType!=Bool)
							cout<<"----------"<<left<<setw(3)<<node->lineNo<<": If Stmt type error."<<endl;
						break;
					}
				case While:
					{
						if(node->child[0]->varType!=Bool)
							cout<<"----------"<<left<<setw(3)<<node->lineNo<<": While Stmt type error."<<endl;
						break;
					}
				case For:
					{
						if(node->child[1]->varType!=Bool)
							cout<<"----------"<<left<<setw(3)<<node->lineNo<<": For Stmt type error."<<endl;
						break;
					}
				case Return:
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}

void getTemp(TreeNode *node)
{
	if (node->nodeType != Expr)
		return;
	if (node->attr.op < PLUS || node->attr.op > DIV)
		return;
	TreeNode *arg1 = node->child[0];
	TreeNode *arg2 = node->child[1];
	if (arg1->type.exprType == Op)
		tempNum--;
	if (arg2 && arg2->type.exprType==Op)
		tempNum--;
	node->tempNo = tempNum;
	tempNum++;
}
void newLabel(char *label)
{
	memset(label,0,10);
	sprintf(label,"L%d",labelNum);
	labelNum++;
}
void getLabel()
{
	TreeNode *temp=root;
	temp->beginLabel="_start";
	recursiveGetLabel(temp);
}
void recursiveGetLabel(TreeNode *node)
{
	if(node->nodeType==Stmt)
		stmtGetLabel(node);
	if(node->nodeType==Expr)
		exprGetLabel(node);
}
void stmtGetLabel(TreeNode *node)
{
	switch(node->type.stmtType)
	{
		case Block:
			{
				for(int i=0;node->child[i];i++)
				{
					recursiveGetLabel(node->child[i]);
					for(TreeNode *temp=node->child[i]->brother;temp;temp=temp->brother)
						recursiveGetLabel(temp);
				}
			}
			break;
		case If:
			{
				TreeNode *t=node->child[0];
				TreeNode *c1=node->child[1];
				TreeNode *c2=node->child[2];
				newLabel(t->trueLabel);
				strcpy(c1->beginLabel,t->trueLabel);
				if(strcmp(node->nextLabel,"")==0)
					newLabel(node->nextLabel);
				strcpy(c1->nextLabel,node->nextLabel);
				if(c2)
				{
					newLabel(t->falseLabel);
					strcpy(c2->beginLabel,t->falseLabel);
					strcpy(c2->nextLabel,node->nextLabel);
				}
				else
					strcpy(t->falseLabel,node->nextLabel);
				if(node->brother)
					strcpy(node->brother->beginLabel,node->nextLabel);
				recursiveGetLabel(t);
				recursiveGetLabel(c1);
				if(c2)
					recursiveGetLabel(c2);
			}
			break;
		case While:
			{
				TreeNode *t=node->child[0];
				TreeNode *c=node->child[1];
				newLabel(node->beginLabel);
				strcpy(c->nextLabel,node->beginLabel);
				newLabel(t->trueLabel);
				strcpy(c->beginLabel,t->trueLabel);
				if(strcmp(node->nextLabel,"")==0)
					newLabel(node->nextLabel);
				strcpy(t->falseLabel,node->nextLabel);
				if(node->brother)
					strcpy(node->brother->beginLabel,node->nextLabel);
				recursiveGetLabel(t);
				recursiveGetLabel(c);
			}
			break;
		case For:
			{
				TreeNode *t=node->child[1];
				TreeNode *c=node->child[3];
				newLabel(node->beginLabel);
				strcpy(c->nextLabel,node->beginLabel);
				newLabel(t->trueLabel);
				strcpy(c->beginLabel,t->trueLabel);
				if(strcmp(node->nextLabel,"")==0)
					newLabel(node->nextLabel);
				strcpy(t->falseLabel,node->nextLabel);
				if(node->brother)
					strcpy(node->brother->beginLabel,node->nextLabel);
				recursiveGetLabel(t);
				recursiveGetLabel(c);
			}
			break;
		default:
			break;
	}
}
void exprGetLabel(TreeNode *node)
{
	if(node->varType!=Bool) return;
	TreeNode *c1=node->child[0];
	TreeNode *c2=node->child[1];
	switch(node->attr.op)
	{
		case AND:
			{
				newLabel(c1->trueLabel);
				strcpy(c2->trueLabel,node->trueLabel);
				strcpy(c2->falseLabel,node->falseLabel);
				strcpy(c1->falseLabel,c2->falseLabel);
			}
			break;
		case OR:
			{
				newLabel(c1->falseLabel);
				strcpy(c2->falseLabel,node->falseLabel);
				strcpy(c2->trueLabel,node->trueLabel);
				strcpy(c1->trueLabel,c2->trueLabel);
			}
			break;
		case OPPSITE:
			{
				strcpy(c1->trueLabel,node->falseLabel);
				strcpy(c1->falseLabel,node->trueLabel);
			}
			break;
		default:
			break;
	}
	if(c1)
		recursiveGetLabel(c1);
	if(c2)
		recursiveGetLabel(c2);
}

void genCode(ostream &out)
{
	genHeader(out);
	TreeNode *decl=root->child[0];
	if(decl->nodeType==Decl)
		genDecl(out,decl);
	out<<endl<<endl<<"\t.code"<<endl;
	out<<"\t"<<root->beginLabel<<":"<<endl;
	recursiveGenCode(out,root);
	if(strcmp(root->nextLabel,"")!=0)
		out<<root->nextLabel<<":"<<endl;
	out<<"\t\tinvoke crt_printf, SADD(\"print any key to continue...\")"<<endl;
	out<<"\t\tinvoke crt__getch"<<endl;
	out<<"\t\tinvoke crt__exit, 0"<<endl;
	out<<"\tend "<<root->beginLabel<<endl;
}
void genHeader(ostream &out)
{
	out << "\t.586" << endl;
	out << "\t.model flat, stdcall" << endl;
	out << "\toption casemap :none" << endl;
	out << endl;
	out << "\tinclude \\masm32\\macros\\macros.asm" << endl;
	out << "\tinclude \\masm32\\include\\msvcrt.inc" << endl;
	out << "\tincludelib \\masm32\\lib\\msvcrt.lib" << endl;
	//out << "\tinclude \\masm32\\include\\windows.inc" << endl;
	//out << "\tinclude \\masm32\\include\\user32.inc" << endl;
	//out << "\tinclude \\masm32\\include\\kernel32.inc" << endl;
	//out << "\tinclude \\masm32\\include\\masm32.inc" << endl;
	//out << endl;
	//out << "\tincludelib \\masm32\\lib\\user32.lib" << endl;
	//out << "\tincludelib \\masm32\\lib\\kernel32.lib" << endl;
	//out << "\tincludelib \\masm32\\lib\\masm32.lib" << endl;
}
void genDecl(ostream &out, TreeNode *node)
{
	out<<endl<<endl<<"\t.data"<<endl;
	for(;node&&node->nodeType==Decl;node=node->brother)
	{
		for(TreeNode *temp=node->child[1];temp;temp=temp->brother)
		{
			if(temp->varType==Int)
				out<<"\t\t_"<<temp->attr.id<<" DWORD 0"<<endl;
			if(temp->varType==Char)
				out<<"\t\t_"<<temp->attr.id<<" BYTE 0"<<endl;
		}
	}
	for(int i=0;i<tempNum;i++)
		out<<"\t\tt"<<i<<" DWORD 0"<<endl;
	//out<<"\t\tbuffer BYTE 128 dup(0)"<<endl;
	//out<<"\t\tLF BYTE 13, 10, 0"<<endl;
}
void recursiveGenCode(ostream &out, TreeNode *node)
{
	if(node->nodeType==Stmt)
		stmtGenCode(out,node);
	if(node->nodeType==Expr&&node->type.exprType==Op)
	{
		if(node->child[0]->nodeType==Expr&&node->child[0]->type.exprType==Op)
			recursiveGenCode(out,node->child[0]);
		if(node->attr.op==AND)
			if(strcmp(node->child[0]->trueLabel,"")!=0)
				out<<"\t"<<node->child[0]->trueLabel<<":"<<endl;
		if(node->attr.op==OR)
			if(strcmp(node->child[0]->falseLabel,"")!=0)
				out<<"\t"<<node->child[0]->falseLabel<<":"<<endl;
		if(node->attr.op!=OPPSITE)
			if(node->child[1]->nodeType==Expr&&node->child[1]->type.exprType==Op)
				recursiveGenCode(out,node->child[1]);
		exprGenCode(out,node);
	}
}
void stmtGenCode(ostream &out, TreeNode *node)
{
	switch(node->type.stmtType)
	{
		case Block:
		{
			for(int i=0;node->child[i];i++)
			{
				recursiveGenCode(out,node->child[i]);
				for(TreeNode *temp=node->child[i]->brother;temp;temp=temp->brother)
					recursiveGenCode(out,temp);
			}
			break;
		}
		case If:
		{
			recursiveGenCode(out,node->child[0]);
			if(strcmp(node->child[0]->trueLabel,"")!=0)
				out<<"\t"<<node->child[0]->trueLabel<<":"<<endl;
			recursiveGenCode(out,node->child[1]);
			out<<"\t\tjmp "<<node->nextLabel<<endl;
			if(node->child[2])
			{
				if(strcmp(node->child[0]->falseLabel,"")!=0)
					out<<"\t"<<node->child[0]->falseLabel<<":"<<endl;
				recursiveGenCode(out,node->child[2]);
				out<<"\t\tjmp "<<node->nextLabel<<endl;
			}
			if(strcmp(node->nextLabel,"")!=0)
				out<<"\t"<<node->nextLabel<<":"<<endl;
			break;
		}
		case While:
		{
			if(strcmp(node->beginLabel,"")!=0)
				out<<"\t"<<node->beginLabel<<":"<<endl;
			recursiveGenCode(out,node->child[0]);
			if(strcmp(node->child[0]->trueLabel,"")!=0)
				out<<"\t"<<node->child[0]->trueLabel<<":"<<endl;
			recursiveGenCode(out,node->child[1]);
			out<<"\t\tjmp "<<node->beginLabel<<endl;
			if(strcmp(node->nextLabel,"")!=0)
				out<<"\t"<<node->nextLabel<<":"<<endl;
			break;
		}
		case For:
		{
			if(node->child[0])
				recursiveGenCode(out,node->child[0]);
			if(strcmp(node->beginLabel,"")!=0)
				out<<"\t"<<node->beginLabel<<":"<<endl;
			recursiveGenCode(out,node->child[1]);
			if(strcmp(node->child[1]->trueLabel,"")!=0)
				out<<"\t"<<node->child[1]->trueLabel<<":"<<endl;
			recursiveGenCode(out,node->child[3]);
			if(node->child[2])
				recursiveGenCode(out,node->child[2]);
			out<<"\t\tjmp "<<node->beginLabel<<endl;
			if(strcmp(node->nextLabel,"")!=0)
				out<<"\t"<<node->nextLabel<<":"<<endl;
			break;
		}
		case Input:
		{
			if(node->child[0]->type.exprType==Id)
			{
				if(node->child[0]->varType==Int)
					out<<"\t\tinvoke crt_scanf, SADD(\"%d\",0), addr _"<<node->child[0]->attr.id<<endl;
				if(node->child[0]->varType==Char)
					out<<"\t\tinvoke crt_scanf, SADD(\"%c\",0), addr _"<<node->child[0]->attr.id<<endl;
			}
			break;
		}
		case Output:
		{
			if(node->child[0]->type.exprType==Id)
			{
				if(node->child[0]->varType==Int)
					out<<"\t\tinvoke crt_printf, SADD(\"%d\", 13, 10), _"<<node->child[0]->attr.id<<endl;
				if(node->child[0]->varType==Char)
					out<<"\t\tinvoke crt_printf, SADD(\"%c\", 13, 10), _"<<node->child[0]->attr.id<<endl;
			}
			break;
		}
		default:
			break;
	}	
}
void exprGenCode(ostream &out, TreeNode *node)
{
	TreeNode *c1=node->child[0];
	TreeNode *c2=node->child[1];
	switch(node->attr.op)
	{
		case PLUS:
		{
			if(c1->varType==Char)
			{
				out<<"\t\tMOV eax, 0"<<endl;
				out<<"\t\tMOV al, ";
			}
			else
				out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tADD eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			out<<"\t\tMOV t"<<node->tempNo<<", eax"<<endl;
			break;
		}
		case MINUS:
		{
			if(c1->varType==Char)
			{
				out<<"\t\tMOV eax, 0"<<endl;
				out<<"\t\tMOV al, ";
			}
			else
				out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tSUB eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			out<<"\t\tMOV t"<<node->tempNo<<", eax"<<endl;
			break;
		}
		case MUL:
		{
			if(c1->varType==Char)
			{
				out<<"\t\tMOV eax, 0"<<endl;
				out<<"\t\tMOV al, ";
			}
			else
				out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tIMUL eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			out<<"\t\tMOV t"<<node->tempNo<<", eax"<<endl;
			break;
		}
		case DIV:
		{
			if(c1->varType==Char)
			{
				out<<"\t\tMOV eax, 0"<<endl;
				out<<"\t\tMOV al, ";
			}
			else
				out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tMOV ecx, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			out<<"\t\tIDIV cl"<<endl;
			out<<"\t\tAND eax, 0000FFFFh"<<endl;
			// out<<"\t\tDIV ";
			// if(c2->type.exprType==Id)
				// out<<"_"<<c2->attr.id;
			// else if(c2->type.exprType==Const)
				// out<<c2->attr.value;
			// else
				// out<<"t"<<c2->tempNo;
			// out<<endl;
			out<<"\t\tMOV t"<<node->tempNo<<", eax"<<endl;
			break;
		}
		case ASSIGN:
		{
			if(c2->varType==Char)
			{
				out<<"\t\tMOV eax, 0"<<endl;
				out<<"\t\tMOV al, ";
			}
			else
				out<<"\t\tMOV eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			out<<"\t\tMOV ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			if(c1->varType==Char)
				out<<", al"<<endl;
			else
				out<<", eax"<<endl;
			break;
		}
		case LT:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tjl "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		case GT:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tjg "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		case LE:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tjle "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		case GE:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tjge "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		case EQ:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tje "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		case NEQ:
		{
			out<<"\t\tMOV eax, ";
			if(c1->type.exprType==Id)
				out<<"_"<<c1->attr.id;
			else if(c1->type.exprType==Const)
				out<<c1->attr.value;
			else
				out<<"t"<<c1->tempNo;
			out<<endl;
			out<<"\t\tCMP eax, ";
			if(c2->type.exprType==Id)
				out<<"_"<<c2->attr.id;
			else if(c2->type.exprType==Const)
				out<<c2->attr.value;
			else
				out<<"t"<<c2->tempNo;
			out<<endl;
			
			out<<"\t\tjne "<<node->trueLabel<<endl;
			out<<"\t\tjmp "<<node->falseLabel<<endl;
			break;
		}
		default:
			break;
	}
}

void makeAsm()
{
	getLabel();
	ofstream fout("D://masm32//examples//advanced//test//test.asm");
	genCode(fout);
	fout.close();
}
























