#pragma once

#include<iostream>
#include<string>
#include<cstring>
#include<fstream>
#include"myparser.h"
#include"mylexer.h"
using namespace std;

#define MAX 4
enum NodeType {Stmt,Expr,Decl};
enum StmtType {Block,If,While,For,Return,Input,Output};
enum ExprType {Op,Const,Id,Type};
enum DeclType {Var};
enum VarType  {Void,Int,Bool,Char,Float,Double};

static int tempNum;
static int labelNum;

union _Type
{
	StmtType stmtType;
	ExprType exprType;
	DeclType declType;
};
union Attribute
{
	int op;
	double value;
	char *id;
};

struct TreeNode
{
	TreeNode *child[MAX];
	TreeNode *brother;
	NodeType nodeType;
	_Type type;
	Attribute attr;
	VarType varType;
	int tempNo;
	char *trueLabel;
	char *falseLabel;
	char *beginLabel;
	char *nextLabel;
	int lineNo;
};

TreeNode* newStmtNode(StmtType type);
TreeNode* newExprNode(ExprType type);
TreeNode* newDeclNode(DeclType type);

void typeCheck(TreeNode *root);
static void traverse(TreeNode *node, void(*preProc) (TreeNode *),void (*postProc) (TreeNode *));
static void checkNode(TreeNode *node);
static void assignType(TreeNode *node);

void showTree(TreeNode* root);
void showNode(TreeNode* node);

void getTemp(TreeNode *node);
void newLabel(char *label);
void getLabel();
void recursiveGetLabel(TreeNode *node);
void stmtGetLabel(TreeNode *node);
void exprGetLabel(TreeNode *node);

void genCode(ostream &out);
void genHeader(ostream &out);
void genDecl(ostream &out, TreeNode *node);
void recursiveGenCode(ostream &out, TreeNode *node);
void stmtGenCode(ostream &out, TreeNode *node);
void exprGenCode(ostream &out, TreeNode *node);

void makeAsm();

	
	